"""Load balancing module for Flow2API"""
import asyncio
import random
from collections import Counter
from datetime import datetime, timezone
from typing import Optional, Dict, Set
from ..core.models import Token
from ..core.config import config
from ..core.account_tiers import (
    get_paygate_tier_label,
    get_required_paygate_tier_for_model,
    normalize_user_paygate_tier,
    supports_model_for_tier,
    ultra_reserved_for_4k_image,
)
from .concurrency_manager import ConcurrencyManager
from .cookie_capacity import account_limit
from ..core.logger import debug_logger


class LoadBalancer:
    """Token load balancer with load-aware selection"""

    def __init__(self, token_manager, concurrency_manager: Optional[ConcurrencyManager] = None):
        self.token_manager = token_manager
        self.concurrency_manager = concurrency_manager
        self._image_pending: Dict[int, int] = {}
        self._video_pending: Dict[int, int] = {}
        self._pending_lock = asyncio.Lock()
        self._assignment_lock = asyncio.Lock()
        self._round_robin_state: Dict[str, Optional[int]] = {"image": None, "video": None, "default": None}
        self._rr_lock = asyncio.Lock()
        self._idle_waiters: Dict[object, dict] = {}
        self._idle_sequence = 0
        self._idle_changed = asyncio.Event()

    def _notify_idle_waiters(self):
        # Rotate the event so one waiter cannot clear another waiter's wakeup.
        previous = self._idle_changed
        self._idle_changed = asyncio.Event()
        previous.set()

    async def _get_pending_count(self, token_id: int, for_image_generation: bool, for_video_generation: bool) -> int:
        async with self._pending_lock:
            if for_image_generation:
                return max(0, int(self._image_pending.get(token_id, 0)))
            if for_video_generation:
                return max(0, int(self._video_pending.get(token_id, 0)))
            return 0

    async def _add_pending(self, token_id: int, for_image_generation: bool, for_video_generation: bool):
        async with self._pending_lock:
            if for_image_generation:
                self._image_pending[token_id] = max(0, int(self._image_pending.get(token_id, 0))) + 1
            elif for_video_generation:
                self._video_pending[token_id] = max(0, int(self._video_pending.get(token_id, 0))) + 1

    async def release_pending(self, token_id: int, for_image_generation: bool = False, for_video_generation: bool = False):
        async with self._pending_lock:
            if for_image_generation:
                current = max(0, int(self._image_pending.get(token_id, 0)))
                if current <= 1:
                    self._image_pending.pop(token_id, None)
                else:
                    self._image_pending[token_id] = current - 1
            elif for_video_generation:
                current = max(0, int(self._video_pending.get(token_id, 0)))
                if current <= 1:
                    self._video_pending.pop(token_id, None)
                else:
                    self._video_pending[token_id] = current - 1
        self._notify_idle_waiters()

    async def _get_token_load(self, token_id: int, for_image_generation: bool, for_video_generation: bool) -> tuple[int, Optional[int]]:
        """获取 token 当前负载。

        Returns:
            (inflight, remaining)
            remaining 为 None 表示无限制
        """
        if not self.concurrency_manager:
            return 0, None

        if for_image_generation:
            inflight = await self.concurrency_manager.get_image_inflight(token_id)
            remaining = await self.concurrency_manager.get_image_remaining(token_id)
            pending = await self._get_pending_count(token_id, True, False)
            effective_inflight = inflight + pending
            if remaining is not None:
                remaining = max(0, remaining - pending)
            return effective_inflight, remaining

        if for_video_generation:
            inflight = await self.concurrency_manager.get_video_inflight(token_id)
            remaining = await self.concurrency_manager.get_video_remaining(token_id)
            pending = await self._get_pending_count(token_id, False, True)
            effective_inflight = inflight + pending
            if remaining is not None:
                remaining = max(0, remaining - pending)
            return effective_inflight, remaining

        return 0, None

    async def _reserve_slot(self, token_id: int, for_image_generation: bool, for_video_generation: bool) -> bool:
        """尝试为当前 token 预占一个生成槽位。"""
        if not self.concurrency_manager:
            return True

        if for_image_generation:
            return await self.concurrency_manager.acquire_image(token_id)

        if for_video_generation:
            return await self.concurrency_manager.acquire_video(token_id)

        return True

    async def _select_round_robin(self, tokens: list[dict], scenario: str) -> Optional[dict]:
        """Select candidate in round-robin order for the given scenario."""
        if not tokens:
            return None

        tokens_sorted = sorted(tokens, key=lambda item: item["token"].id or 0)
        async with self._rr_lock:
            last_id = self._round_robin_state.get(scenario)
            start_idx = 0
            if last_id is not None:
                for idx, item in enumerate(tokens_sorted):
                    if item["token"].id == last_id:
                        start_idx = (idx + 1) % len(tokens_sorted)
                        break
            selected = tokens_sorted[start_idx]
            self._round_robin_state[scenario] = selected["token"].id
        return selected

    async def _check_extension_route(self, token: Token) -> tuple[bool, str]:
        """Ensure extension captcha requests are routed to the selected account."""
        if config.captcha_method != "extension":
            return True, ""

        try:
            from .browser_captcha_extension import ExtensionCaptchaService

            service = await ExtensionCaptchaService.get_instance(getattr(self.token_manager, "db", None))
            has_connection, route_key = await service.has_connection_for_token(token.id)
            if has_connection:
                return True, ""

            available = service.describe_routes() or "none"
            if route_key:
                return False, f"扩展路由 {route_key} 未连接（可用路由: {available}）"
            return False, f"扩展路由未配置或匿名插件未连接（可用路由: {available}）"
        except Exception as exc:
            return False, f"扩展路由检查失败: {exc}"

    async def select_token(self, *args, **kwargs) -> Optional[Token]:
        # Wait before binding an idle Cookie account, not behind one fixed jar.
        # The assignment lock covers each selection plus its pending increment,
        # never the wait. No media dispatch or retry is performed here.
        wait_seconds = max(0.0, min(240.0, float(kwargs.pop("wait_idle_seconds", 0))))
        diagnostic = kwargs.get("selection_diagnostic")
        started = asyncio.get_running_loop().time()
        polls = 0
        ticket = None
        snapshot_at = None
        if isinstance(diagnostic, dict):
            diagnostic["selection_snapshot_status"] = "not_observed"
        if wait_seconds and kwargs.get("idle_cookie_only"):
            # The same tier/model-family shares capacity across aspect aliases.
            # Per-account exclusion below lets a later eligible waiter use an
            # account that an older request cannot use, without blocking it.
            ticket = object()
            self._idle_sequence += 1
            key = (bool(kwargs.get("for_image_generation")),
                   bool(kwargs.get("for_video_generation")),
                   kwargs.get("model_quota_key"),
                   get_required_paygate_tier_for_model(kwargs.get("model")))
            self._idle_waiters[ticket] = {"sequence": self._idle_sequence,
                "key": key, "excluded": set(kwargs.get("excluded_token_ids") or ())}
            kwargs["_idle_waiter"] = ticket
            if isinstance(diagnostic, dict):
                diagnostic.update(queue_policy="oldest_eligible_account_v1",
                    queue_depth_at_enqueue=sum(w["key"] == key for w in self._idle_waiters.values()),
                    fairness_deferrals=0, release_wakeups=0)
        deadline = asyncio.timeout(wait_seconds or None)
        try:
            async with deadline:
                while True:
                    changed = self._idle_changed
                    # Commit only a completed selection pass. Cancellation at
                    # the deadline must not replace the previous evidence with
                    # zeroes or a partly scanned pool.
                    poll_kwargs = kwargs
                    poll_diagnostic = None
                    if isinstance(diagnostic, dict):
                        poll_diagnostic = {"busy_cookie_candidates": 0,
                            "older_waiter_candidates": 0,
                            "fairness_deferrals": diagnostic.get("fairness_deferrals", 0)}
                        poll_kwargs = dict(kwargs, selection_diagnostic=poll_diagnostic)
                    async with self._assignment_lock:
                        token = await self._select_token(*args, **poll_kwargs)
                    polls += 1
                    if poll_diagnostic is not None:
                        snapshot_at = asyncio.get_running_loop().time()
                        diagnostic.update(poll_diagnostic,
                            selection_snapshot_status="completed",
                            selection_snapshot_age_ms=0)
                    if token is not None:
                        if isinstance(diagnostic, dict):
                            diagnostic.update(status="selected", polls=polls,
                                wait_ms=round((asyncio.get_running_loop().time()-started)*1000))
                        return token
                    busy = ((diagnostic or {}).get("busy_cookie_candidates", 0)
                            or (diagnostic or {}).get("older_waiter_candidates", 0))
                    elapsed = asyncio.get_running_loop().time()-started
                    if not busy or not wait_seconds or elapsed >= wait_seconds:
                        if isinstance(diagnostic, dict):
                            diagnostic.update(status="timeout" if busy and wait_seconds else "unavailable",
                                polls=polls, wait_ms=round(elapsed*1000),
                                dispatch_started=False, upload_posts=0)
                        return None
                    # Re-evaluate auth/tier/cooldown/egress exclusions at every selection.
                    # Cancellable wait holds neither an account nor the assignment lock.
                    try:
                        await asyncio.wait_for(changed.wait(), min(.5, wait_seconds-elapsed))
                        if isinstance(diagnostic, dict):
                            diagnostic["release_wakeups"] = diagnostic.get("release_wakeups", 0) + 1
                    except asyncio.TimeoutError:
                        pass
        except asyncio.TimeoutError:
            if not deadline.expired():
                raise
            if isinstance(diagnostic, dict):
                diagnostic.update(status="timeout", polls=polls,
                    wait_ms=round((asyncio.get_running_loop().time()-started)*1000),
                    dispatch_started=False, upload_posts=0)
                if snapshot_at is not None:
                    diagnostic["selection_snapshot_age_ms"] = round(
                        (asyncio.get_running_loop().time()-snapshot_at)*1000)
            return None
        except asyncio.CancelledError:
            if isinstance(diagnostic, dict):
                diagnostic.update(status="cancelled", dispatch_started=False, upload_posts=0)
            raise
        finally:
            if ticket is not None:
                self._idle_waiters.pop(ticket, None)
                self._notify_idle_waiters()

    async def _select_token(
        self,
        for_image_generation: bool = False,
        for_video_generation: bool = False,
        model: Optional[str] = None,
        model_quota_key: Optional[str] = None,
        reserve: bool = False,
        enforce_concurrency_filter: bool = True,
        track_pending: bool = False,
        excluded_token_ids: Optional[Set[int]] = None,
        idle_cookie_only: bool = False,
        selection_diagnostic: Optional[dict] = None,
        _idle_waiter: Optional[object] = None,
    ) -> Optional[Token]:
        """
        Select a token using load-aware balancing

        Args:
            for_image_generation: If True, only select tokens with image_enabled=True
            for_video_generation: If True, only select tokens with video_enabled=True
            model: Model name (used to filter tokens for specific models)
            model_quota_key: Upstream model-family key used for quota cooldowns
            reserve: Whether to atomically reserve one concurrency slot for the selected token
            enforce_concurrency_filter:
                Whether to pre-filter tokens by current inflight/remaining capacity.
                For reserve=False generation paths, this should usually be False so
                requests can enter the downstream wait queue instead of failing fast.
            track_pending:
                Whether to count the selected token as a queued request immediately.
                This smooths burst distribution before the hard concurrency slot is acquired.
            excluded_token_ids:
                Token ids that must not be selected for this attempt.  This is used by
                the bounded cross-account image retry so the second attempt cannot
                silently return to the account that just failed.

        Returns:
            Selected token or None if no available tokens
        """
        log_info = debug_logger.log_info if selection_diagnostic is None else lambda *_: None
        log_info(
            f"[LOAD_BALANCER] 开始选择Token (图片生成={for_image_generation}, "
            f"视频生成={for_video_generation}, 模型={model}, 预占槽位={reserve})"
        )

        active_tokens = await self.token_manager.get_active_tokens()
        if isinstance(selection_diagnostic, dict):
            selection_diagnostic.update(active_accounts=len(active_tokens),
                eligible_candidates=0, eligible_pipeline_capacity=0, cookie_not_ready_candidates=0)
        log_info(f"[LOAD_BALANCER] 获取到 {len(active_tokens)} 个活跃Token")

        if not active_tokens:
            log_info(f"[LOAD_BALANCER] ❌ 没有活跃的Token")
            return None

        excluded_token_ids = {
            int(token_id)
            for token_id in (excluded_token_ids or set())
            if isinstance(token_id, int) or str(token_id).isdigit()
        }
        available_tokens = []
        filtered_reasons = {}
        required_tier = get_required_paygate_tier_for_model(model)
        cooled_token_ids = set()
        if model_quota_key:
            cooled_token_ids = await self.token_manager.get_token_ids_in_model_cooldown(
                model_quota_key
            )
        breaker_cooled_ids = await self.token_manager.get_token_ids_in_model_cooldown(
            "ACCOUNT_BREAKER"
        )

        cookie_sessions = getattr(getattr(self.token_manager, "cookie_auth", None), "cache", {})
        for token in active_tokens:
            if (for_image_generation and token.id in cookie_sessions
                    and self.token_manager.needs_at_refresh(token)):
                # Cookie admission is read-only here; the bounded maintainer
                # owns recovery. Avoid serial DB validation of every stale jar.
                filtered_reasons[token.id] = "Cookie 认证待复查或图片尚未验收"
                if isinstance(selection_diagnostic, dict):
                    selection_diagnostic["cookie_not_ready_candidates"] += 1
                continue
            if for_video_generation and token.id in self.token_manager.cookie_auth.cache:
                filtered_reasons[token.id] = "Cookie 会话尚未支持视频生成"
                continue
            if token.id in excluded_token_ids:
                filtered_reasons[token.id] = "已由当前请求排除"
                continue
            if token.id in breaker_cooled_ids:
                filtered_reasons[token.id] = "账号连续错误后暂时冷却，届时自动恢复调度"
                continue
            normalized_tier = normalize_user_paygate_tier(token.user_paygate_tier)
            if ultra_reserved_for_4k_image(
                normalized_tier, model, for_image_generation=for_image_generation,
            ):
                filtered_reasons[token.id] = "Ultra 账号预留给 4K 图片"
                continue
            if model and not supports_model_for_tier(model, normalized_tier):
                filtered_reasons[token.id] = '账号等级不足，需要 ' + get_paygate_tier_label(required_tier)
                continue
            if token.id in cooled_token_ids:
                filtered_reasons[token.id] = "当前模型族每日额度冷却中"
                continue
            if for_image_generation:
                if not token.image_enabled:
                    filtered_reasons[token.id] = "图片生成已禁用"
                    continue

                route_ok, route_reason = await self._check_extension_route(token)
                if not route_ok:
                    filtered_reasons[token.id] = route_reason
                    continue

                if (
                    enforce_concurrency_filter
                    and self.concurrency_manager
                    and not await self.concurrency_manager.can_use_image(token.id)
                ):
                    filtered_reasons[token.id] = "图片并发已满"
                    continue

            if for_video_generation:
                if not token.video_enabled:
                    filtered_reasons[token.id] = "视频生成已禁用"
                    continue

                route_ok, route_reason = await self._check_extension_route(token)
                if not route_ok:
                    filtered_reasons[token.id] = route_reason
                    continue

                if (
                    enforce_concurrency_filter
                    and self.concurrency_manager
                    and not await self.concurrency_manager.can_use_video(token.id)
                ):
                    filtered_reasons[token.id] = "视频并发已满"
                    continue

            if isinstance(selection_diagnostic, dict):
                selection_diagnostic["eligible_candidates"] += 1
            pipeline_limit = account_limit(token.id, model=model, tier=token.user_paygate_tier) if token.id in cookie_sessions else 1
            if isinstance(selection_diagnostic, dict):
                selection_diagnostic["eligible_pipeline_capacity"] += pipeline_limit
            inflight, remaining = await self._get_token_load(
                token.id,
                for_image_generation=for_image_generation,
                for_video_generation=for_video_generation
            )
            if (idle_cookie_only and for_image_generation and token.id in cookie_sessions
                    and max(inflight, await self._get_pending_count(token.id, True, False)) >= pipeline_limit):
                filtered_reasons[token.id] = "Cookie 图片流水线繁忙，提交前等待其他空闲账号"
                if isinstance(selection_diagnostic, dict):
                    selection_diagnostic["busy_cookie_candidates"] = selection_diagnostic.get("busy_cookie_candidates", 0) + 1
                continue
            waiter = self._idle_waiters.get(_idle_waiter)
            if waiter is not None and any(
                older["sequence"] < waiter["sequence"] and older["key"] == waiter["key"]
                and token.id not in older["excluded"]
                for older in self._idle_waiters.values()
            ):
                filtered_reasons[token.id] = "空闲账号优先分配给较早且可使用该账号的请求"
                if isinstance(selection_diagnostic, dict):
                    selection_diagnostic["older_waiter_candidates"] = selection_diagnostic.get("older_waiter_candidates", 0) + 1
                    selection_diagnostic["fairness_deferrals"] = selection_diagnostic.get("fairness_deferrals", 0) + 1
                continue
            available_tokens.append({
                "token": token,
                "inflight": inflight,
                "remaining": remaining,
                "needs_refresh": self.token_manager.needs_at_refresh(token),
                "random": random.random()
            })

        if filtered_reasons:
            log_info(f"[LOAD_BALANCER] 已过滤Token:")
            for token_id, reason in filtered_reasons.items():
                log_info(f"[LOAD_BALANCER]   - Token {token_id}: {reason}")

        if not available_tokens:
            log_info(f"[LOAD_BALANCER] ❌ 没有可用的Token (图片生成={for_image_generation}, 视频生成={for_video_generation})")
            return None

        # 最低 in-flight 优先；有并发上限时，剩余槽位更多的 token 优先；最后随机打散
        call_mode = config.call_logic_mode
        if call_mode == "polling":
            # A Cookie jar serializes all RPC stages. Round robin across stale
            # entries used to restart at the first usable id, concentrating load.
            # Balance complete pending pipelines among currently ready accounts.
            ready = [item for item in available_tokens if not item["needs_refresh"]]
            if ready:
                available_tokens = ready
            if for_image_generation:
                least_load = min(item["inflight"] for item in available_tokens)
                available_tokens = [item for item in available_tokens
                    if item["inflight"] == least_load]
            scenario = "default"
            if for_image_generation:
                scenario = "image"
            elif for_video_generation:
                scenario = "video"

            ordered_candidates = []
            first_candidate = await self._select_round_robin(available_tokens, scenario)
            if first_candidate is not None:
                ordered_candidates.append(first_candidate)
                ordered_candidates.extend(
                    item for item in sorted(available_tokens, key=lambda item: item["token"].id or 0)
                    if item["token"].id != first_candidate["token"].id
                )
            available_tokens = ordered_candidates
        else:
            available_tokens.sort(
                key=lambda item: (
                    1 if item["needs_refresh"] else 0,
                    item["inflight"],
                    0 if item["remaining"] is None else 1,
                    -(item["remaining"] or 0),
                    item["random"]
                )
            )

        ready_candidates = [item for item in available_tokens if not item["needs_refresh"]]
        refresh_candidates = [item for item in available_tokens if item["needs_refresh"]]
        if ready_candidates and refresh_candidates:
            available_tokens = ready_candidates + refresh_candidates

        log_info("[LOAD_BALANCER] 候选Token负载:")
        for item in available_tokens:
            token = item["token"]
            remaining = "unlimited" if item["remaining"] is None else item["remaining"]
            log_info(
                f"[LOAD_BALANCER]   - Token {token.id} ({token.email}) "
                f"inflight={item['inflight']}, remaining={remaining}, "
                f"needs_refresh={item['needs_refresh']}, credits={token.credits}"
            )

        # 只为候选列表中真正尝试到的 token 做 AT 校验，避免每次请求把所有 token 全扫一遍
        for item in available_tokens:
            token = item["token"]
            token_id = token.id

            token = await self.token_manager.ensure_valid_token(token)
            if not token:
                log_info(f"[LOAD_BALANCER] 跳过 Token {token_id}: AT无效或已过期")
                continue

            if reserve and not await self._reserve_slot(token.id, for_image_generation, for_video_generation):
                log_info(f"[LOAD_BALANCER] 跳过 Token {token.id}: 预占槽位失败")
                continue

            if track_pending:
                await self._add_pending(token.id, for_image_generation, for_video_generation)

            log_info(
                f"[LOAD_BALANCER] ✅ 已选择Token {token.id} ({token.email}) - "
                f"余额: {token.credits}, inflight={item['inflight']}"
            )
            return token

        log_info(f"[LOAD_BALANCER] ❌ 候选Token均不可用 (图片生成={for_image_generation}, 视频生成={for_video_generation})")
        return None

    async def get_unavailable_reason(
        self,
        *,
        for_image_generation: bool = False,
        for_video_generation: bool = False,
        model: Optional[str] = None,
        model_quota_key: Optional[str] = None,
    ) -> Optional[str]:
        """给出更明确的“无可用账号”原因，优先用于分辨率/tier 档位提示。"""
        active_tokens = await self.token_manager.get_active_tokens()
        if not active_tokens:
            return None

        if for_video_generation:
            active_tokens = [token for token in active_tokens
                if token.id not in self.token_manager.cookie_auth.cache]
            if not active_tokens:
                return "当前 Cookie 会话尚未支持视频生成。"
        required_tier = get_required_paygate_tier_for_model(model)
        supported_tokens = []
        reserved_ultra = 0
        for token in active_tokens:
            normalized_tier = normalize_user_paygate_tier(token.user_paygate_tier)
            if ultra_reserved_for_4k_image(
                normalized_tier, model, for_image_generation=for_image_generation,
            ):
                reserved_ultra += 1
                continue
            if model and not supports_model_for_tier(model, normalized_tier):
                continue
            supported_tokens.append(token)

        if model and not supported_tokens:
            if reserved_ultra:
                return "Ultra 账号已预留给 4K 图片，当前没有可调度的其他账号。"
            tier_label = get_paygate_tier_label(required_tier)
            return f"当前模型需要 {tier_label} 账号，但没有可用的 {tier_label} 账号: {model}"

        capability_tokens = []
        for token in supported_tokens:
            if for_image_generation and not token.image_enabled:
                continue
            if for_video_generation and not token.video_enabled:
                continue
            capability_tokens.append(token)

        breaker_cooled_ids = await self.token_manager.get_token_ids_in_model_cooldown(
            "ACCOUNT_BREAKER"
        )
        if capability_tokens and all(token.id in breaker_cooled_ids for token in capability_tokens):
            return "符合档位的账号均在连续错误冷却中，冷却结束后自动恢复调度。"

        cooled_token_ids = set()
        if model_quota_key:
            cooled_token_ids = await self.token_manager.get_token_ids_in_model_cooldown(
                model_quota_key
            )
        if capability_tokens and all(token.id in cooled_token_ids for token in capability_tokens):
            return "当前模型族的所有可用账号均处于每日额度冷却中，其他模型仍可调度。"

        if supported_tokens and not capability_tokens:
            if for_image_generation:
                return "当前有符合档位的账号，但图片生成功能已全部禁用。"
            if for_video_generation:
                return "当前有符合档位的账号，但视频生成功能已全部禁用。"

        return None

    async def get_unavailable_diagnostic(
        self, *, model: Optional[str], model_quota_key: Optional[str],
    ) -> dict:
        """Return only aggregate, fixed-enum reasons for an unsuccessful image selection."""
        tokens = await self.token_manager.get_active_tokens()
        counts = Counter()
        counts["active"] = len(tokens)
        quota_ids = (
            await self.token_manager.get_token_ids_in_model_cooldown(model_quota_key)
            if model_quota_key else set()
        )
        breaker_ids = await self.token_manager.get_token_ids_in_model_cooldown(
            "ACCOUNT_BREAKER"
        )
        eligible_ids = set()
        for token in tokens:
            if ultra_reserved_for_4k_image(
                token.user_paygate_tier, model, for_image_generation=True,
            ):
                counts["ultra_reserved_for_4k"] += 1
            elif model and not supports_model_for_tier(
                model, normalize_user_paygate_tier(token.user_paygate_tier)
            ):
                counts["tier_missing"] += 1
            elif not token.image_enabled:
                counts["image_disabled"] += 1
            else:
                eligible_ids.add(token.id)
                if token.id in breaker_ids:
                    counts["breaker_cooldown"] += 1
                elif token.id in quota_ids:
                    counts["daily_quota_cooldown"] += 1
                else:
                    route_ok, _ = await self._check_extension_route(token)
                    counts["candidate" if route_ok else "route_unavailable"] += 1

        reason = "unknown"
        if tokens and counts["ultra_reserved_for_4k"] == len(tokens):
            reason = "ultra_reserved_for_4k"
        elif tokens and counts["tier_missing"] == len(tokens):
            reason = "tier_missing"
        elif counts["candidate"]:
            reason = "session_invalid"
        else:
            for candidate in (
                "daily_quota_cooldown", "breaker_cooldown", "route_unavailable"
            ):
                if counts[candidate]:
                    reason = candidate
                    break

        result = {
            "reason": reason,
            "filter_counts": {key: int(counts[key]) for key in (
                "active", "ultra_reserved_for_4k", "tier_missing", "image_disabled", "breaker_cooldown",
                "daily_quota_cooldown", "route_unavailable", "candidate",
            )},
        }
        if reason in {"daily_quota_cooldown", "breaker_cooldown"}:
            try:
                cooldowns = await self.token_manager.db.get_model_cooldowns()
                key = model_quota_key if reason == "daily_quota_cooldown" else "ACCOUNT_BREAKER"
                deadlines = []
                for entry in cooldowns:
                    if entry.get("model_key") != key or entry.get("token_id") not in eligible_ids:
                        continue
                    until = datetime.fromisoformat(str(entry.get("cooling_until")))
                    if until.tzinfo is None:
                        until = until.replace(tzinfo=timezone.utc)
                    deadlines.append(until)
                if deadlines:
                    wait = (min(deadlines) - datetime.now(timezone.utc)).total_seconds()
                    result["retry_after_seconds"] = max(1, int(wait + 0.999))
            except (AttributeError, TypeError, ValueError):
                pass
        return result
