"""Explicit Cookie auth lifecycle, independent of real legacy bearer tokens.

Only an authenticated operator supplies existing, freshly reconciled bindings.
No enrollment by email discovery, no account enablement, no credential solving.
Network reads have durable intents; a database CAS rejects changed bindings.
"""
import asyncio
import hashlib
import json
import time
import uuid

from .flow_cookie_rpc import CookieTransport, ProtocolError

AUTH_MODE = 'google_cookie_rpc'
CHECK_INTERVAL = 3600
POLICY_TTL = 600
REFRESH_AHEAD = 300
READ_TRANSIENT_ERRORS = {'rpc_transport_unavailable_curl_' + str(n)
    for n in (6, 7, 18, 28, 35, 52, 55, 56, 92)}
MANUAL_ERRORS = {'bootstrap_identity_mismatch', 'bootstrap_auth_fields_missing',
    'bootstrap_missing', 'existing_project_not_unique', 'credits_tier_changed',
    'rpc_http_401', 'rpc_http_403', 'bootstrap_http_302', 'bootstrap_http_303',
    'bootstrap_http_401', 'bootstrap_http_403', 'rpc_provider_error'}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


def binding(token):
    fields = {name: getattr(token, name, None) for name in (
        'id', 'email', 'current_project_id', 'proxy_url', 'captcha_proxy_url',
        'user_paygate_tier', 'is_active', 'image_enabled', 'auto_refresh_enabled',
        'ban_reason', 'banned_at')}
    for name in ('is_active', 'image_enabled', 'auto_refresh_enabled'):
        fields[name] = bool(fields[name])
    fields['email'] = str(fields['email'] or '').lower().strip()
    return digest(fields)


def allowed(token):
    return bool(token and token.is_active and token.image_enabled
        and token.auto_refresh_enabled and not token.ban_reason and not token.banned_at)


def safe(row):
    if not row:
        return None
    return {k: row[k] for k in ('token_id', 'profile_id', 'auth_mode', 'status',
        'checked_at', 'next_check_at', 'policy_until', 'last_error', 'revision',
        'generation_ready')}


class CookieAuth:
    def __init__(self, db, transport_factory=CookieTransport):
        self.db = db
        self.transport_factory = transport_factory
        self.cache = {}
        self._initialized = False
        self._init_lock = asyncio.Lock()
        self._locks = {}

    async def initialize(self):
        async with self._init_lock:
            if self._initialized:
                return
            async with self.db._connect(write=True) as db:
                await db.execute('''CREATE TABLE IF NOT EXISTS flow_cookie_sessions (
                    token_id INTEGER PRIMARY KEY REFERENCES tokens(id) ON DELETE CASCADE,
                    profile_id INTEGER NOT NULL, record_id TEXT NOT NULL,
                    auth_mode TEXT NOT NULL DEFAULT 'google_cookie_rpc',
                    email TEXT NOT NULL, project_id TEXT NOT NULL, proxy_url TEXT NOT NULL,
                    binding_sha TEXT NOT NULL, source_sha TEXT NOT NULL,
                    cookies TEXT NOT NULL, status TEXT NOT NULL,
                    checked_at REAL NOT NULL, next_check_at REAL NOT NULL,
                    policy_until REAL NOT NULL, last_error TEXT NOT NULL DEFAULT '',
                    revision INTEGER NOT NULL DEFAULT 1,
                    generation_ready INTEGER NOT NULL DEFAULT 0)''')
                await db.execute('''CREATE TABLE IF NOT EXISTS flow_cookie_auth_attempts (
                    attempt_id TEXT PRIMARY KEY, token_id INTEGER NOT NULL,
                    started_at REAL NOT NULL, finished_at REAL,
                    status TEXT NOT NULL, code TEXT NOT NULL DEFAULT '')''')
                await db.commit()
            self._initialized = True

    async def rows(self):
        await self.initialize()
        async with self.db._connect() as db:
            cursor = await db.execute('SELECT * FROM flow_cookie_sessions')
            names = [x[0] for x in cursor.description]
            rows = [dict(zip(names, values)) for values in await cursor.fetchall()]
        self.cache = {r['token_id']: r for r in rows}
        return rows

    async def get(self, token_id):
        # Never return stale enabled/identity/route state from an in-process cache.
        await self.rows()
        return self.cache.get(int(token_id))

    async def authorize(self, grants, fetched_at):
        """Refresh only existing exact bindings' short policy leases."""
        now = time.time()
        if not now - POLICY_TTL <= fetched_at <= now + 30:
            raise ProtocolError('fresh_policy_required')
        await self.initialize()
        valid = {}
        for grant in grants:
            token = await self.db.get_token(int(grant['token_id']))
            if allowed(token) and binding(token) == grant['binding_sha']:
                valid[int(grant['token_id'])] = grant
        async with self.db._connect(write=True) as db:
            # Omitted, disabled, excluded or changed identities lose their lease.
            await db.execute('UPDATE flow_cookie_sessions SET policy_until=0')
            for tid, grant in valid.items():
                await db.execute('''UPDATE flow_cookie_sessions SET policy_until=?
                    WHERE token_id=? AND profile_id=? AND record_id=? AND binding_sha=?''',
                    (fetched_at + POLICY_TTL, tid, grant['profile_id'],
                     grant['record_id'], grant['binding_sha']))
            await db.commit()
        return {'authorized': len(valid)}

    def session_lock(self, token_id):
        """Serialize refresh, credits and media use of the same Cookie jar."""
        return self._locks.setdefault(int(token_id), asyncio.Lock())

    async def accept(self, payload, *, retained=False, refresh_before=0):
        """Authenticate an exact existing source snapshot, then CAS its context."""
        tid = int(payload['token_id'])
        async with self.session_lock(tid):
            return await self._accept(payload, retained=retained, refresh_before=refresh_before)

    async def _accept(self, payload, *, retained=False, refresh_before=0):
        now = time.time()
        fetched = float(payload['policy_fetched_at'])
        if not now - POLICY_TTL <= fetched <= now + 30:
            raise ProtocolError('fresh_policy_required')
        token = await self.db.get_token(int(payload['token_id']))
        if not allowed(token) or binding(token) != payload['binding_sha']:
            raise ProtocolError('account_binding_changed')
        if (str(token.email).lower().strip() != str(payload['email']).lower().strip()
                or token.current_project_id != payload['project_id']
                or token.proxy_url != payload['proxy_url']):
            raise ProtocolError('account_binding_changed')
        projects = await self.db.get_projects_by_token(token.id)
        if sum(p.project_id == token.current_project_id and p.is_active for p in projects) != 1:
            raise ProtocolError('existing_project_not_unique')
        previous = await self.get(token.id)
        if previous and (previous['profile_id'] != int(payload['profile_id'])
                or previous['record_id'] != payload['record_id']):
            raise ProtocolError('source_binding_changed')
        if previous and previous['status'] == 'manual_required':
            raise ProtocolError('persistent_cookie_auth_hold')
        if previous and previous['status'] == 'retry_later' and previous['next_check_at'] > now:
            raise ProtocolError('cookie_auth_backoff')
        revision = previous['revision'] if previous else 0
        source_sha = previous['source_sha'] if retained and previous else digest(payload['cookies'])
        if (previous and previous['status'] == 'verified'
                and previous['binding_sha'] == payload['binding_sha']
                and previous['source_sha'] == source_sha
                and previous['next_check_at'] > now + max(0, min(REFRESH_AHEAD, refresh_before))):
            return {**safe(previous), 'cached': True, 'at_renewed': False}
        raw = (previous['cookies'] if previous and previous['source_sha'] == source_sha
            else payload['cookies'])
        attempt = str(uuid.uuid4())
        # Cross-process exclusion survives a restart. Only read-only operations
        # can resume after a dead intent's five-minute deadline.
        async with self.db._connect(write=True) as db:
            await db.execute('BEGIN IMMEDIATE')
            held = await (await db.execute('''SELECT 1 FROM flow_cookie_auth_attempts
                WHERE token_id=? AND status='manual_required' LIMIT 1''', (token.id,))).fetchone()
            if held:
                raise ProtocolError('persistent_cookie_auth_hold')
            busy = await (await db.execute('''SELECT 1 FROM flow_cookie_auth_attempts
                WHERE token_id=? AND status='checking' AND started_at>?''',
                (token.id, now - 300))).fetchone()
            if busy:
                raise ProtocolError('cookie_auth_inflight')
            await db.execute("UPDATE flow_cookie_auth_attempts SET status='interrupted',finished_at=? WHERE token_id=? AND status='checking'", (now, token.id))
            await db.execute('INSERT INTO flow_cookie_auth_attempts VALUES(?,?,?,NULL,?,?)',
                (attempt, token.id, now, 'checking', ''))
            await db.commit()
        try:
            # Only identity/project/credits reads repeat on a known transport
            # failure. This path never solves CAPTCHA or submits media.
            for read_attempt in range(2):
                try:
                    async with self.transport_factory(raw, token.email, token.proxy_url) as transport:
                        result = await transport.verify(token.current_project_id)
                    break
                except ProtocolError as error:
                    if read_attempt or str(error) not in READ_TRANSIENT_ERRORS:
                        raise
                    await asyncio.sleep(0.5)
            if result['userPaygateTier'] != token.user_paygate_tier:
                raise ProtocolError('credits_tier_changed')
            checked = time.time()
            if checked > fetched + POLICY_TTL:
                raise ProtocolError('policy_expired_before_commit')
            async with self.db._connect(write=True) as db:
                await db.execute('BEGIN IMMEDIATE')
                # Recheck under the same transaction as the credential write.
                cursor = await db.execute('SELECT * FROM tokens WHERE id=?', (token.id,))
                values = await cursor.fetchone()
                from types import SimpleNamespace
                latest = SimpleNamespace(**dict(zip([x[0] for x in cursor.description], values))) if values else None
                if latest is None or binding(latest) != payload['binding_sha']:
                    raise ProtocolError('account_binding_changed')
                current = await (await db.execute('SELECT revision FROM flow_cookie_sessions WHERE token_id=?', (token.id,))).fetchone()
                if (current[0] if current else 0) != revision:
                    raise ProtocolError('cookie_auth_revision_changed')
                ready = previous['generation_ready'] if previous else 0
                await db.execute('''INSERT OR REPLACE INTO flow_cookie_sessions
                    (token_id,profile_id,record_id,email,project_id,proxy_url,binding_sha,
                     source_sha,cookies,status,checked_at,next_check_at,policy_until,
                     last_error,revision,generation_ready)
                    VALUES(?,?,?,?,?,?,?,?,?,'verified',?,?,?,'',?,?)''',
                    (token.id, int(payload['profile_id']), payload['record_id'], token.email,
                     token.current_project_id, token.proxy_url, payload['binding_sha'], source_sha,
                     result['cookies'], checked, checked + CHECK_INTERVAL, fetched + POLICY_TTL,
                     revision + 1, ready))
                await db.execute('UPDATE tokens SET credits=? WHERE id=?', (result['credits'], token.id))
                await db.execute("UPDATE flow_cookie_auth_attempts SET status='verified',finished_at=? WHERE attempt_id=?", (checked, attempt))
                await db.commit()
            row = await self.get(token.id)
            return {**safe(row), 'identity_exact': True, 'existing_project_exact': True,
                'credits': result['credits'], 'userPaygateTier': result['userPaygateTier'],
                'at_renewed': False}
        except Exception as error:
            code = str(error) if isinstance(error, ProtocolError) else 'auth_internal_' + type(error).__name__
            state = 'manual_required' if code in MANUAL_ERRORS else 'retry_later'
            async with self.db._connect(write=True) as db:
                await db.execute('''UPDATE flow_cookie_auth_attempts
                    SET status=?,finished_at=?,code=? WHERE attempt_id=?''',
                    (state, time.time(), code, attempt))
                await db.execute('''UPDATE flow_cookie_sessions SET status=?,last_error=?,
                    next_check_at=? WHERE token_id=? AND revision=?''',
                    (state, code, time.time() + 300, token.id, revision))
                await db.commit()
            raise ProtocolError(code) from None

    async def usable(self, token, *, require_generation=True):
        row = await self.get(token.id)
        if not row or not allowed(token) or binding(token) != row['binding_sha']:
            return False
        if row['policy_until'] < time.time() or row['status'] != 'verified':
            return False
        if require_generation and getattr(token, 'st', '<legacy>') is None:
            from .cookie_native import admitted
            if not await admitted(self.db, token.id):
                return False
        if require_generation and not row['generation_ready']:
            return False
        return row['next_check_at'] >= time.time()

    async def _refresh_locked(self, token_id, *, refresh_before=0):
        row = await self.get(token_id)
        if not row or row['policy_until'] < time.time():
            raise ProtocolError('fresh_policy_required')
        return await self._accept({'token_id':row['token_id'], 'profile_id':row['profile_id'],
            'record_id':row['record_id'], 'email':row['email'], 'project_id':row['project_id'],
            'proxy_url':row['proxy_url'], 'binding_sha':row['binding_sha'],
            'cookies':row['cookies'], 'policy_fetched_at':row['policy_until']-POLICY_TTL},
            retained=True, refresh_before=refresh_before)

    async def refresh(self, token_id, *, refresh_before=0):
        async with self.session_lock(token_id):
            return await self._refresh_locked(token_id, refresh_before=refresh_before)

    async def maintain_media_locked(self, token_id):
        """Called under the shared jar lock, before any media solve/dispatch."""
        row = await self.get(token_id)
        if (row and row['status'] == 'verified' and row['policy_until'] > time.time()
                and row['next_check_at'] <= time.time() + 120):
            return await self._refresh_locked(token_id, refresh_before=120)
        return None

    async def run_once(self, maximum=3):
        rows = await self.rows()
        now = time.time()
        due = sorted((row for row in rows if row['policy_until'] > now
            and row['status'] != 'manual_required'
            and row['next_check_at'] <= now + (REFRESH_AHEAD if row['status'] == 'verified' else 0)
            and not self.session_lock(row['token_id']).locked()),
            key=lambda row: row['next_check_at'])

        async def check(row):
            # No await between this test and acquiring the lock in refresh.
            # A busy media jar must not stall the other independent accounts.
            if self.session_lock(row['token_id']).locked():
                return {'token_id': row['token_id'], 'status': 'media_busy'}
            try:
                value = await self.refresh(row['token_id'], refresh_before=REFRESH_AHEAD)
                return {'token_id': row['token_id'], 'status': value['status']}
            except ProtocolError as error:
                return {'token_id': row['token_id'], 'status': str(error)}

        return list(await asyncio.gather(*(check(row) for row in due[:max(1, min(3, maximum))])))
