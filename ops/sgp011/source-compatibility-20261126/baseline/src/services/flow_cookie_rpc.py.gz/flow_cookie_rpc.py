"""Strict Flow Cookie RPC authentication. Never manufactures a bearer AT.

The read allowlist is based on observed public frontend declarations. Session
check freshness is independent of provider cookie expiry and legacy AT expiry.
Exceptions contain fixed codes only: no response bodies or credentials.
"""
import json
import math
import re
import time
import urllib.parse
from http.cookiejar import Cookie, CookieJar


def cookie_jar(raw):
    jar = CookieJar()
    for item in scoped_cookies(raw):
        domain = item['domain']
        jar.set_cookie(Cookie(0, item['name'], item['value'], None, False,
            domain, domain.startswith('.'), domain.startswith('.'),
            item['path'], True, bool(item['secure']),
            None if item['expires'] == -1 else int(item['expires']),
            item['expires'] == -1, None, None,
            {'HttpOnly': item['httpOnly'], 'SameSite': item['sameSite']}, False))
    return jar


def export_jar(jar):
    return json.dumps([{'name': c.name, 'value': c.value, 'domain': c.domain,
        'path': c.path, 'secure': c.secure, 'httpOnly': bool(c._rest.get('HttpOnly')),
        'sameSite': c._rest.get('SameSite', 'Lax'),
        'expires': c.expires if c.expires is not None else -1}
        for c in jar if not c.is_expired()], separators=(',', ':'))


def transport_diagnostic(call, result, error, elapsed):
    """Fixed transport evidence only; missing instrumentation stays unknown."""
    diagnostic = {'duration_ms': round(max(0, elapsed) * 1000, 3),
                  'response_complete': result is not None}
    code = re.fullmatch(r'rpc_transport_unavailable_curl_([0-9]{1,3})', str(error or ''))
    if code:
        diagnostic['curl_code'] = int(code[1])
    status = getattr(result, 'status_code', None)
    if type(status) is int:
        diagnostic['http_status'] = status
    if call is not None:
        counts = getattr(call, 'counts', {}) or {}
        for source, target in [('4', 'request_data_bytes'), ('3', 'response_data_bytes')]:
            value = counts.get(source)
            if type(value) is int and value >= 0:
                diagnostic[target] = value
        # A client completion marker does not prove Google accepted the RPC.
        events = getattr(call, 'events', []) or []
        sent = any(isinstance(e, dict) and any(marker in str(e.get('text', '')).lower()
                   for marker in ('upload completely sent off', 'request completely sent off'))
                   for e in events)
        if sent:
            diagnostic['request_body_send_complete'] = True
        if diagnostic.get('curl_code') == 28:
            diagnostic['timeout_phase'] = ('waiting_response' if sent and not counts.get('3')
                                           else 'receiving_response' if counts.get('3')
                                           else 'unresolved_transport')
    return diagnostic


class CookieTransport:
    """One session's scoped cookie jar; each dispatch occurs exactly once."""

    def __init__(self, raw_cookies, email, proxy_url):
        self.jar = cookie_jar(raw_cookies)
        self.email = email
        parsed = urllib.parse.urlsplit(proxy_url)
        if parsed.scheme not in ('http', 'https', 'socks5', 'socks5h') or not parsed.hostname:
            raise ProtocolError('explicit_profile_proxy_required')
        self.proxy_url = proxy_url
        self.auth = None
        self.session = None

    async def __aenter__(self):
        from curl_cffi import CurlInfo
        from curl_cffi.requests import AsyncSession
        self.session = AsyncSession(cookies=self.jar, impersonate='chrome',
            proxy=self.proxy_url, timeout=30, curl_infos=[CurlInfo.COOKIELIST])
        return self

    async def __aexit__(self, *_):
        if self.session:
            await self.session.close()

    async def dispatch(self, method, url, *, max_body=None, **kwargs):
        from curl_cffi import CurlInfo
        from curl_cffi.requests import Cookies
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or parsed.hostname != 'flow.google.com' or parsed.port:
            raise ProtocolError('rpc_origin_rejected')
        limit = MAX_BODY if max_body is None else max_body
        if not isinstance(limit, int) or isinstance(limit, bool) or not MAX_BODY <= limit <= MAX_MEDIA_BODY:
            raise ProtocolError('rpc_body_limit_invalid')
        if limit != MAX_BODY and (method != 'POST' or parsed.path != RPC_PATH
                or urllib.parse.parse_qs(parsed.query).get('rpcids') not in (['ogiZ0b'], ['maseQ'], ['SPrCad'])):
            raise ProtocolError('rpc_media_body_limit_not_allowed')
        headers = {'Origin': ORIGIN, 'Referer': ORIGIN + '/'}
        headers.update(kwargs.pop('headers', {}))
        # Context-local instrumentation only. No disk/IPC setup or await is
        # introduced between a synchronous solver token and the single POST.
        from . import google_failure_evidence as evidence
        call = None
        try:
            call = evidence.new_call(method, url, headers, body=kwargs.get('data'),
                stage='cookie_rpc_' + (urllib.parse.parse_qs(parsed.query).get('rpcids') or ['bootstrap'])[0])
            if call is not None:
                call.rpc_form = method == 'POST' and parsed.path == RPC_PATH
                call.secrets.extend(c.value for c in self.jar if len(c.value) >= 6)
                call.attach(self.session)
                self.session.curl_infos = list(set(self.session.curl_infos or []) | set(evidence.EXTRA_INFOS))
        except Exception:
            if call is not None:
                call.chain.issues.append('rpc_capture_setup_failed')
        result = None
        failure = None
        started = time.monotonic()
        try:
            result = await self.session.request(method, url, allow_redirects=False,
                headers=headers, **kwargs)
        except BaseException as error:
            failure = error
            if isinstance(error, Exception):
                code = re.search(r'curl: \(([0-9]+)\)', str(error))
                suffix = '_curl_' + code.group(1) if code else '_' + type(error).__name__
                failure = ProtocolError('rpc_transport_unavailable' + suffix)
                raise failure from None
            raise
        finally:
            transport = transport_diagnostic(call, result, failure, time.monotonic() - started)
            self.last_rpc_transport = transport
            if failure is not None:
                failure.rpc_transport_diagnostic = transport
            if call is not None:
                call.detach(self.session)
                await evidence.finish_call(call, result, failure,
                    {'auth_mode': 'google_cookie_rpc', 'response_complete': result is not None,
                     'account_id': getattr(self, 'evidence_account_id', None),
                     'proxy': evidence.clean_url(self.proxy_url),
                     'submission_outcome': 'http_response_unparsed' if result is not None else 'unknown'},
                    partial=getattr(getattr(failure, 'response', None), 'content', None))
        return self._receive(result, limit, CurlInfo, Cookies)

    def _receive(self, result, limit, CurlInfo, Cookies):
        """Validate the one received response without another dispatch."""
        if len(result.content) > limit:
            raise ProtocolError('rpc_body_too_large')
        # libcurl's current jar is authoritative, including cookie deletion.
        # Do not merge a stale Python jar over a Set-Cookie expiry/deletion.
        lines = result.infos.get(CurlInfo.COOKIELIST)
        if lines is None:
            # Absence of instrumentation is not an authoritative empty jar.
            raise ProtocolError('rpc_cookie_snapshot_unavailable')
        current = Cookies()
        from curl_cffi.requests.cookies import CurlMorsel
        for line in lines:
            current.update_cookies_from_curl([CurlMorsel.from_curl_format(line)])
        self.jar.clear()
        for cookie in current.jar:
            self.jar.set_cookie(cookie)
        self.session.cookies = Cookies(self.jar)
        return result

    async def load(self):
        result = await self.dispatch('GET', ORIGIN + '/')
        if result.status_code != 200:
            raise ProtocolError('bootstrap_http_' + str(result.status_code))
        self.auth = bootstrap(result.text, self.email)

    async def rpc(self, rpc_id, payload):
        if self.auth is None:
            await self.load()
        url, form = request(rpc_id, payload, self.auth)
        result = await self.dispatch('POST', url, data=form)
        return response(result.text, rpc_id, result.status_code)

    async def verify(self, project_id):
        await self.load()
        values = credits(await self.rpc('nzlxg', []))
        project = existing_project(await self.rpc('UpteDb', ['projects/*', 21]), project_id)
        updated = export_jar(self.jar)
        scoped_cookies(updated)
        return {**values, **project, 'identity_exact': True, 'cookies': updated}


ORIGIN = 'https://flow.google.com'
RPC_PATH = '/_/AiSandboxAngularFrontend/data/batchexecute'
READ_METHODS = {
    'nzlxg': '/VideoFxService.GetCredits',
    'cPZSdc': '/VideoFxService.GetFlowAppConfig',
    'rThb8d': '/VideoFxService.CheckFlowAvailability',
    'Hnrtob': '/FlowService.GetProject',
    'okjlg': '/FlowService.ListProjects',
    'UpteDb': '/FlowService.GetProjects',
}
MAX_BODY = 4 * 1024 * 1024
# A 64 MiB decoded image can occupy about 86 MiB in a base64 RPC envelope.
MAX_MEDIA_BODY = 96 * 1024 * 1024
# Public provider enum wza, rather than inferring paid tier from balance.
PAYGATE_TIERS = {
    0: 'PAYGATE_TIER_UNSPECIFIED', 5: 'PAYGATE_TIER_ZERO',
    1: 'PAYGATE_TIER_ONE', 7: 'PAYGATE_TIER_GEMNOVA',
    2: 'PAYGATE_TIER_TWO', 3: 'PAYGATE_TIER_NOT_PAID',
    4: 'PAYGATE_TIER_UNSUBSCRIBED_WITH_CREDITS',
    6: 'PAYGATE_TIER_EXEMPT', 8: 'PAYGATE_TIER_TIER1P5',
}


class ProtocolError(RuntimeError):
    """Only fixed, nonsecret codes belong in this exception."""


def scoped_cookies(raw, now=None):
    """Preserve cookie scope/expiry; do not turn expired cookies into sessions."""
    try:
        raw = json.loads(raw) if isinstance(raw, str) else raw
    except (ValueError, TypeError):
        raise ProtocolError('cookies_invalid') from None
    if isinstance(raw, dict):
        raw = raw.get('cookies')
    if not isinstance(raw, list):
        raise ProtocolError('cookies_invalid')
    current = time.time() if now is None else now
    out = {}
    for cookie in raw:
        if not isinstance(cookie, dict) or cookie.get('partitionKey'):
            continue
        if cookie.get('domain', '').lstrip('.') not in (
                'google.com', 'accounts.google.com', 'flow.google.com', 'www.google.com'):
            continue
        if not all(isinstance(cookie.get(k), str) and cookie[k] for k in ('name', 'value')):
            continue
        path = cookie.get('path', '/')
        if not isinstance(path, str) or not path.startswith('/'):
            continue
        try:
            expiry = float(cookie.get('expires', cookie.get('expirationDate', -1)))
        except (ValueError, TypeError):
            continue
        if not math.isfinite(expiry) or (expiry != -1 and expiry <= current):
            continue
        item = {k: cookie[k] for k in ('name', 'value', 'domain', 'secure', 'httpOnly') if k in cookie}
        item.update(path=path, expires=expiry, sameSite=cookie.get('sameSite', 'Lax'))
        item.setdefault('secure', True)
        item.setdefault('httpOnly', False)
        if item['sameSite'] not in ('Strict', 'Lax', 'None'):
            item['sameSite'] = 'Lax'
        key = (item['name'], item['domain'], item['path'])
        if key in out and out[key] != item:
            raise ProtocolError('cookies_scope_conflict')
        out[key] = item
    if not out:
        raise ProtocolError('cookies_missing')
    return list(out.values())


def bootstrap(body, expected_email):
    """Require the exact account in provider bootstrap, not arbitrary HTML."""
    if not isinstance(expected_email, str) or '@' not in expected_email:
        raise ProtocolError('expected_identity_missing')
    if len(body.encode()) > MAX_BODY:
        raise ProtocolError('bootstrap_too_large')
    match = re.search(r'window\.WIZ_global_data\s*=\s*(\{.*?\});', body, re.S)
    if not match:
        raise ProtocolError('bootstrap_missing')
    try:
        data = json.loads(match.group(1))
    except (ValueError, TypeError):
        raise ProtocolError('bootstrap_invalid') from None
    expected = expected_email.lower().strip()
    # oPEP7c is the provider's exact signed-in email, observed on new Flow.
    if str(data.get('oPEP7c', '')).lower().strip() != expected:
        raise ProtocolError('bootstrap_identity_mismatch')
    for field in ('SNlM0e', 'FdrFJe', 'cfb2h'):
        if not isinstance(data.get(field), str) or not data[field]:
            raise ProtocolError('bootstrap_auth_fields_missing')
    return {key: data[key] for key in ('SNlM0e', 'FdrFJe', 'cfb2h')}


def request(rpc_id, payload, auth, *, allowed=None):
    """One allowed RPC per request; never retry a dispatch in this layer."""
    if rpc_id not in (READ_METHODS if allowed is None else allowed) or not isinstance(payload, list):
        raise ProtocolError('rpc_not_allowed')
    query = urllib.parse.urlencode({'rpcids': rpc_id, 'source-path': '/',
        'f.sid': auth['FdrFJe'], 'bl': auth['cfb2h'], 'hl': 'en', 'rt': 'c'})
    calls = [[[rpc_id, json.dumps(payload, separators=(',', ':')), None, 'generic']]]
    form = {'f.req': json.dumps(calls, separators=(',', ':')), 'at': auth['SNlM0e']}
    return ORIGIN + RPC_PATH + '?' + query, form


def response(body, rpc_id, status=200, *, allowed=None, max_body=None):
    """Parse framed JSON, reject server errors even when HTTP is 200."""
    if rpc_id not in (READ_METHODS if allowed is None else allowed):
        raise ProtocolError('rpc_not_allowed')
    if status != 200:
        raise ProtocolError('rpc_http_' + str(int(status)))
    limit = MAX_BODY if max_body is None else max_body
    if not isinstance(limit, int) or isinstance(limit, bool) or not MAX_BODY <= limit <= MAX_MEDIA_BODY:
        raise ProtocolError('rpc_body_limit_invalid')
    if limit != MAX_BODY and (allowed is None or rpc_id not in {'ogiZ0b', 'maseQ', 'SPrCad'}):
        raise ProtocolError('rpc_media_body_limit_not_allowed')
    if not isinstance(body, str) or len(body.encode()) > limit:
        raise ProtocolError('rpc_body_invalid')
    if not body.startswith(")]}'"):
        raise ProtocolError('rpc_not_framed_json')
    tail = body[4:]
    decoder = json.JSONDecoder()
    rows = []
    while tail.strip():
        tail = tail.lstrip()
        # Decode JSON structurally: response.text() has already decoded the
        # wire encoding. Google responses use byte or UTF-16 string lengths,
        # with up to two line separators; slicing Python strings by that
        # count would corrupt non-ASCII prompts and supplementary characters.
        frame = re.match(r'([0-9]+)\n', tail)
        if frame:
            length = int(frame.group(1))
            raw = tail[frame.end():].lstrip()
            if length <= 0 or length > limit:
                raise ProtocolError('rpc_frame_length_invalid')
            try:
                value, end = decoder.raw_decode(raw)
            except ValueError:
                raise ProtocolError('rpc_frame_invalid') from None
            segment = raw[:end]
            sizes = {len(segment.encode()), len(segment.encode('utf-16-le')) // 2}
            if not any(size <= length <= size + 2 for size in sizes):
                # Counts only; no prompt, credential or provider text.
                raise ProtocolError('rpc_frame_length_invalid_announced_' + str(length)
                    + '_utf8_' + str(len(segment.encode())) + '_utf16_'
                    + str(len(segment.encode('utf-16-le')) // 2))
            tail = raw[end:]
        else:
            try:
                value, end = decoder.raw_decode(tail)
            except ValueError:
                raise ProtocolError('rpc_json_invalid') from None
            tail = tail[end:]
        if not isinstance(value, list):
            raise ProtocolError('rpc_envelope_invalid')
        rows.extend(value)
    found = []
    errors = []
    def provider_error(detail):
        # Keep authentication's durable error classification unchanged. Media
        # diagnostics expose only provider enums from the error slot itself.
        if allowed is not None and rpc_id in {'ogiZ0b', 'maseQ', 'SPrCad'}:
            # Numeric gRPC status is metadata from the exact error slot, NOT
            # an HTTP status or a content/risk reason. Trust it for recovery
            # only after the whole unique response is validated below.
            numeric = detail[0] if isinstance(detail, list) and detail else None
            numeric = numeric if type(numeric) is int and 1 <= numeric <= 16 else None
            names = {3: 'INVALID_ARGUMENT', 4: 'DEADLINE_EXCEEDED', 8: 'RESOURCE_EXHAUSTED', 13: 'INTERNAL'}
            codes = re.findall(r'\bPUBLIC_ERROR_[A-Z0-9_]{1,80}\b',
                json.dumps(detail, ensure_ascii=True))
            if len(set(codes)) == 1:
                error = ProtocolError('rpc_provider_error_' + codes[0])
                error.provider_code = codes[0]
            else:
                error = ProtocolError('rpc_provider_error' + ('_' + names[numeric] if numeric in names else ''))
            error.rpc_method = rpc_id
            error.rpc_public_error_present = bool(codes)
            if numeric is not None:
                error.rpc_status_code = numeric
                error.rpc_status_name = names.get(numeric, 'UNCLASSIFIED')
            return error
        return ProtocolError('rpc_provider_error')
    for row in rows:
        if not isinstance(row, list) or len(row) < 2:
            raise ProtocolError('rpc_row_invalid')
        if row[0] == 'er' and row[1] == rpc_id:
            errors.append(provider_error(row[2:]))
            continue
        if row[:2] != ['wrb.fr', rpc_id]:
            if row[0] in {'wrb.fr', 'er'}:
                raise ProtocolError('rpc_unexpected_identity')
            continue
        if len(row) > 5 and row[5] not in (None, []):
            # A payload alongside an error is ambiguous, never proof of rejection.
            if len(row) > 2 and row[2] not in (None, ''):
                raise ProtocolError('rpc_mixed_result_and_error')
            errors.append(provider_error(row[5]))
            continue
        if len(row) < 3 or not isinstance(row[2], str):
            raise ProtocolError('rpc_result_missing')
        try:
            result = json.loads(row[2])
        except ValueError:
            raise ProtocolError('rpc_result_invalid') from None
        if not isinstance(result, list):
            raise ProtocolError('rpc_result_invalid')
        found.append(result)
    if errors:
        if len(errors) != 1 or found:
            raise ProtocolError('rpc_result_not_unique')
        # Only after validating the entire response and its unique RPC identity
        # can a provider rejection be distinguished from a lost/partial result.
        error = errors[0]
        error.rpc_rejection_confirmed = True
        raise error
    if len(found) != 1:
        raise ProtocolError('rpc_result_not_unique')
    return found[0]


def credits(payload):
    """Decode exact provider fields; never convert positive credits into Pro."""
    if not isinstance(payload, list) or len(payload) < 2:
        raise ProtocolError('credits_schema_unknown')
    balance, tier = payload[:2]
    if not isinstance(tier, int) or isinstance(tier, bool) or tier not in PAYGATE_TIERS:
        raise ProtocolError('credits_tier_unknown')
    # Protobuf's omitted zero balance is accepted only with a known explicit
    # tier and an already authenticated exact-identity RPC envelope.
    if balance is None:
        balance = 0
    if (not isinstance(balance, (int, float)) or isinstance(balance, bool)
            or not math.isfinite(balance) or balance < 0 or int(balance) != balance):
        raise ProtocolError('credits_balance_invalid')
    return {'credits': int(balance), 'userPaygateTier': PAYGATE_TIERS[tier],
            'provider_tier_enum': tier, 'auth_mode': 'google_cookie_rpc', 'at_renewed': False}


def existing_project(payload, project_id):
    """Require the exact project resource in the account's project list."""
    if not isinstance(project_id, str) or not re.fullmatch(
            r'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', project_id):
        raise ProtocolError('expected_project_invalid')
    if not isinstance(payload, list) or not payload or not isinstance(payload[0], list):
        raise ProtocolError('project_schema_unknown')
    names = [x[0] for x in payload[0] if isinstance(x, list) and len(x) >= 2
             and isinstance(x[0], str) and isinstance(x[1], list)]
    matched = sum(name in (project_id, 'projects/' + project_id) for name in names)
    if matched != 1:
        raise ProtocolError('existing_project_not_unique')
    return {'existing_project_exact': True, 'project_count': len(payload[0])}


def shape(value, depth=0):
    """Safe bounded structural description; no strings or identifiers."""
    if depth >= 5:
        return type(value).__name__
    if isinstance(value, list):
        return {'length': len(value), 'fields': [shape(x, depth + 1) for x in value[:14]]}
    if value is None:
        return 'null'
    return type(value).__name__
