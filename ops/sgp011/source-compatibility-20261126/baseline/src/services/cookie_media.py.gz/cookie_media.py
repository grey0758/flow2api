"""Current Flow image contract; bounded, confirmed-rejection CAPTCHA failover.

Media dispatch is deliberately separate from authentication's read allowlist.
No legacy bearer is consumed and no transport/unknown-outcome replay occurs.
"""
import json
import os
import asyncio
import base64
import hashlib
import io
import random
import re
import time
import uuid
from urllib.parse import urlsplit

from src.core.config import config
from .image_recovery import solver_started, solver_finished
from .image_diagnostics import provider_snapshot
from .flow_cookie_rpc import CookieTransport, ProtocolError, export_jar, request, response, credits, MAX_MEDIA_BODY
from .cookie_upload import upload_lease, media_lease, current_group, merge_cookie_delta
from .cookie_capacity import rpc_parallel_enabled
from .upload_first import upload_first_control, upload_first_fallback_reason
from .original_aspect import SPECS as ORIGINAL_SPECS, BASE_ROLE, REFERENCE_ROLE, NATIVE_ASPECT_ENUMS

MEDIA_METHODS = {'ogiZ0b', 'maseQ', 'SPrCad'}
ASPECTS = {'IMAGE_ASPECT_RATIO_SQUARE': 1, 'IMAGE_ASPECT_RATIO_PORTRAIT': 2,
    'IMAGE_ASPECT_RATIO_16_9': 3, 'IMAGE_ASPECT_RATIO_LANDSCAPE': 3,
    'IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE': 5,
    'IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR': 4, **NATIVE_ASPECT_ENUMS}


def media_rpc_timeout_seconds():
    """Use the configured image deadline for Cookie RPC media generation.

    The old path hard-coded 180 seconds even though the service configuration
    allows a 300-second image deadline. A Google RPC response can legitimately
    arrive after 180 seconds while the request remains non-idempotent. This
    helper raises the wait ceiling only within the existing bounded service
    contract; it never enables a second POST or a cross-account replay.
    """
    try:
        configured = int(getattr(config, 'image_timeout', 180) or 180)
    except (TypeError, ValueError):
        configured = 180
    return max(180, min(300, configured))


def upload_rpc_timeout_seconds():
    """Bound only upload RPC time, never infer rejection from a timeout.

    Successful uploads have a separate latency distribution from generation
    and upsample. Solving CAPTCHA and bootstrap remain outside this RPC cap.
    An expired deadline still carries unknown submission evidence and does not
    authorize any solver, upload or generation replay.
    """
    raw = os.getenv('FLOW2API_UPLOAD_RPC_TIMEOUT_SECONDS', '120')
    try:
        configured = int(raw)
    except (TypeError, ValueError):
        configured = 120
    return max(60, min(180, configured))


def media_attempts(trace):
    """Keep each solver attempt visible to the existing outer submission guard."""
    return list(trace.get('previous_attempts', [])) + [
        {k: v for k, v in trace.items() if k != 'previous_attempts'}]


def captcha_failover_reason(error, trace):
    # Cancellation and uncertain submissions must never start another solver.
    if not isinstance(error, Exception) or getattr(error, 'outcome_unknown', False):
        return None
    if not trace.get('dispatch_started'):
        if trace.get('phase') == 'captcha':
            return 'captcha_unavailable_before_dispatch'
        if isinstance(error, ProtocolError) and str(error) in {
                'sync_token_stale', 'sync_token_state_invalid'}:
            return 'captcha_expired_before_dispatch'
        return None
    if (trace.get('response_complete') is True and trace.get('http_status') == 200
            and trace.get('submission_outcome') == 'explicit_provider_rejection'
            and getattr(error, 'rpc_rejection_confirmed', False) is True
            and getattr(error, 'provider_code', None) in {
                'PUBLIC_ERROR_UNUSUAL_ACTIVITY',
                'PUBLIC_ERROR_UNUSUAL_ACTIVITY_TOO_MUCH_TRAFFIC'}):
        return 'explicit_google_risk_rejection'
    return None


def context(project_id, captcha):
    return [None, 22, None, None, None, project_id, None, None, None, None, [captcha, 1]]


def image_argument(project_id, prompt, model, aspect, captcha, session_id, inputs=None):
    original = aspect in ORIGINAL_SPECS and aspect not in NATIVE_ASPECT_ENUMS
    if aspect in NATIVE_ASPECT_ENUMS and model != 'GEM_PIX_2':
        raise ProtocolError('image_original_aspect_contract_unverified')
    if aspect not in ASPECTS and not original:
        raise ProtocolError('image_aspect_unsupported')
    if original and (model != 'GEM_PIX_2' or not inputs
            or inputs[0].get('imageInputType') != BASE_ROLE
            or any(item.get('imageInputType') != REFERENCE_ROLE for item in inputs[1:])):
        raise ProtocolError('image_original_aspect_contract_unverified')
    # Keep the requested model exact. Never silently rewrite an unavailable model.
    if model not in {'BELUGA', 'NARWHAL', 'GEM_PIX', 'GEM_PIX_2', 'HARBOR_SEAL', 'IMAGEN_3_5'}:
        raise ProtocolError('image_model_unsupported')
    refs = []
    for index, item in enumerate(inputs or []):
        name = item.get('name') or item.get('mediaId')
        if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9_./-]{1,512}', name):
            raise ProtocolError('image_reference_invalid')
        refs.append([name, None, None, None, 2 if original and index == 0 else 1])
    ctx = context(project_id, captcha)
    one = [None, None, refs or None, random.randint(1, 2147483647), None if original else ASPECTS[aspect],
        model, None, ctx, [[[prompt]]], None, None, None, session_id, str(uuid.uuid4()).upper()]
    # Official protobuf toJSON (tc) serializes booleans as numeric 1/0.
    return [None, [one], 1, ctx, [session_id]]


def content_url(value):
    if isinstance(value, str):
        p = urlsplit(value)
        if (p.scheme == 'https' and not p.username and not p.password and not p.port
                and (p.hostname in {'flow.google.com', 'flow-content.google', 'storage.googleapis.com'}
                     or (p.hostname or '').endswith('.googleusercontent.com'))
                and '/image/' in p.path):
            return value
    if isinstance(value, list):
        for item in value:
            found = content_url(item)
            if found:
                return found
    return ''


def normalize_image(payload):
    # Official response Ya: repeated media (.bz) in field 1. The declaration's
    # lb is the request, as confirmed by zbb/Abb in the current public editor JS.
    if not isinstance(payload, list) or not payload or not isinstance(payload[0], list):
        raise ProtocolError('image_response_schema_unknown')
    media = []
    for item in payload[0]:
        if not isinstance(item, list) or not item:
            raise ProtocolError('image_response_schema_unknown')
        name, url = item[0], content_url(item)
        if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9_./-]{1,512}', name) or not url:
            raise ProtocolError('image_response_media_missing')
        media.append({'name': name, 'image': {'generatedImage': {'fifeUrl': url}}})
    if not media:
        raise ProtocolError('image_response_media_missing')
    return {'media': media, 'frontendRpc': 'ogiZ0b'}


class MediaTransport(CookieTransport):
    async def media_rpc(self, rpc_id, argument, client, provider, trace):
        from curl_cffi.requests import Cookies
        if rpc_id not in MEDIA_METHODS or not self.auth:
            raise ProtocolError('media_bootstrap_required')
        trace['rpc_method'] = rpc_id
        url, form = request(rpc_id, argument, self.auth, allowed=MEDIA_METHODS)
        fingerprint = client.get_request_fingerprint() or {}
        headers = {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
        for source, target in (('user_agent', 'User-Agent'), ('accept_language', 'Accept-Language'),
                ('sec_ch_ua', 'sec-ch-ua'), ('sec_ch_ua_platform', 'sec-ch-ua-platform'),
                ('sec_ch_ua_mobile', 'sec-ch-ua-mobile')):
            if fingerprint.get(source):
                headers[target] = fingerprint[source]
        original = self.session
        request_context = {}
        if provider == 'eznew':
            state = client._eznew_context().get()
            if not state or state.get('consumed') or not state.get('received_at'):
                raise ProtocolError('sync_token_state_invalid')
            elapsed = time.monotonic() - state['received_at']
            trace['sync_dispatch_gap_ms'] = round(elapsed * 1000, 3)
            if elapsed < 0 or elapsed >= 1:
                raise ProtocolError('sync_token_stale')
            from curl_cffi import CurlInfo
            # The borrowed solver session has its own diagnostic list. Require
            # its authoritative cookie snapshot before the immediate POST.
            state['session'].curl_infos = list(set(getattr(state['session'], 'curl_infos', []) or []) |
                {CurlInfo.COOKIELIST, CurlInfo.PRIMARY_IP, CurlInfo.PRIMARY_PORT,
                 CurlInfo.LOCAL_IP, CurlInfo.LOCAL_PORT})
            state['session'].cookies = Cookies(self.jar)
            self.session = state['session']
            state['consumed'] = True
            # Solver request options are per-call, not session defaults. Reusing
            # its connection pool must not drop the account's Google egress or
            # browser TLS/HTTP fingerprint. No await before the immediate POST.
            request_context = {'proxy': self.proxy_url,
                'impersonate': getattr(original, 'impersonate', None) or 'chrome'}
            trace['request_context'] = {'borrowed_solver_session': True,
                'proxy_sha256': hashlib.sha256(self.proxy_url.encode()).hexdigest(),
                'impersonate': str(request_context['impersonate'])}
        trace['dispatch_started'] = True
        trace['phase'] = 'rpc_dispatch'
        request_timeout = (upload_rpc_timeout_seconds() if rpc_id == 'maseQ'
                           else media_rpc_timeout_seconds())
        trace['rpc_timeout_seconds'] = request_timeout
        trace['rpc_deadline_policy'] = ('upload_only_v1' if rpc_id == 'maseQ'
                                        else 'image_generation_config_v1')
        try:
            raw = await self.dispatch('POST', url, data=form, headers=headers, timeout=request_timeout,
                max_body=MAX_MEDIA_BODY, **request_context)
            trace['transport'] = dict(getattr(self, 'last_rpc_transport', {}) or {})
            if provider == 'eznew':
                # Actual socket endpoints complement the configured proxy hash.
                # Collect after dispatch so synchronous tokens incur no delay.
                infos = getattr(raw, 'infos', {}) or {}
                connection = {}
                for key, field in ((CurlInfo.PRIMARY_IP, 'primary_ip'),
                        (CurlInfo.PRIMARY_PORT, 'primary_port'),
                        (CurlInfo.LOCAL_IP, 'local_ip'), (CurlInfo.LOCAL_PORT, 'local_port')):
                    value = infos.get(key)
                    if isinstance(value, bytes):
                        value = value.decode('ascii', 'replace')
                    if isinstance(value, (str, int)) and not isinstance(value, bool):
                        connection[field] = value
                trace['transport']['connection'] = connection
            trace['http_status'] = raw.status_code
            trace['response_complete'] = True
            trace['phase'] = 'rpc_parse'
            payload = response(raw.text, rpc_id, raw.status_code, allowed=MEDIA_METHODS,
                max_body=MAX_MEDIA_BODY)
            trace['submission_outcome'] = 'rpc_accepted'
            return payload
        except BaseException as error:
            diagnostic = getattr(error, 'rpc_transport_diagnostic', None)
            if isinstance(diagnostic, dict):
                trace['transport'] = dict(diagnostic)
            rejected = (trace.get('response_complete') is True and trace.get('http_status') == 200
                and getattr(error, 'rpc_rejection_confirmed', False) is True)
            trace['submission_outcome'] = 'explicit_provider_rejection' if rejected else 'unknown'
            if rejected and re.fullmatch(r'PUBLIC_ERROR_[A-Z0-9_]{1,80}', getattr(error, 'provider_code', '')):
                # Only a complete unique matching RPC rejection reaches this
                # bridge. Restore the existing public/backoff/recovery contract.
                error.args = ('Google RPC rejection: ' + error.provider_code,)
            setattr(error, 'outcome_unknown', not rejected)
            setattr(error, 'submission_uncertain', not rejected)
            raise
        finally:
            self.session = original


class CookieMedia:
    def __init__(self, client, auth):
        self.client, self.auth, self.db = client, auth, auth.db

    async def resolve(self, token_id=None, at=None, project_id=None, require_ready=True):
        if token_id is None:
            async with self.db._connect() as db:
                if at is not None:
                    found = await (await db.execute('SELECT id FROM tokens WHERE at=?', (at,))).fetchall()
                elif project_id is not None:
                    found = await (await db.execute('SELECT id FROM tokens WHERE current_project_id=? AND st IS NULL AND at IS NULL', (project_id,))).fetchall()
                else:
                    found = []
            if len(found) != 1:
                raise ProtocolError('media_identity_not_unique')
            token_id = found[0][0]
        token = await self.db.get_token(int(token_id))
        row = await self.auth.get(token_id)
        if not await self.auth.usable(token, require_generation=require_ready):
            from .cookie_auth import binding
            now = time.time()
            error = ProtocolError('cookie_media_session_not_usable')
            error.admission_diagnostic = {
                'session_present': bool(row), 'account_allowed': bool(token
                    and all(getattr(token, k, False) for k in ('is_active', 'image_enabled', 'auto_refresh_enabled'))
                    and not any(getattr(token, k, None) for k in ('ban_reason', 'banned_at'))),
                'binding_exact': bool(token and row and binding(token) == row.get('binding_sha')),
                'verified': bool(row and row.get('status') == 'verified'),
                'generation_ready': bool(row and row.get('generation_ready')),
                'require_generation': require_ready,
                'policy_remaining_seconds': round(row['policy_until'] - now, 3) if row and row.get('policy_until') is not None else None,
                'check_remaining_seconds': round(row['next_check_at'] - now, 3) if row and row.get('next_check_at') is not None else None}
            raise error
        if project_id is not None and row['project_id'] != project_id:
            raise ProtocolError('cookie_media_project_changed')
        return token, row

    async def save_cookies(self, token, row, transport):
        from .cookie_auth import binding
        from .flow_cookie_rpc import scoped_cookies
        updated = export_jar(transport.jar)
        scoped_cookies(updated)
        async with self.db._connect(write=True) as db:
            await db.execute('BEGIN IMMEDIATE')
            cursor = await db.execute('SELECT * FROM tokens WHERE id=?', (token.id,))
            values = await cursor.fetchone()
            from types import SimpleNamespace
            latest = SimpleNamespace(**dict(zip([x[0] for x in cursor.description], values)))
            if binding(latest) != row['binding_sha']:
                raise ProtocolError('media_binding_changed_after_dispatch')
            current = await (await db.execute('SELECT revision,binding_sha,status,source_sha,cookies FROM flow_cookie_sessions WHERE token_id=?', (token.id,))).fetchone()
            if (not current or current[1] != row['binding_sha'] or current[2] != 'verified'
                    or current[3] != row['source_sha']):
                raise ProtocolError('media_session_changed_after_dispatch')
            group = current_group(self.auth, token.id)
            if group is not None:
                if (group.stale or group.binding != row['binding_sha']
                        or group.source != row['source_sha'] or current[0] != group.revision):
                    # An external revision is not part of our upload lineage.
                    # Keep it and the successful result, as on the serial path.
                    group.stale = True
                    return False
                updated = json.dumps(merge_cookie_delta(row['cookies'], updated, current[4]),
                    separators=(',', ':'))
            elif current[0] != row['revision']:
                # An external process committed a newer jar. Retain that jar
                # and the successful paid result; never replay the generation.
                return False
            await db.execute('UPDATE flow_cookie_sessions SET cookies=?,revision=revision+1 WHERE token_id=?',
                (updated, token.id))
            await db.commit()
            if group is not None:
                group.revision = current[0] + 1
        return True

    async def operation(self, rpc_id, token, row, argument_builder, *, action='IMAGE_GENERATION', diagnostic_trace=None):
        started = time.monotonic()
        try:
            parallel = rpc_id in {'ogiZ0b', 'SPrCad'} and rpc_parallel_enabled(token.id)
            lease = (upload_lease(self.auth, token.id) if rpc_id == 'maseQ' else
                     media_lease(self.auth, token.id) if parallel else self.auth.session_lock(token.id))
            async with lease as upload:
                # Re-read admission and the jar under the shared account lock.
                wait_ms = round((time.monotonic() - started) * 1000)
                if rpc_id != 'maseQ' and not parallel:
                    await self.auth.maintain_media_locked(token.id)
                token, row = await self.resolve(token.id, project_id=row['project_id'],
                    require_ready=bool(row['generation_ready']))
                payload, trace = await self._operation(rpc_id, token, row, argument_builder, action=action, diagnostic_trace=diagnostic_trace)
                trace['account_lock_wait_ms'] = wait_ms
                if rpc_id == 'maseQ':
                    trace.update(upload_rpc_parallelism_limit=upload['limit'],
                        upload_rpc_active_at_start=upload['active_at_start'],
                        upload_rpc_peak_active=upload['group'].peak)
                elif parallel:
                    trace.update(media_rpc_parallelism_limit=upload['limit'],
                        media_rpc_active_at_start=upload['active_at_start'],
                        media_rpc_peak_active=upload['group'].media_peak,
                        cookie_lineage_policy='locked_delta_merge_v1')
                for item in trace.get('previous_attempts', []):
                    item['account_lock_wait_ms'] = wait_ms
                return payload, trace
        except BaseException as error:
            attr = 'flow2api_image_upsample_trace' if rpc_id == 'SPrCad' else 'flow2api_image_generation_trace'
            existing = getattr(error, attr, None)
            if isinstance(existing, dict):
                for item in existing.get('attempts' if rpc_id == 'SPrCad' else 'generation_attempts', []):
                    item['account_lock_wait_ms'] = locals().get('wait_ms', round((time.monotonic() - started) * 1000))
            else:
                trace = {'auth_mode': 'google_cookie_rpc', 'success': False, 'dispatch_started': False,
                    'phase': 'account_admission', 'code': str(error) if isinstance(error, ProtocolError)
                    else type(error).__name__, 'retry_blocked': 'account_admission_failed',
                    'duration_ms': round((time.monotonic() - started) * 1000)}
                trace['account_lock_wait_ms'] = round((time.monotonic() - started) * 1000)
                if hasattr(error, 'admission_diagnostic'):
                    trace['admission'] = error.admission_diagnostic
                if rpc_id == 'SPrCad':
                    self.client._attach_image_upsample_trace(error, {'attempts': [trace], 'max_attempts': 1})
                else:
                    self.client._attach_image_generation_trace(error, {'generation_attempts': [trace], 'max_retries': 1})
            raise

    async def _load_media_bootstrap(self, transport, trace, token, row, diagnostic_trace):
        """Retry one read-only GET, before any solver token or media RPC exists."""
        identity = (token.id, token.email, token.proxy_url, row['project_id'],
            row.get('binding_sha'), row.get('source_sha'), row.get('revision'))
        attempts = trace['bootstrap_attempts'] = []
        for index in range(2):
            started = time.monotonic()
            item = {'attempt': index + 1, 'method': 'GET', 'success': False,
                'media_dispatched': False, 'solver_called': False}
            attempts.append(item)
            try:
                await transport.load()
                item['success'] = True
                return
            except Exception as error:
                item['code'] = (str(error) if isinstance(error, ProtocolError)
                    else type(error).__name__)
                diagnostic = getattr(error, 'rpc_transport_diagnostic', None)
                if isinstance(diagnostic, dict):
                    item['transport'] = dict(diagnostic)
                # Exact transient transport codes observed on bootstrap GETs.
                # Auth/schema/content errors, cancellation and every POST stay
                # outside this recovery boundary.
                retryable = (isinstance(error, ProtocolError) and re.fullmatch(
                    r'rpc_transport_unavailable_curl_(?:16|28|35|55|56)', str(error)))
                if (index or not retryable or trace.get('dispatch_started')
                        or trace.get('solver_called') or trace.get('recaptcha_ok')
                        or (diagnostic_trace or {}).get('batch_stop_requested')):
                    raise
                await asyncio.sleep(.5)
                if (diagnostic_trace or {}).get('batch_stop_requested'):
                    item['retry_blocked'] = 'batch_stop_requested'
                    raise
                fresh_token, fresh_row = await self.resolve(token.id,
                    project_id=row['project_id'], require_ready=bool(row.get('generation_ready')))
                current = (fresh_token.id, fresh_token.email, fresh_token.proxy_url,
                    fresh_row['project_id'], fresh_row.get('binding_sha'),
                    fresh_row.get('source_sha'), fresh_row.get('revision'))
                if current != identity or fresh_row['policy_until'] <= time.time():
                    item['retry_blocked'] = 'bootstrap_admission_changed'
                    raise ProtocolError('bootstrap_retry_admission_changed') from None
                # Do not reuse a connection implicated in a failed TLS/H2 GET.
                # Keep the exact jar, browser fingerprint and account proxy.
                await transport.session.close()
                transport.session = None
                transport.auth = None
                await transport.__aenter__()
                item['retry_reason'] = 'bootstrap_transient_before_solver'
                item['retry_to_attempt'] = 2
            finally:
                item['duration_ms'] = round((time.monotonic() - started) * 1000)

    async def _operation(self, rpc_id, token, row, argument_builder, *, action='IMAGE_GENERATION', diagnostic_trace=None):
        client = self.client
        proxy = client.bind_token_image_egress(token.id, fallback_proxy_url=token.proxy_url)
        selected = tuple(client.resolve_image_captcha_provider_plan(token.id))
        # Preserve weighted primary selection. Cookie RPC permits at most one
        # switch to the already-planned Yes fallback, within the existing budget.
        plan = selected[:1]
        if plan and plan[0] != 'yescaptcha' and 'yescaptcha' in selected[1:]:
            plan += ('yescaptcha',)
        limit = max(1, int(config.flow_max_retries or 1))
        plan = plan[:limit]
        if not plan:
            raise ProtocolError('captcha_provider_plan_empty')
        paid_plan = plan
        control = upload_first_control() if rpc_id == 'maseQ' else {'enabled': False, 'revision': 'not_upload'}
        if control['enabled']:
            plan = ('none',) + paid_plan
        attempts = []
        cookies = row['cookies']
        identity = (token.id, token.email, token.proxy_url, row['project_id'],
            row.get('binding_sha'), row.get('source_sha'))
        for index, provider in enumerate(plan):
            no_solver = provider == 'none'
            paid_index = index - int(control['enabled'])
            trace = {'auth_mode': 'google_cookie_rpc', 'captcha_provider': provider,
                'captcha_provider_plan': list(paid_plan), 'attempt': index + 1,
                'captcha_fallback': paid_index > 0, 'recaptcha_ok': False,
                'solver_called': False, 'captcha_required': not no_solver,
                'paid_attempt': None if no_solver else paid_index + 1,
                'max_paid_attempts': len(paid_plan),
                'upload_first': rpc_id == 'maseQ' and control['enabled'],
                'upload_first_revision': control['revision'],
                'upload_first_control_reason': control.get('reason', 'not_upload'),
                'dispatch_started': False, 'max_retries': len(plan), 'phase': 'bootstrap'}
            attempts.append(trace)
            if isinstance(diagnostic_trace, dict):
                # Live metadata only; the batch supervisor must distinguish an
                # already-dispatched RPC from a queued solver before cleanup.
                diagnostic_trace['rpc_trace'] = trace
            browser = None
            solver_called = False
            started = time.monotonic()
            try:
                if index:
                    trace['phase'] = 'fallback_admission'
                    # Backoff and admission happen before obtaining a fresh
                    # one-use token, never between an EZnew token and its POST.
                    await asyncio.sleep(1)
                    fresh_token, fresh_row = await self.resolve(token.id,
                        project_id=row['project_id'], require_ready=bool(row.get('generation_ready')))
                    current = (fresh_token.id, fresh_token.email, fresh_token.proxy_url,
                        fresh_row['project_id'], fresh_row.get('binding_sha'), fresh_row.get('source_sha'))
                    if current != identity:
                        raise ProtocolError('captcha_fallback_binding_changed')
                    if fresh_row.get('revision') != row.get('revision'):
                        cookies = fresh_row['cookies']
                    token, row = fresh_token, fresh_row
                trace['phase'] = 'bootstrap'
                async with MediaTransport(cookies, token.email, proxy) as transport:
                    transport.evidence_account_id = token.id
                    await self._load_media_bootstrap(transport, trace, token, row, diagnostic_trace)
                    if row['policy_until'] <= time.time():
                        raise ProtocolError('policy_expired_before_solve')
                    captcha = None
                    if not no_solver:
                        trace['phase'] = 'captcha'
                        solver_called = True
                        trace['solver_called'] = True
                        solver_started(provider)
                        try:
                            captcha, browser = await client._get_recaptcha_token(row['project_id'],
                                action=action, token_id=token.id, captcha_method_override=provider)
                        except BaseException:
                            solver_finished(provider, False, uncertain=True)
                            raise
                        solver_finished(provider, bool(captcha))
                        trace['recaptcha_ok'] = bool(captcha)
                        if not captcha:
                            raise ProtocolError('cookie_media_captcha_unavailable')
                    trace['phase'] = 'argument_build'
                    if row['policy_until'] <= time.time():
                        raise ProtocolError('policy_expired_before_dispatch')
                    argument = argument_builder(captcha)
                    payload = await transport.media_rpc(rpc_id, argument, client, provider, trace)
                    trace['phase'] = 'cookie_persistence'
                    trace['cookies_persisted'] = await self.save_cookies(token, row, transport)
                    trace['success'] = True
                    if index:
                        trace['previous_attempts'] = attempts[:-1]
                    return payload, trace
            except BaseException as error:
                trace['success'] = False
                trace['code'] = str(error) if isinstance(error, ProtocolError) else type(error).__name__
                rejected = (trace.get('submission_outcome') == 'explicit_provider_rejection'
                    and getattr(error, 'rpc_rejection_confirmed', False) is True)
                if rejected:
                    trace['error_class'] = getattr(error, 'provider_code', 'rpc_provider_error')
                    trace['error'] = trace['error_class']
                    trace['rpc_rejection_confirmed'] = True
                    trace['rpc_public_error_present'] = getattr(error, 'rpc_public_error_present', True)
                    if type(getattr(error, 'rpc_status_code', None)) is int:
                        trace['rpc_status_code'] = error.rpc_status_code
                        trace['rpc_status_name'] = error.rpc_status_name
                    if getattr(error, 'provider_code', None):
                        trace['provider_code'] = error.provider_code
                # A solver returning no token did not submit the media RPC.
                # Preserve that proof on the intermediate attempt as well as
                # the terminal one, before the existing Yes fallback continues.
                no_token = (trace['dispatch_started'] is False
                    and trace['phase'] == 'captcha' and trace['solver_called'] is True
                    and trace['recaptcha_ok'] is False and isinstance(error, ProtocolError)
                    and str(error) == 'cookie_media_captcha_unavailable')
                if no_token:
                    trace.update(error_class='captcha_unavailable', error='captcha_unavailable',
                        submission_outcome='not_dispatched')
                reason = (upload_first_fallback_reason(error, trace) if no_solver
                          else captcha_failover_reason(error, trace))
                if (reason and index + 1 < len(plan)
                        and not (diagnostic_trace or {}).get('batch_stop_requested')):
                    trace['fallback_reason'] = reason
                    trace['fallback_to'] = plan[index + 1]
                    # Keep Set-Cookie changes from the rejected/unsent attempt
                    # locally; never replace the account or project to fail over.
                    cookies = export_jar(transport.jar)
                    continue
                if not rejected:
                    if no_token:
                        trace['retry_blocked'] = 'captcha_providers_exhausted'
                    else:
                        trace['retry_blocked'] = 'non_retryable_or_ambiguous_submission'
                if trace['dispatch_started'] and not rejected:
                    setattr(error, 'outcome_unknown', True)
                    setattr(error, 'submission_uncertain', True)
                client._attach_image_generation_trace(error,
                    {'generation_attempts': attempts, 'max_retries': len(plan),
                     'captcha_provider_plan': list(plan), 'auth_mode': 'google_cookie_rpc'})
                client._attach_image_upsample_trace(error,
                    {'attempts': attempts, 'max_attempts': len(plan),
                     'captcha_provider_plan': list(plan), 'auth_mode': 'google_cookie_rpc'})
                raise
            finally:
                # After dispatch/failure only: preserve immediate EZnew POST.
                if solver_called:
                    trace['solver'] = provider_snapshot()
                trace['duration_ms'] = round((time.monotonic() - started) * 1000)
                await client._close_eznew_session()
                await client._notify_browser_captcha_request_finished(browser)

    async def generate(self, token_id, project_id, prompt, model_name, aspect_ratio,
            image_inputs=None, progress_callback=None, *, acceptance=False):
        trace = None
        phase = 'account_admission'
        try:
            token, row = await self.resolve(token_id, project_id=project_id, require_ready=not acceptance)
            sid = str(uuid.uuid4()).upper()
            if progress_callback:
                await progress_callback('solving_image_captcha', 38)
            payload, trace = await self.operation('ogiZ0b', token, row,
                lambda cap: image_argument(project_id, prompt, model_name, aspect_ratio, cap, sid, image_inputs))
            phase = 'generation_response_decode'
            result = normalize_image(payload)
            attempts = media_attempts(trace)
            return result, sid, {'max_retries': trace.get('max_retries', 1),
                'generation_attempts': attempts, 'final_success_attempt': len(attempts),
                'auth_mode': 'google_cookie_rpc'}
        except BaseException as error:
            if not isinstance(getattr(error, 'flow2api_image_generation_trace', None), dict):
                detail = dict(trace or {'auth_mode': 'google_cookie_rpc', 'dispatch_started': False})
                detail.update(success=False, phase=phase,
                    code=str(error) if isinstance(error, ProtocolError) else type(error).__name__)
                if hasattr(error, 'admission_diagnostic'):
                    detail['admission'] = error.admission_diagnostic
                self.client._attach_image_generation_trace(error,
                    {'generation_attempts': media_attempts(detail), 'max_retries': detail.get('max_retries', 1)})
            raise

    async def upload(self, at, project_id, image_bytes, diagnostic_trace=None):
        diagnostic = diagnostic_trace if isinstance(diagnostic_trace, dict) else {}
        started = time.monotonic()
        trace = None
        diagnostic.update(auth_mode='google_cookie_rpc', attempts=1, max_attempts=1)
        try:
            token, row = await self.resolve(at=at, project_id=project_id)
            mime = self.client._detect_image_mime_type(image_bytes)
            encoded = base64.b64encode(image_bytes).decode('ascii')
            payload, trace = await self.operation('maseQ', token, row,
                lambda cap: [context(project_id, cap) if cap is not None else context(project_id, cap)[:-1], encoded, mime, 1, None, None, None, None,
                    'reference-image', None, str(uuid.uuid4()).upper(), str(uuid.uuid4()).upper()],
                action='UPLOAD_IMAGE', diagnostic_trace=diagnostic)
            if not payload or not isinstance(payload[0], list) or not payload[0] or not isinstance(payload[0][0], str):
                raise ProtocolError('upload_media_response_unknown')
            diagnostic.update(status='uploaded', rpc_trace=trace,
                attempts=len(media_attempts(trace)), max_attempts=trace.get('max_retries', 1),
                returned_media_sha256=hashlib.sha256(payload[0][0].encode()).hexdigest())
            return payload[0][0]
        except BaseException as error:
            existing = getattr(error, 'flow2api_image_generation_trace', {})
            attempts = existing.get('generation_attempts') or []
            detail = attempts[-1] if attempts else dict(trace or {'phase': 'account_admission', 'dispatch_started': False})
            if not attempts:
                detail.update(success=False, phase='upload_response_decode' if trace else 'account_admission',
                    code=str(error) if isinstance(error, ProtocolError) else type(error).__name__)
            if hasattr(error, 'admission_diagnostic'):
                detail['admission'] = error.admission_diagnostic
            diagnostic.update(status='failed', rpc_trace=detail,
                rpc_attempts=attempts,
                attempts=len(attempts) or 1, max_attempts=existing.get('max_retries', 1),
                cause=detail.get('error_class') or detail.get('code', 'unknown'))
            transport_code = detail.get('code', '')
            if (not isinstance(error, asyncio.CancelledError)
                    and isinstance(transport_code, str)
                    and re.fullmatch(r'rpc_transport_unavailable_curl_[0-9]{1,3}', transport_code)):
                # Classification MUST NOT authorize replay of an uncertain RPC.
                cause = 'network_timeout' if transport_code.endswith('_curl_28') else 'transport'
                diagnostic.update(cause=cause, failure_stage='reference_upload',
                    recovery_blocked='non_retryable_or_ambiguous_submission')
                wrapped = ProtocolError('Project-scoped image upload failed via /flow/uploadImage; '
                    + 'cause=' + cause + '; attempts=' + str(len(attempts) or 1))
                wrapped.outcome_unknown = True
                wrapped.submission_uncertain = True
                self.client._attach_image_generation_trace(wrapped, existing)
                raise wrapped from error
            # This boundary knows it was an upload, not an image submission.
            # Keep the real HTTP200 and numeric RPC status separate in trace.
            # Typed/explicit content policy still passes through unchanged.
            rejected = (detail.get('rpc_method') == 'maseQ'
                and detail.get('response_complete') is True and detail.get('http_status') == 200
                and detail.get('submission_outcome') == 'explicit_provider_rejection'
                and detail.get('rpc_rejection_confirmed') is True
                and getattr(error, 'rpc_rejection_confirmed', False) is True)
            if (rejected and getattr(error, 'provider_code', None) == 'PUBLIC_ERROR_HIGH_TRAFFIC'
                    and detail.get('provider_code') == 'PUBLIC_ERROR_HIGH_TRAFFIC'
                    and type(detail.get('rpc_status_code')) is int
                    and detail['rpc_status_code'] == 8):
                diagnostic.update(cause='rpc_high_traffic', failure_stage='reference_upload')
                wrapped = RuntimeError('Project-scoped image upload failed via /flow/uploadImage; '
                    + 'cause=rpc_high_traffic; provider_code=PUBLIC_ERROR_HIGH_TRAFFIC; attempts='
                    + str(len(attempts) or 1))
                wrapped.outcome_unknown = False
                wrapped.submission_uncertain = False
                self.client._attach_image_generation_trace(wrapped, existing)
                raise wrapped from error
            if (rejected and not getattr(error, 'provider_code', None)
                    and getattr(error, 'rpc_public_error_present', True) is False):
                causes = {3: 'rpc_invalid_argument', 4: 'rpc_deadline_exceeded', 8: 'rpc_resource_exhausted', 13: 'rpc_internal'}
                cause = causes.get(detail.get('rpc_status_code'), 'rpc_provider_rejection')
                diagnostic['cause'] = cause
                wrapped = RuntimeError('Project-scoped image upload failed via /flow/uploadImage; '
                    + 'cause=' + cause + '; attempts=' + str(len(attempts) or 1))
                wrapped.outcome_unknown = False
                wrapped.submission_uncertain = False
                raise wrapped from error
            raise
        finally:
            diagnostic['duration_ms'] = round((time.monotonic() - started) * 1000, 3)

    async def upsample(self, token_id, project_id, media_id, resolution, *, acceptance=False):
        trace = None
        phase = 'upsample_admission'
        started = time.monotonic()
        try:
            token, row = await self.resolve(token_id, project_id=project_id, require_ready=not acceptance)
            if resolution not in {'UPSAMPLE_IMAGE_RESOLUTION_2K', 'UPSAMPLE_IMAGE_RESOLUTION_4K'}:
                raise ProtocolError('upsample_resolution_unsupported')
            payload, trace = await self.operation('SPrCad', token, row,
                lambda cap: [media_id, 2 if resolution.endswith('4K') else 1, context(project_id, cap)])
            phase = 'upsample_response_decode'
            encoded = payload[1] if len(payload) > 1 and isinstance(payload[1], str) else None
            url = content_url(payload)
            if not encoded and not url:
                raise ProtocolError('upsample_media_response_unknown')
            if not encoded:
                phase = 'upsample_output_download'
                raw, evidence = await self.download(token, url)
                trace['download'] = evidence
                encoded = base64.b64encode(raw).decode('ascii')
            attempts = media_attempts(trace)
            return encoded, {'attempts': attempts, 'max_attempts': trace.get('max_retries', 1),
                'final_success_attempt': len(attempts),
                'base_image_available': bool(media_id), 'auth_mode': 'google_cookie_rpc'}
        except BaseException as error:
            existing = getattr(error, 'flow2api_image_upsample_trace', None)
            if not isinstance(existing, dict):
                trace = dict(trace or {'auth_mode': 'google_cookie_rpc', 'dispatch_started': False})
                trace.update(success=False, phase=phase,
                    code=str(error) if isinstance(error, ProtocolError) else type(error).__name__,
                    retry_blocked='non_retryable_or_ambiguous_submission',
                    duration_ms=round((time.monotonic() - started) * 1000))
                existing = {'attempts': media_attempts(trace), 'max_attempts': trace.get('max_retries', 1)}
            existing.update(base_image_available=bool(media_id), auth_mode='google_cookie_rpc')
            self.client._attach_image_upsample_trace(error, existing)
            raise

    async def balance(self, at, *, token_id=None):
        token, row = await self.resolve(token_id=token_id, at=at, require_ready=False)
        async with self.auth.session_lock(token.id):
            return await self._balance(at, token_id=token.id)

    async def _balance(self, at, *, token_id=None):
        token, row = await self.resolve(token_id=token_id, at=at, require_ready=False)
        async with MediaTransport(row['cookies'], token.email, row['proxy_url']) as transport:
            result = credits(await transport.rpc('nzlxg', []))
            if result['userPaygateTier'] != token.user_paygate_tier:
                raise ProtocolError('credits_tier_changed')
            await self.save_cookies(token, row, transport)
            await self.db.update_token(token.id, credits=result['credits'])
            return result

    async def download(self, token, url):
        from curl_cffi.requests import AsyncSession
        from PIL import Image
        if content_url(url) != url:
            raise ProtocolError('media_download_origin_rejected')
        proxy = self.client.resolve_token_image_egress_proxy(token.id) or token.proxy_url
        from . import google_failure_evidence as evidence
        call = evidence.new_call('GET', url, stage='cookie_rpc_output_download')
        result = failure = None
        async with AsyncSession(impersonate='chrome', proxy=proxy, trust_env=False, timeout=90) as session:
            if call is not None:
                call.attach(session)
                session.curl_infos = list(set(session.curl_infos or []) | set(evidence.EXTRA_INFOS))
            try:
                result = await session.get(url, allow_redirects=False)
            except BaseException as error:
                failure = ProtocolError('media_download_transport_' + type(error).__name__)
                if isinstance(error, Exception):
                    raise failure from None
                raise
            finally:
                if call is not None:
                    call.detach(session)
                    await evidence.finish_call(call, result, failure, {'response_complete': result is not None})
        if result.status_code != 200 or len(result.content) > 64 * 1024 * 1024:
            raise ProtocolError('media_download_failed')
        image = Image.open(io.BytesIO(result.content)); image.load()
        return result.content, {'http': 200, 'width': image.width, 'height': image.height,
            'format': image.format, 'bytes': len(result.content),
            'sha256': hashlib.sha256(result.content).hexdigest()}

    async def acceptance_table(self):
        await self.auth.initialize()
        async with self.db._connect(write=True) as db:
            await db.execute('''CREATE TABLE IF NOT EXISTS flow_cookie_generation_acceptances (
                token_id INTEGER PRIMARY KEY, binding_sha TEXT NOT NULL,
                started_at REAL NOT NULL, finished_at REAL, status TEXT NOT NULL,
                report TEXT NOT NULL)''')
            await db.commit()

    async def finish_acceptance(self, token_id, binding_sha, report):
        from .cookie_auth import binding
        async with self.db._connect(write=True) as db:
            await db.execute('BEGIN IMMEDIATE')
            cursor = await db.execute('SELECT * FROM tokens WHERE id=?', (token_id,))
            values = await cursor.fetchone()
            from types import SimpleNamespace
            token = SimpleNamespace(**dict(zip([x[0] for x in cursor.description], values)))
            row = await (await db.execute('SELECT binding_sha,policy_until,status FROM flow_cookie_sessions WHERE token_id=?', (token_id,))).fetchone()
            if binding(token) != binding_sha or not row or row[0] != binding_sha or row[1] < time.time() or row[2] != 'verified':
                raise ProtocolError('acceptance_binding_or_policy_changed')
            await db.execute('UPDATE flow_cookie_sessions SET generation_ready=1 WHERE token_id=?', (token_id,))
            await db.execute('UPDATE flow_cookie_generation_acceptances SET status=?,finished_at=?,report=? WHERE token_id=?',
                ('accepted', time.time(), json.dumps(report), token_id))
            await db.commit()
        return report

    async def accept_one(self, token_id):
        """Exactly one new-protocol image acceptance, persistent before solving.

        Existing intents, failures and successes are never replayed. Ultra tests
        are explicit 4K requests (base + same-base upsample), respecting cooldowns.
        """
        token, row = await self.resolve(token_id, require_ready=False)
        await self.acceptance_table()
        if any(c['token_id'] == token.id for c in await self.db.get_model_cooldowns()):
            return {'token_id': token.id, 'status': 'skipped', 'code': 'real_model_cooldown'}
        async with self.db._connect(write=True) as db:
            await db.execute('BEGIN IMMEDIATE')
            found = await (await db.execute('SELECT status,report FROM flow_cookie_generation_acceptances WHERE token_id=?', (token.id,))).fetchone()
            if found:
                return {'token_id': token.id, 'status': found[0], 'cached': True}
            await db.execute('INSERT INTO flow_cookie_generation_acceptances VALUES(?,?,?,NULL,?,?)',
                (token.id, row['binding_sha'], time.time(), 'dispatching', '{}'))
            await db.commit()
        report = {'token_id': token.id, 'status': 'dispatching', 'auth_mode': 'google_cookie_rpc',
            'model': 'BELUGA', 'at_renewed': False}
        try:
            ultra = token.user_paygate_tier in {'PAYGATE_TIER_TWO', 'PAYGATE_TIER_TIER1P5'}
            result, sid, trace = await self.generate(token.id, row['project_id'],
                'A simple blue ceramic cup on a plain white table, studio photograph, no text.',
                'BELUGA', 'IMAGE_ASPECT_RATIO_SQUARE', acceptance=True)
            report['generation_trace'] = trace
            if ultra:
                encoded, upscale_trace = await self.upsample(token.id, row['project_id'],
                    result['media'][0]['name'], 'UPSAMPLE_IMAGE_RESOLUTION_4K', acceptance=True)
                raw = base64.b64decode(encoded, validate=True)
                from PIL import Image
                image = Image.open(io.BytesIO(raw)); image.load()
                evidence = {'http': 200, 'width': image.width, 'height': image.height,
                    'format': image.format, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                report['upsample_trace'] = upscale_trace
                report['resolution'] = '4K'
            else:
                raw, evidence = await self.download(token, result['media'][0]['image']['generatedImage']['fifeUrl'])
                report['resolution'] = '1K'
            minimum = 4096 if ultra else 1024
            if min(evidence['width'], evidence['height']) < minimum:
                raise ProtocolError('acceptance_resolution_mismatch')
            report.update(status='accepted', evidence=evidence)
            await self.balance(token.at, token_id=token.id)
            await self.db.increment_token_stats(token.id, 'image')
            return await self.finish_acceptance(token.id, row['binding_sha'], report)
        except Exception as error:
            report.update(status='manual_required', code=str(error) if isinstance(error, ProtocolError) else type(error).__name__)
            trace = getattr(error, 'flow2api_image_generation_trace', None)
            if trace:
                report['generation_trace'] = trace
            async with self.db._connect(write=True) as db:
                await db.execute('UPDATE flow_cookie_generation_acceptances SET status=?,finished_at=?,report=? WHERE token_id=?',
                    ('manual_required', time.time(), json.dumps(report), token.id))
                await db.commit()
            return report
