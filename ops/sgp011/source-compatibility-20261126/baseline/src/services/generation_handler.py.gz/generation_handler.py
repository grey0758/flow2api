"""Generation handler for Flow2API"""
import asyncio
import hashlib
import base64
import binascii
from collections import deque
import io
import json
import math
import os
import re
import secrets
import time
from pathlib import Path
from typing import Optional, AsyncGenerator, List, Dict, Any
from PIL import Image, UnidentifiedImageError
from ..core.logger import debug_logger
from ..core.config import config
from ..core.monitoring import record_generation_result
from ..core.models import Task, RequestLog
from ..core.account_tiers import (
    PAYGATE_TIER_NOT_PAID,
    get_paygate_tier_label,
    get_required_paygate_tier_for_model,
    normalize_user_paygate_tier,
    supports_model_for_tier,
)
from .file_cache import FileCache
from .flow_client import FlowClient
from .upload_success_evidence import find_success, MATCH_FIELDS
from . import upload_egress
from . import image_provenance
from . import google_failure_evidence
from . import image_content_policy
from . import image_watermark
from . import cookie_capacity
from .original_aspect import ORIGINAL_ASPECTS, DIMENSIONS as ORIGINAL_DIMENSIONS, reference_geometry, original_inputs, validate_output
from .upload_exit_backoff import UploadExitBackoff
from .image_failure_guard import FLASH_ENDPOINT_GUARD, is_shared_flash_404


# Model configuration
MODEL_CONFIG = {
    # 图片生成 - GEM_PIX_2 (Gemini 3.0 Pro)
    "gemini-3.0-pro-image-landscape": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE"
    },
    "gemini-3.0-pro-image-portrait": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT"
    },
    "gemini-3.0-pro-image-square": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_SQUARE"
    },
    "gemini-3.0-pro-image-four-three": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE"
    },
    "gemini-3.0-pro-image-three-four": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR"
    },

    # 图片生成 - GEM_PIX_2 (Gemini 3.0 Pro) 2K 放大版
    "gemini-3.0-pro-image-landscape-2k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.0-pro-image-portrait-2k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.0-pro-image-square-2k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_SQUARE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.0-pro-image-four-three-2k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.0-pro-image-three-four-2k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },

    # 图片生成 - GEM_PIX_2 (Gemini 3.0 Pro) 4K 放大版
    "gemini-3.0-pro-image-landscape-4k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.0-pro-image-portrait-4k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.0-pro-image-square-4k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_SQUARE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.0-pro-image-four-three-4k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.0-pro-image-three-four-4k": {
        "type": "image",
        "model_name": "GEM_PIX_2",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },

    # 图片生成 - IMAGEN_3_5 (Imagen 4.0)
    "imagen-4.0-generate-preview-landscape": {
        "type": "image",
        "model_name": "IMAGEN_3_5",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE"
    },
    "imagen-4.0-generate-preview-portrait": {
        "type": "image",
        "model_name": "IMAGEN_3_5",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT"
    },

    # 图片生成 - BELUGA (Nano Banana 2.1；保留现有公开型号名称)
    "gemini-3.1-flash-image-landscape": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE"
    },
    "gemini-3.1-flash-image-portrait": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT"
    },
    "gemini-3.1-flash-image-square": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_SQUARE"
    },
    "gemini-3.1-flash-image-four-three": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE"
    },
    "gemini-3.1-flash-image-three-four": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR"
    },
    "gemini-3.1-flash-image-landscape-2k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.1-flash-image-portrait-2k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.1-flash-image-square-2k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_SQUARE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.1-flash-image-four-three-2k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.1-flash-image-three-four-2k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_2K"
    },
    "gemini-3.1-flash-image-landscape-4k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.1-flash-image-portrait-4k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.1-flash-image-square-4k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_SQUARE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.1-flash-image-four-three-4k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },
    "gemini-3.1-flash-image-three-four-4k": {
        "type": "image",
        "model_name": "BELUGA",
        "aspect_ratio": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR",
        "upsample": "UPSAMPLE_IMAGE_RESOLUTION_4K"
    },

    # ========== 文生视频 (T2V - Text to Video) ==========
    # 不支持上传图片，只使用文本提示词生成

    # veo_3_1_t2v_fast_portrait (竖屏)
    # 上游模型名: veo_3_1_t2v_fast_portrait
    "veo_3_1_t2v_fast_portrait": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "use_v2_model_config": True,
    },
    # veo_3_1_t2v_fast_landscape (横屏)
    # 上游模型名: veo_3_1_t2v_fast
    "veo_3_1_t2v_fast_landscape": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "use_v2_model_config": True,
    },

    # veo_3_1_t2v_fast_ultra (横竖屏)
    "veo_3_1_t2v_fast_portrait_ultra": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "use_v2_model_config": True,
    },
    "veo_3_1_t2v_fast_ultra": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "use_v2_model_config": True,
    },

    # veo_3_1_t2v_fast_ultra_relaxed (横竖屏)
    "veo_3_1_t2v_fast_portrait_ultra_relaxed": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait_ultra_relaxed",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "use_v2_model_config": True,
    },
    "veo_3_1_t2v_fast_ultra_relaxed": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_ultra_relaxed",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "use_v2_model_config": True,
    },

    # veo_3_1_t2v (横竖屏)
    "veo_3_1_t2v_portrait": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "use_v2_model_config": True,
    },
    "veo_3_1_t2v_landscape": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "use_v2_model_config": True,
    },
    # veo_3_1_t2v_lite (横竖屏，来自 labs.google.har)
    "veo_3_1_t2v_lite_portrait": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_lite",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False
    },
    "veo_3_1_t2v_lite_landscape": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_lite",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False
    },

    # ========== 首尾帧模型 (I2V - Image to Video) ==========
    # 支持1-2张图片：1张作为首帧，2张作为首尾帧

    # veo_3_1_i2v_s_fast_fl (需要新增横竖屏)
    "veo_3_1_i2v_s_fast_portrait_fl": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_portrait_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },
    "veo_3_1_i2v_s_fast_fl": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },

    # veo_3_1_i2v_s_fast_ultra (横竖屏)
    "veo_3_1_i2v_s_fast_portrait_ultra_fl": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_portrait_ultra_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },
    "veo_3_1_i2v_s_fast_ultra_fl": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_ultra_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },

    # veo_3_1_i2v_s_fast_ultra_relaxed (需要新增横竖屏)
    "veo_3_1_i2v_s_fast_portrait_ultra_relaxed": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_portrait_ultra_relaxed",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },
    "veo_3_1_i2v_s_fast_ultra_relaxed": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_ultra_relaxed",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },

    # veo_3_1_i2v_s (需要新增横竖屏)
    "veo_3_1_i2v_s_portrait": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },
    "veo_3_1_i2v_s_landscape": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2
    },
    # veo_3_1_i2v_lite (横竖屏，仅首帧，来自 labs.google.har)
    "veo_3_1_i2v_lite_portrait": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_lite",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 1,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False
    },
    "veo_3_1_i2v_lite_landscape": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_lite",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 1,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False
    },
    # veo_3_1_interpolation_lite (横竖屏，首尾帧，来自 labs.google.har)
    "veo_3_1_interpolation_lite_portrait": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_interpolation_lite",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 2,
        "max_images": 2,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False
    },
    "veo_3_1_interpolation_lite_landscape": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_interpolation_lite",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 2,
        "max_images": 2,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False
    },

    # ========== 多图生成 (R2V - Reference Images to Video) ==========
    # 当前上游协议最多支持 3 张参考图

    # veo_3_1_r2v_fast (横竖屏)
    "veo_3_1_r2v_fast_portrait": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_portrait",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3
    },
    "veo_3_1_r2v_fast": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_landscape",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3
    },

    # veo_3_1_r2v_fast_ultra (横竖屏)
    "veo_3_1_r2v_fast_portrait_ultra": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3
    },
    "veo_3_1_r2v_fast_ultra": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_landscape_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3
    },

    # veo_3_1_r2v_fast_ultra_relaxed (横竖屏)
    "veo_3_1_r2v_fast_portrait_ultra_relaxed": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_portrait_ultra_relaxed",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3
    },
    "veo_3_1_r2v_fast_ultra_relaxed": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_landscape_ultra_relaxed",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3
    },

    # ========== 视频放大 (Video Upsampler) ==========
    # 仅 3.1 支持，需要先生成视频后再放大，可能需要 30 分钟

    # T2V 4K 放大版
    "veo_3_1_t2v_fast_portrait_4k": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },
    "veo_3_1_t2v_fast_4k": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },
    "veo_3_1_t2v_fast_portrait_ultra_4k": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },
    "veo_3_1_t2v_fast_ultra_4k": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },

    # T2V 1080P 放大版
    "veo_3_1_t2v_fast_portrait_1080p": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },
    "veo_3_1_t2v_fast_1080p": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },
    "veo_3_1_t2v_fast_portrait_ultra_1080p": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },
    "veo_3_1_t2v_fast_ultra_1080p": {
        "type": "video",
        "video_type": "t2v",
        "model_key": "veo_3_1_t2v_fast_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },

    # I2V 4K 放大版
    "veo_3_1_i2v_s_fast_portrait_ultra_fl_4k": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_portrait_ultra_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },
    "veo_3_1_i2v_s_fast_ultra_fl_4k": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_ultra_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },

    # I2V 1080P 放大版
    "veo_3_1_i2v_s_fast_portrait_ultra_fl_1080p": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_portrait_ultra_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },
    "veo_3_1_i2v_s_fast_ultra_fl_1080p": {
        "type": "video",
        "video_type": "i2v",
        "model_key": "veo_3_1_i2v_s_fast_ultra_fl",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 1,
        "max_images": 2,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },

    # R2V 4K 放大版
    "veo_3_1_r2v_fast_portrait_ultra_4k": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },
    "veo_3_1_r2v_fast_ultra_4k": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_landscape_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3,
        "upsample": {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
    },

    # R2V 1080P 放大版
    "veo_3_1_r2v_fast_portrait_ultra_1080p": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },
    "veo_3_1_r2v_fast_ultra_1080p": {
        "type": "video",
        "video_type": "r2v",
        "model_key": "veo_3_1_r2v_fast_landscape_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3,
        "upsample": {"resolution": "VIDEO_RESOLUTION_1080P", "model_key": "veo_3_1_upsampler_1080p"}
    },

    # ========== 视频续写 (Extend - Video Continuation) ==========
    # 基于已生成的视频续写7秒，最多续写20次（最长148秒）
    # 需要提供源视频的 mediaGenerationId

    # VEO 3.1 Extend (横竖屏)
    "veo_3_1_extend_portrait": {
        "type": "video",
        "video_type": "extend",
        "model_key": "veo_3_1_extend_fast_portrait_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": False,
        "requires_video_id": True,
    },
    "veo_3_1_extend": {
        "type": "video",
        "video_type": "extend",
        "model_key": "veo_3_1_extend_fast_ultra",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": False,
        "requires_video_id": True,
    },
    # ========== Gemini Omni Flash ==========
    # 2026-05-26 实测上游真实请求：
    # - 纯文本 -> video:batchAsyncGenerateVideoText, videoModelKey=abra_t2v_8s
    # - 参考图 -> video:batchAsyncGenerateVideoReferenceImages, videoModelKey=abra_r2v_8s
    "omni": {
        "type": "video",
        "video_type": "omni",
        "model_key": "abra_t2v_8s",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_LANDSCAPE",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False,
        "reference_model_key": "abra_r2v_8s",
        "reference_duration": 8,
        "reference_model_display_name": "Omni Flash",
    },
    "omni_portrait": {
        "type": "video",
        "video_type": "omni",
        "model_key": "abra_t2v_8s",
        "aspect_ratio": "VIDEO_ASPECT_RATIO_PORTRAIT",
        "supports_images": True,
        "min_images": 0,
        "max_images": 3,
        "use_v2_model_config": True,
        "allow_tier_upgrade": False,
        "reference_model_key": "abra_r2v_8s",
        "reference_duration": 8,
        "reference_model_display_name": "Omni Flash",
    },
}


# Official Original edit mode: same first image, no crop, canvas or transcode.
for _variant, (_aspect, _, _) in ORIGINAL_ASPECTS.items():
    for _suffix in ("", "-2k", "-4k"):
        MODEL_CONFIG["gemini-3.0-pro-image-" + _variant + _suffix] = {
            **MODEL_CONFIG["gemini-3.0-pro-image-three-four" + _suffix],
            "aspect_ratio": _aspect,
            "native_original_aspect": True,
        }


UPSAMPLED_IMAGE_DIMENSIONS = {
    "UPSAMPLE_IMAGE_RESOLUTION_2K": {
        "IMAGE_ASPECT_RATIO_LANDSCAPE": (2752, 1536),
        "IMAGE_ASPECT_RATIO_PORTRAIT": (1536, 2752),
        "IMAGE_ASPECT_RATIO_SQUARE": (2048, 2048),
        "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE": (2400, 1792),
        "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR": (1792, 2400),
    },
    "UPSAMPLE_IMAGE_RESOLUTION_4K": {
        "IMAGE_ASPECT_RATIO_LANDSCAPE": (5504, 3072),
        "IMAGE_ASPECT_RATIO_PORTRAIT": (3072, 5504),
        "IMAGE_ASPECT_RATIO_SQUARE": (4096, 4096),
        "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE": (4800, 3584),
        "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR": (3584, 4800),
    },
}
for _tier in ("2K", "4K"):
    UPSAMPLED_IMAGE_DIMENSIONS["UPSAMPLE_IMAGE_RESOLUTION_" + _tier].update(ORIGINAL_DIMENSIONS[_tier])



from .image_recovery import (CrossAccountRetryBudget, RECOVERY_BUDGET as _CROSS_ACCOUNT_RETRY_BUDGET,
    IMAGE_RISK_BACKOFF, explicit_risk, bind_reservation, reset_reservation)


def _make_t2v_config(
    model_key: str,
    aspect_ratio: str,
    *,
    use_v2_model_config: bool = False,
    allow_tier_upgrade: bool = True,
    upsample: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    cfg: Dict[str, Any] = {
        "type": "video",
        "video_type": "t2v",
        "model_key": model_key,
        "aspect_ratio": aspect_ratio,
        "supports_images": False,
    }
    if use_v2_model_config:
        cfg["use_v2_model_config"] = True
    if not allow_tier_upgrade:
        cfg["allow_tier_upgrade"] = False
    if upsample:
        cfg["upsample"] = upsample
    return cfg


def _make_i2v_config(
    model_key: str,
    aspect_ratio: str,
    *,
    min_images: int = 1,
    max_images: int = 2,
    use_v2_model_config: bool = False,
    allow_tier_upgrade: bool = True,
    upsample: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    cfg: Dict[str, Any] = {
        "type": "video",
        "video_type": "i2v",
        "model_key": model_key,
        "aspect_ratio": aspect_ratio,
        "supports_images": True,
        "min_images": min_images,
        "max_images": max_images,
    }
    if use_v2_model_config:
        cfg["use_v2_model_config"] = True
    if not allow_tier_upgrade:
        cfg["allow_tier_upgrade"] = False
    if upsample:
        cfg["upsample"] = upsample
    return cfg


def _apply_veo_3_1_model_updates():
    """Keep the public aliases aligned with the current Veo 3.1 model families."""
    landscape = "VIDEO_ASPECT_RATIO_LANDSCAPE"
    portrait = "VIDEO_ASPECT_RATIO_PORTRAIT"

    def add_alias(alias: str, target: str):
        MODEL_CONFIG[alias] = dict(MODEL_CONFIG[target])

    def add_default_duration_aliases(
        base_alias: str,
        landscape_target: str,
        portrait_target: str,
        *,
        fl_suffix: bool = False,
    ):
        if fl_suffix:
            add_alias(f"{base_alias}_8s_fl", landscape_target)
            add_alias(f"{base_alias}_portrait_8s_fl", portrait_target)
            add_alias(f"{base_alias}_landscape_8s_fl", landscape_target)
            return

        add_alias(f"{base_alias}_8s", landscape_target)
        add_alias(f"{base_alias}_portrait_8s", portrait_target)
        add_alias(f"{base_alias}_landscape_8s", landscape_target)

    def add_default_duration_upsample_aliases(
        base_alias: str,
        resolution_name: str,
        landscape_target: str,
        portrait_target: str,
    ):
        add_alias(f"{base_alias}_8s_{resolution_name}", landscape_target)
        add_alias(f"{base_alias}_portrait_8s_{resolution_name}", portrait_target)
        add_alias(f"{base_alias}_landscape_8s_{resolution_name}", landscape_target)

    # Non-fast/non-lite Veo 3.1 aliases must call Quality upstream keys.
    MODEL_CONFIG["veo_3_1_t2v_landscape"].update({"model_key": "veo_3_1_t2v"})
    MODEL_CONFIG["veo_3_1_t2v_portrait"].update({"model_key": "veo_3_1_t2v_portrait"})
    MODEL_CONFIG["veo_3_1_i2v_s_landscape"].update({"model_key": "veo_3_1_i2v_s_fl"})
    MODEL_CONFIG["veo_3_1_i2v_s_portrait"].update({"model_key": "veo_3_1_i2v_s_portrait_fl"})
    MODEL_CONFIG["veo_3_1_extend"].update({"model_key": "veo_3_1_extend_landscape"})
    MODEL_CONFIG["veo_3_1_extend_portrait"].update({"model_key": "veo_3_1_extend_portrait"})

    for seconds in (4, 6):
        suffix = f"{seconds}s"

        # T2V duration variants.
        MODEL_CONFIG[f"veo_3_1_t2v_fast_{suffix}"] = _make_t2v_config(
            f"veo_3_1_t2v_fast_{suffix}", landscape
        )
        MODEL_CONFIG[f"veo_3_1_t2v_fast_portrait_{suffix}"] = _make_t2v_config(
            f"veo_3_1_t2v_fast_{suffix}", portrait
        )
        MODEL_CONFIG[f"veo_3_1_t2v_lite_{suffix}_landscape"] = _make_t2v_config(
            f"veo_3_1_t2v_lite_{suffix}",
            landscape,
            use_v2_model_config=True,
            allow_tier_upgrade=False,
        )
        MODEL_CONFIG[f"veo_3_1_t2v_lite_{suffix}_portrait"] = _make_t2v_config(
            f"veo_3_1_t2v_lite_{suffix}",
            portrait,
            use_v2_model_config=True,
            allow_tier_upgrade=False,
        )
        MODEL_CONFIG[f"veo_3_1_t2v_{suffix}"] = _make_t2v_config(
            f"veo_3_1_t2v_quality_{suffix}", landscape
        )
        MODEL_CONFIG[f"veo_3_1_t2v_portrait_{suffix}"] = _make_t2v_config(
            f"veo_3_1_t2v_quality_{suffix}", portrait
        )

        # I2V duration variants. FL keys are used for 2 images; the single-image path strips "_fl".
        MODEL_CONFIG[f"veo_3_1_i2v_s_fast_{suffix}_fl"] = _make_i2v_config(
            f"veo_3_1_i2v_s_fast_{suffix}_fl", landscape
        )
        MODEL_CONFIG[f"veo_3_1_i2v_s_fast_portrait_{suffix}_fl"] = _make_i2v_config(
            f"veo_3_1_i2v_s_fast_{suffix}_fl", portrait
        )
        MODEL_CONFIG[f"veo_3_1_i2v_lite_{suffix}_landscape"] = _make_i2v_config(
            f"veo_3_1_i2v_s_lite_{suffix}",
            landscape,
            min_images=1,
            max_images=1,
            use_v2_model_config=True,
            allow_tier_upgrade=False,
        )
        MODEL_CONFIG[f"veo_3_1_i2v_lite_{suffix}_portrait"] = _make_i2v_config(
            f"veo_3_1_i2v_s_lite_{suffix}",
            portrait,
            min_images=1,
            max_images=1,
            use_v2_model_config=True,
            allow_tier_upgrade=False,
        )
        MODEL_CONFIG[f"veo_3_1_interpolation_lite_{suffix}_landscape"] = _make_i2v_config(
            f"veo_3_1_i2v_s_lite_{suffix}_fl",
            landscape,
            min_images=2,
            max_images=2,
            use_v2_model_config=True,
            allow_tier_upgrade=False,
        )
        MODEL_CONFIG[f"veo_3_1_interpolation_lite_{suffix}_portrait"] = _make_i2v_config(
            f"veo_3_1_i2v_s_lite_{suffix}_fl",
            portrait,
            min_images=2,
            max_images=2,
            use_v2_model_config=True,
            allow_tier_upgrade=False,
        )
        MODEL_CONFIG[f"veo_3_1_i2v_s_{suffix}"] = _make_i2v_config(
            f"veo_3_1_i2v_s_quality_{suffix}_fl", landscape
        )
        MODEL_CONFIG[f"veo_3_1_i2v_s_portrait_{suffix}"] = _make_i2v_config(
            f"veo_3_1_i2v_s_quality_{suffix}_fl", portrait
        )

        for resolution_name, resolution, upsampler_model_key in (
            ("4k", "VIDEO_RESOLUTION_4K", "veo_3_1_upsampler_4k"),
            ("1080p", "VIDEO_RESOLUTION_1080P", "veo_3_1_upsampler_1080p"),
        ):
            upsample = {"resolution": resolution, "model_key": upsampler_model_key}
            MODEL_CONFIG[f"veo_3_1_t2v_{suffix}_{resolution_name}"] = _make_t2v_config(
                f"veo_3_1_t2v_quality_{suffix}", landscape, upsample=upsample
            )
            MODEL_CONFIG[f"veo_3_1_t2v_portrait_{suffix}_{resolution_name}"] = _make_t2v_config(
                f"veo_3_1_t2v_quality_{suffix}", portrait, upsample=upsample
            )
            MODEL_CONFIG[f"veo_3_1_i2v_s_{suffix}_{resolution_name}"] = _make_i2v_config(
                f"veo_3_1_i2v_s_quality_{suffix}_fl", landscape, upsample=upsample
            )
            MODEL_CONFIG[f"veo_3_1_i2v_s_portrait_{suffix}_{resolution_name}"] = _make_i2v_config(
                f"veo_3_1_i2v_s_quality_{suffix}_fl", portrait, upsample=upsample
            )

    for resolution_name, resolution, upsampler_model_key in (
        ("4k", "VIDEO_RESOLUTION_4K", "veo_3_1_upsampler_4k"),
        ("1080p", "VIDEO_RESOLUTION_1080P", "veo_3_1_upsampler_1080p"),
    ):
        upsample = {"resolution": resolution, "model_key": upsampler_model_key}
        MODEL_CONFIG[f"veo_3_1_t2v_{resolution_name}"] = _make_t2v_config(
            "veo_3_1_t2v", landscape, upsample=upsample
        )
        MODEL_CONFIG[f"veo_3_1_t2v_portrait_{resolution_name}"] = _make_t2v_config(
            "veo_3_1_t2v_portrait", portrait, upsample=upsample
        )
        MODEL_CONFIG[f"veo_3_1_i2v_s_{resolution_name}"] = _make_i2v_config(
            "veo_3_1_i2v_s_fl", landscape, upsample=upsample
        )
        MODEL_CONFIG[f"veo_3_1_i2v_s_portrait_{resolution_name}"] = _make_i2v_config(
            "veo_3_1_i2v_s_portrait_fl", portrait, upsample=upsample
        )

    for seconds in (4, 6):
        suffix = f"{seconds}s"

        # Explicit landscape names for /v1/models; short landscape names remain compatible.
        add_alias(f"veo_3_1_t2v_fast_landscape_{suffix}", f"veo_3_1_t2v_fast_{suffix}")
        add_alias(f"veo_3_1_t2v_landscape_{suffix}", f"veo_3_1_t2v_{suffix}")
        add_alias(f"veo_3_1_i2v_s_fast_landscape_{suffix}_fl", f"veo_3_1_i2v_s_fast_{suffix}_fl")
        add_alias(f"veo_3_1_i2v_s_landscape_{suffix}", f"veo_3_1_i2v_s_{suffix}")

        add_alias(f"veo_3_1_t2v_lite_landscape_{suffix}", f"veo_3_1_t2v_lite_{suffix}_landscape")
        add_alias(f"veo_3_1_t2v_lite_portrait_{suffix}", f"veo_3_1_t2v_lite_{suffix}_portrait")
        add_alias(f"veo_3_1_i2v_lite_landscape_{suffix}", f"veo_3_1_i2v_lite_{suffix}_landscape")
        add_alias(f"veo_3_1_i2v_lite_portrait_{suffix}", f"veo_3_1_i2v_lite_{suffix}_portrait")
        add_alias(
            f"veo_3_1_interpolation_lite_landscape_{suffix}",
            f"veo_3_1_interpolation_lite_{suffix}_landscape",
        )
        add_alias(
            f"veo_3_1_interpolation_lite_portrait_{suffix}",
            f"veo_3_1_interpolation_lite_{suffix}_portrait",
        )

        for resolution_name in ("4k", "1080p"):
            add_alias(
                f"veo_3_1_t2v_landscape_{suffix}_{resolution_name}",
                f"veo_3_1_t2v_{suffix}_{resolution_name}",
            )
            add_alias(
                f"veo_3_1_i2v_s_landscape_{suffix}_{resolution_name}",
                f"veo_3_1_i2v_s_{suffix}_{resolution_name}",
            )

    for resolution_name in ("4k", "1080p"):
        add_alias(f"veo_3_1_t2v_landscape_{resolution_name}", f"veo_3_1_t2v_{resolution_name}")
        add_alias(f"veo_3_1_i2v_s_landscape_{resolution_name}", f"veo_3_1_i2v_s_{resolution_name}")

    add_alias("veo_3_1_r2v_fast_landscape", "veo_3_1_r2v_fast")
    add_alias("veo_3_1_r2v_fast_landscape_ultra", "veo_3_1_r2v_fast_ultra")
    add_alias("veo_3_1_r2v_fast_landscape_ultra_relaxed", "veo_3_1_r2v_fast_ultra_relaxed")
    add_alias("veo_3_1_r2v_fast_landscape_ultra_4k", "veo_3_1_r2v_fast_ultra_4k")
    add_alias("veo_3_1_r2v_fast_landscape_ultra_1080p", "veo_3_1_r2v_fast_ultra_1080p")

    add_default_duration_aliases(
        "veo_3_1_t2v_fast",
        "veo_3_1_t2v_fast_landscape",
        "veo_3_1_t2v_fast_portrait",
    )
    add_default_duration_aliases(
        "veo_3_1_t2v",
        "veo_3_1_t2v_landscape",
        "veo_3_1_t2v_portrait",
    )
    add_default_duration_aliases(
        "veo_3_1_i2v_s_fast",
        "veo_3_1_i2v_s_fast_fl",
        "veo_3_1_i2v_s_fast_portrait_fl",
        fl_suffix=True,
    )
    add_default_duration_aliases(
        "veo_3_1_i2v_s",
        "veo_3_1_i2v_s_landscape",
        "veo_3_1_i2v_s_portrait",
    )
    add_default_duration_aliases(
        "veo_3_1_r2v_fast",
        "veo_3_1_r2v_fast",
        "veo_3_1_r2v_fast_portrait",
    )
    add_alias("veo_3_1_r2v_fast_ultra_8s", "veo_3_1_r2v_fast_ultra")
    add_alias("veo_3_1_r2v_fast_portrait_ultra_8s", "veo_3_1_r2v_fast_portrait_ultra")
    add_alias("veo_3_1_r2v_fast_landscape_ultra_8s", "veo_3_1_r2v_fast_ultra")
    add_alias(
        "veo_3_1_r2v_fast_ultra_relaxed_8s",
        "veo_3_1_r2v_fast_ultra_relaxed",
    )
    add_alias(
        "veo_3_1_r2v_fast_portrait_ultra_relaxed_8s",
        "veo_3_1_r2v_fast_portrait_ultra_relaxed",
    )
    add_alias(
        "veo_3_1_r2v_fast_landscape_ultra_relaxed_8s",
        "veo_3_1_r2v_fast_ultra_relaxed",
    )

    add_alias("veo_3_1_t2v_lite_8s_landscape", "veo_3_1_t2v_lite_landscape")
    add_alias("veo_3_1_t2v_lite_8s_portrait", "veo_3_1_t2v_lite_portrait")
    add_alias("veo_3_1_t2v_lite_landscape_8s", "veo_3_1_t2v_lite_landscape")
    add_alias("veo_3_1_t2v_lite_portrait_8s", "veo_3_1_t2v_lite_portrait")
    add_alias("veo_3_1_i2v_lite_8s_landscape", "veo_3_1_i2v_lite_landscape")
    add_alias("veo_3_1_i2v_lite_8s_portrait", "veo_3_1_i2v_lite_portrait")
    add_alias("veo_3_1_i2v_lite_landscape_8s", "veo_3_1_i2v_lite_landscape")
    add_alias("veo_3_1_i2v_lite_portrait_8s", "veo_3_1_i2v_lite_portrait")
    add_alias(
        "veo_3_1_interpolation_lite_8s_landscape",
        "veo_3_1_interpolation_lite_landscape",
    )
    add_alias(
        "veo_3_1_interpolation_lite_8s_portrait",
        "veo_3_1_interpolation_lite_portrait",
    )
    add_alias(
        "veo_3_1_interpolation_lite_landscape_8s",
        "veo_3_1_interpolation_lite_landscape",
    )
    add_alias(
        "veo_3_1_interpolation_lite_portrait_8s",
        "veo_3_1_interpolation_lite_portrait",
    )

    for resolution_name in ("4k", "1080p"):
        add_default_duration_upsample_aliases(
            "veo_3_1_t2v",
            resolution_name,
            f"veo_3_1_t2v_{resolution_name}",
            f"veo_3_1_t2v_portrait_{resolution_name}",
        )
        add_default_duration_upsample_aliases(
            "veo_3_1_i2v_s",
            resolution_name,
            f"veo_3_1_i2v_s_{resolution_name}",
            f"veo_3_1_i2v_s_portrait_{resolution_name}",
        )


_apply_veo_3_1_model_updates()


def _known_video_model_keys() -> set[str]:
    return {
        cfg["model_key"]
        for cfg in MODEL_CONFIG.values()
        if cfg.get("type") == "video" and cfg.get("model_key")
    }


def _resolve_tier_two_model_key(model_key: str) -> str:
    """Only upgrade to an ultra key when that exact upstream key is known valid."""
    if "ultra" in model_key:
        return model_key
    if "_fl" in model_key:
        candidate = model_key.replace("_fl", "_ultra_fl")
    else:
        candidate = model_key + "_ultra"
    return candidate if candidate in _known_video_model_keys() else model_key


class _ReferenceUploadAdmission:
    """Admit whole upload batches; never serialize references inside a batch.

    All bookkeeping is synchronous on the worker's event loop. Cancellation
    after a grant returns that grant as well as removing an ungranted waiter.
    Busy accounts cannot block other accounts; eligible batches stay FIFO.
    """

    def __init__(self, account_batches=2, reference_capacity=192, wait_seconds=120):
        if account_batches < 1 or reference_capacity < 1 or wait_seconds <= 0:
            raise ValueError("invalid upload admission limits")
        self.account_batches = account_batches
        self.reference_capacity = reference_capacity
        self.wait_seconds = wait_seconds
        self._active = {}
        self._active_limits = {}
        self._references = 0
        self._waiting = []

    def _grant_waiters(self):
        for waiter in tuple(self._waiting):
            account, cost = waiter["account"], waiter["cost"]
            limit = min(waiter.get("limit", self.account_batches),
                        self._active_limits.get(account, self.account_batches))
            if self._active.get(account, 0) >= limit:
                continue
            # Do not starve a larger eligible batch with smaller later ones.
            if self._references + cost > self.reference_capacity:
                break
            self._waiting.remove(waiter)
            self._active[account] = self._active.get(account, 0) + 1
            self._active_limits[account] = limit
            self._references += cost
            waiter["granted"] = True
            waiter["account_batches"] = self._active[account]
            waiter["reserved_references"] = self._references
            waiter["event"].set()

    async def acquire(self, account, references, *, account_limit=None):
        # An oversized batch is admitted exclusively, with all its children
        # still launched together, rather than deadlocking or dropping inputs.
        waiter = {"account": account, "cost": min(references, self.reference_capacity),
                  "limit": min(self.account_batches, max(1, account_limit or self.account_batches)),
                  "remaining_cost": min(references, self.reference_capacity),
                  "oversized": references > self.reference_capacity,
                  "event": asyncio.Event(), "granted": False}
        self._waiting.append(waiter)
        self._grant_waiters()
        try:
            async with asyncio.timeout(self.wait_seconds):
                await waiter["event"].wait()
            return waiter
        except BaseException:
            if waiter["granted"]:
                self.release(waiter)
            else:
                self._waiting.remove(waiter)
                self._grant_waiters()
            raise

    def snapshot(self, account, references, *, account_limit=None):
        """Numeric pressure evidence only; never expose account identities."""
        account_busy = self._active.get(account, 0) >= min(account_limit or self.account_batches,
            self._active_limits.get(account, self.account_batches))
        capacity_busy = self._references + min(references, self.reference_capacity) > self.reference_capacity
        return {"active_account_batches": self._active.get(account, 0),
                "active_batches": sum(self._active.values()),
                "reserved_references": self._references,
                "queued_batches": len(self._waiting),
                "queued_references": sum(w["cost"] for w in self._waiting),
                "blocking_reason": "account_and_capacity" if account_busy and capacity_busy else
                    "account_limit" if account_busy else "global_capacity" if capacity_busy else
                    "fifo_wait" if self._waiting else "available"}

    def reference_finished(self, waiter):
        # Return capacity after the child's HTTP resources have closed. Keep
        # the account batch lease until every sibling has finished/drained.
        # Oversized batches retain exclusive admission until the whole batch
        # ends, since their reservation undercounts actual children.
        if not waiter["granted"] or waiter["oversized"] or waiter["remaining_cost"] <= 0:
            return
        waiter["remaining_cost"] -= 1
        self._references -= 1
        self._grant_waiters()

    def release(self, waiter):
        if not waiter["granted"]:
            return
        waiter["granted"] = False
        account = waiter["account"]
        self._active[account] -= 1
        if self._active[account] == 0:
            del self._active[account]
            self._active_limits.pop(account, None)
        self._references -= waiter["remaining_cost"]
        waiter["remaining_cost"] = 0
        self._grant_waiters()


class GenerationHandler:
    """统一生成处理器"""

    def __init__(self, flow_client, token_manager, load_balancer, db, concurrency_manager, proxy_manager):
        cache_dir = Path(__file__).resolve().parents[2] / "tmp"
        self.flow_client = flow_client
        self._reference_upload_admission = _ReferenceUploadAdmission()
        self.token_manager = token_manager
        self.load_balancer = load_balancer
        self.db = db
        self.concurrency_manager = concurrency_manager
        self.file_cache = FileCache(
            cache_dir=str(cache_dir),
            default_timeout=config.cache_timeout,
            proxy_manager=proxy_manager,
            flow_client=flow_client,
        )

    def _create_generation_result(self) -> Dict[str, Any]:
        """????????????????"""
        return dict(success=False, error_message=None, error_emitted=False)

    def _create_response_state(self) -> Dict[str, Any]:
        """为单次请求创建独立的响应状态，避免并发请求互相污染。"""
        return {
            "url": None,
            "generated_assets": None,
            "base_url": None,
        }

    @staticmethod
    def _reference_image_metadata(image_bytes: bytes) -> Dict[str, Any]:
        """Validate original bytes; attach safe failure evidence without retaining them."""
        diagnostic = {"stage": "open", "failure_kind": "empty_or_non_bytes",
                      "input_bytes": len(image_bytes) if isinstance(image_bytes, bytes) else None}
        if isinstance(image_bytes, bytes):
            diagnostic["image_sha256"] = hashlib.sha256(image_bytes).hexdigest()
        if not isinstance(image_bytes, bytes) or not image_bytes:
            error = ValueError("invalid_reference_image:empty")
            error.flow2api_reference_precheck = diagnostic
            raise error
        diagnostic["failure_kind"] = "unrecognized_image"
        try:
            with Image.open(io.BytesIO(image_bytes)) as image:
                width, height = image.size
                image_format = str(image.format or "").lower()
                color_mode = image.mode if image.mode in {
                    "RGB", "RGBA", "CMYK", "L", "LA", "P", "1", "I", "F", "I;16"
                } else "other"
                has_icc = bool(image.info.get("icc_profile"))
                has_exif = bool(image.info.get("exif"))
                animated = bool(getattr(image, "is_animated", False))
                diagnostic.update(format=image_format if image_format in {
                    "jpeg", "png", "webp", "gif", "bmp", "jpeg2000", "tiff", "ico", "ppm", "mpo", "avif", "heif", "heic"
                } else "other", width=width, height=height, color_mode=color_mode,
                    has_icc=has_icc, has_exif=has_exif, animated=animated,
                    stage="format_and_dimensions")
                if width < 1 or height < 1 or image_format not in {
                    "jpeg", "png", "webp", "gif", "bmp", "jpeg2000"
                }:
                    diagnostic["failure_kind"] = "invalid_dimensions" if width < 1 or height < 1 else "unsupported_format"
                    raise ValueError("unsupported")
                diagnostic.update(stage="verify", failure_kind="container_verification_failed")
                image.verify()
            # JPEG.verify() does not decode its pixel stream. Fully decode
            # before choosing an account to reject incomplete pixel data.
            with Image.open(io.BytesIO(image_bytes)) as image:
                diagnostic.update(stage="pixel_decode", failure_kind="pixel_decode_failed")
                image.load()
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
            if isinstance(exc, Image.DecompressionBombError):
                diagnostic["failure_kind"] = "decompression_bomb"
            error = ValueError("invalid_reference_image:decode_or_dimensions")
            error.flow2api_reference_precheck = diagnostic
            raise error from exc
        size_bucket = (
            "under_1m" if len(image_bytes) < 1_000_000 else
            "under_5m" if len(image_bytes) < 5_000_000 else "5m_or_more"
        )
        edge = max(width, height)
        dimension_bucket = (
            "under_1k" if edge < 1024 else
            "under_2k" if edge < 2048 else
            "under_4k" if edge < 4096 else "4k_or_more"
        )
        return {
            "format": image_format,
            "input_bytes": len(image_bytes),
            "width": width, "height": height,
            "image_sha256": hashlib.sha256(image_bytes).hexdigest(),
            "bytes_bucket": size_bucket,
            "dimension_bucket": dimension_bucket,
            "color_mode": color_mode, "has_icc": has_icc,
            "has_exif": has_exif, "animated": animated,
        }

    @staticmethod
    def _max_image_account_attempts() -> int:
        """An explicit opt-in extends two accounts to three, never beyond three."""
        raw = os.getenv("FLOW2API_IMAGE_MAX_ACCOUNT_ATTEMPTS", "2")
        try:
            return max(1, min(3, int(raw)))
        except (TypeError, ValueError):
            return 1

    @staticmethod
    def _upsample_regeneration_decision(error, perf_trace, generation_result, response_state, model_config):
        """Only confirmed rejected upsample submissions can abandon an owned base."""
        decision = {"eligible": False, "reason": "not_upsample_failure"}
        if not str(error or "").startswith("image_upsample_failed:"):
            return decision
        resolution = "4K" if "4K" in str(model_config.get("upsample", "")) else "2K"
        if not model_config.get("upsample") or not str(error).startswith(f"image_upsample_failed:{resolution}:cause="):
            decision["reason"] = "upsample_resolution_contract_mismatch"
            return decision
        decision["reason"] = "upsample_evidence_missing"
        image = perf_trace.get("image_generation") or {}
        upsample = image.get("upsample") or {}
        attempts = upsample.get("attempts") or []
        assets = response_state.get("generated_assets") or {}
        if (not upsample.get("base_image_available") or not assets.get("origin_image_url")
                or assets.get("type") != "image" or not attempts):
            return decision
        if (generation_result.get("success") or response_state.get("url")
                or assets.get("upscaled_image") or image.get("output_delivered")
                or (image.get("output_validation") or {}).get("success")
                or upsample.get("final_success_attempt")):
            decision["reason"] = "output_already_accepted_or_delivered"
            return decision
        generated = (image.get("upstream_trace") or {}).get("generation_attempts") or []
        if not any(isinstance(a, dict) and a.get("success") is True for a in generated):
            return decision
        saw_risk = False
        for attempt in attempts:
            # A proven no-token solver attempt cannot make another attempt's
            # complete rejection unknown. Intermediate modern fallback must
            # carry the same unsent evidence as terminal solver exhaustion.
            if (isinstance(attempt, dict) and attempt.get("success") is False
                    and attempt.get("dispatch_started") is False
                    and attempt.get("recaptcha_ok") is False and attempt.get("phase") == "captcha"
                    and attempt.get("submission_outcome") == "not_dispatched"
                    and attempt.get("error_class") == "captcha_unavailable"
                    and (attempt.get("retry_blocked") == "captcha_providers_exhausted"
                         or (attempt.get("auth_mode") == "google_cookie_rpc"
                             and attempt.get("solver_called") is True
                             and not attempt.get("retry_blocked")
                             and attempt.get("fallback_to") == "yescaptcha"
                             and attempt.get("fallback_reason") == "captcha_unavailable_before_dispatch"
                             and not attempt.get("rpc_method")
                             and not attempt.get("http_status")
                             and not attempt.get("response_complete")
                             and not attempt.get("transport")))
                    and attempt.get("code") == "cookie_media_captcha_unavailable"
                    and not attempt.get("http_transport")
                    and not attempt.get("rpc_rejection_confirmed")):
                continue
            if not isinstance(attempt, dict) or attempt.get("success") is not False or attempt.get("retry_blocked"):
                decision["reason"] = "upsample_accepted_or_unknown_submission"
                return decision
            transfer = attempt.get("http_transport") or {}
            if (transfer.get("success") is True or transfer.get("submission_outcome") in {
                    "unknown", "http_response_unparsed"}):
                decision["reason"] = "upsample_accepted_or_unknown_submission"
                return decision
            cause = attempt.get("error_class") or attempt.get("error")
            if attempt.get("auth_mode") == "google_cookie_rpc":
                # Require the modern parser's full unique rejection proof;
                # an error string alone must never authorize regeneration.
                transfer = attempt.get("transport") or {}
                if (attempt.get("phase") != "rpc_parse"
                        or attempt.get("rpc_method") != "SPrCad"
                        or attempt.get("dispatch_started") is not True
                        or attempt.get("response_complete") is not True
                        or attempt.get("http_status") != 200
                        or attempt.get("submission_outcome") != "explicit_provider_rejection"
                        or attempt.get("rpc_rejection_confirmed") is not True
                        or attempt.get("rpc_public_error_present") is not True
                        or attempt.get("provider_code") != cause
                        or transfer.get("response_complete") is not True
                        or transfer.get("http_status") != 200):
                    decision["reason"] = "upsample_accepted_or_unknown_submission"
                    return decision
            if attempt.get("recaptcha_ok") is True:
                if not explicit_risk(cause):
                    decision["reason"] = "upsample_non_risk_rejection"
                    return decision
                saw_risk = True
            elif cause not in {"captcha_unavailable", "Failed to obtain reCAPTCHA token"}:
                decision["reason"] = "upsample_evidence_missing"
                return decision
        if not saw_risk or not explicit_risk(error, perf_trace):
            decision["reason"] = "upsample_non_risk_rejection"
            return decision
        decision.update(eligible=True, reason="upsample_cross_account_regeneration",
                        prior_base_abandoned=True, new_base_required=True,
                        upsample_attempts=len(attempts), submission_outcome="explicit_risk_rejection")
        return decision

    @staticmethod
    def _aggregate_retry_settlement(retry_trace):
        settlements = [a["retry_budget_settlement"] for a in retry_trace.get("account_attempts", [])
                       if isinstance(a.get("retry_budget_settlement"), dict)]
        if not settlements:
            return
        tokens = {}
        for settlement in settlements:
            for provider, count in settlement.get("tokens", {}).items():
                tokens[provider] = tokens.get(provider, 0) + count
        retry_trace["retry_budget_settlement"] = {
            "settled": True, "reservations": len(settlements), "tokens": tokens,
            "cost_basis": "conservative_unknown_solve" if any(
                s.get("cost_basis") == "conservative_unknown_solve" for s in settlements
            ) else "returned_tokens_estimate",
            **{key: round(sum(s.get(key, 0) for s in settlements), 6)
               for key in ("reserved_usd", "actual_cost_usd", "released_usd")},
        }

    @staticmethod
    def _parse_percentage(raw_value: Any) -> int:
        """Parse a fail-safe integer percentage in the inclusive range 0..100."""
        try:
            value = int(str(raw_value or "0").strip())
        except (TypeError, ValueError):
            return 0
        return max(0, min(100, value))

    @classmethod
    def _select_cross_account_retry_canary(cls) -> tuple[bool, int]:
        """Select the request-local cross-account retry arm exactly once."""
        percent = cls._parse_percentage(
            os.getenv("FLOW2API_CROSS_ACCOUNT_RETRY_PERCENT")
        )
        return percent > 0 and secrets.randbelow(100) < percent, percent

    @staticmethod
    def _cross_account_retry_reason(error: Any) -> Optional[str]:
        """Return an allowlisted pre-image failure class, or None.

        The canary deliberately excludes upload, upsample, content-policy and
        ambiguous transport failures.  Adding a class here requires evidence
        that the first account could not have produced an image.
        """
        message = str(error or "")
        if any(marker in message.lower() for marker in (
            "image_upsample", "project-scoped image upload", "invalid_reference_image:",
        )):
            return None
        public_codes = set(re.findall(r"\bPUBLIC_ERROR_[A-Z0-9_]{2,64}\b", message))
        if public_codes:
            if len(public_codes) != 1:
                return None
            code = next(iter(public_codes))
            if code in {
                "PUBLIC_ERROR_UNUSUAL_ACTIVITY",
                "PUBLIC_ERROR_UNUSUAL_ACTIVITY_TOO_MUCH_TRAFFIC",
                "PUBLIC_ERROR_PER_MODEL_DAILY_QUOTA_REACHED",
                "PUBLIC_ERROR_PER_MODEL_DAILY_QUOTA_REACHED_UPGRADEABLE",
            }:
                return code
            return None
        if message.strip().lower() == "failed to obtain recaptcha token":
            return "captcha_unavailable"
        return None

    @staticmethod
    def _upload_transport_retry_reason(error, perf_trace):
        """Only a proven upload transport failure before ANY generation attempt.

        Uploads can create unused reference media, never an image generation.
        Partial uploads are discarded; the next account uploads original bytes
        into its own project. Do not infer eligibility from generic error text.
        """
        message = str(error or "")
        if not message.startswith("Project-scoped image upload failed via /flow/uploadImage; "):
            return None
        image = perf_trace.get("image_generation") or {}
        if image.get("output_delivered") or image.get("output_validation") or image.get("upsample"):
            return None
        if (image.get("upstream_trace") or {}).get("generation_attempts"):
            return None
        upload = image.get("reference_upload") or {}
        admission = upload.get("admission") or {}
        if admission.get("status") == "timeout":
            # A local busy-account wait sent no HTTP and bought no CAPTCHA.
            # Do not switch on global capacity pressure or missing evidence.
            pressure = admission.get("pressure_at_timeout") or {}
            if ("cause=upload_queue_timeout; attempts=0" in message
                    and pressure.get("blocking_reason") == "account_limit"
                    and pressure.get("active_account_batches", 0) >= admission.get("max_account_batches", 2)
                    and upload.get("images")
                    and not any(ref.get("http_attempts") for ref in upload["images"])):
                return "reference_upload_account_queue"
            return None
        if admission.get("status") != "admitted":
            return None
        references = upload.get("images") or []
        transports = {"network_timeout", "proxy_dns_error", "dns_error", "connect_error",
                      "tls_error", "tls_verification_error", "send_error", "receive_error"}
        confirmed_failure = False
        for ref in references:
            attempts = ref.get("http_attempts") or []
            if len(attempts) > 2:
                return None
            for post in attempts:
                transfer = post.get("transport") or {}
                status = transfer.get("http_status_code", post.get("http_status_code"))
                if status is not None and (not isinstance(status, int) or not 100 <= status < 400):
                    return None
                if transfer.get("failure_phase") in {"response_decode", "image_decode", "local_processing"}:
                    return None
            if ref.get("status") == "failed":
                if ref.get("cause") not in {"network_timeout", "transport"} or not attempts:
                    return None
                transfer = attempts[-1].get("transport") or {}
                # libcurl 16 is an HTTP/2 transport failure. A failed reference
                # upload cannot generate an image, even if upload commit is
                # unknown. Keep this exception local to uploads; never infer
                # generation/upsample replay safety from this curl code.
                http2_upload_failure = (
                    transfer.get("failure_kind") == "transport_error"
                    and transfer.get("curl_code") == 16
                    and transfer.get("stage") == "reference_upload"
                    and transfer.get("dispatch_started") is True
                    and transfer.get("failure_phase") == "transport"
                    and transfer.get("http_status_code") is None
                    and transfer.get("response_complete") is not True
                    and transfer.get("submission_outcome") == "unknown"
                    and attempts[-1].get("success") is False
                )
                if transfer.get("failure_kind") not in transports and not http2_upload_failure:
                    return None
                confirmed_failure = True
        return "reference_upload_transport" if confirmed_failure else None

    @staticmethod
    def _upload_internal_retry_reason(error, perf_trace, reference_metadata, account_id, consumed=0):
        """One complete upload INTERNAL recovery before any generation POST."""
        if consumed or not str(error or "").startswith("Project-scoped image upload failed via /flow/uploadImage; "):
            return None
        image = perf_trace.get("image_generation") or {}
        if (image.get("output_delivered") or image.get("output_validation") or image.get("upsample")
                or (image.get("upstream_trace") or {}).get("generation_attempts")):
            return None
        upload = image.get("reference_upload") or {}
        refs = upload.get("images") or []
        if ((upload.get("admission") or {}).get("status") != "admitted"
                or not reference_metadata or len(refs) != len(reference_metadata)):
            return None
        failed = False
        for index, (ref, expected) in enumerate(zip(refs, reference_metadata), 1):
            # A sibling cancelled by the parallel upload supervisor may have
            # only parallel_outcome, without a terminal upload status or POST
            # record. It still belongs to this exact original/account and no
            # generation is allowed until all references have uploaded.
            ref_status = ref.get("status") or (
                "cancelled" if ref.get("parallel_outcome") == "cancelled" else None)
            if (ref.get("index") != index or ref.get("account_id") != account_id
                    or any(ref.get(k) != expected.get(k) for k in MATCH_FIELDS)
                    or ref_status not in {"uploaded", "cancelled", "failed"}):
                return None
            rpc = ref.get('rpc_trace')
            if isinstance(rpc, dict):
                # Cookie upload errors are HTTP200 with an explicit gRPC
                # status. Only complete, unique INTERNAL(13) rejection of
                # maseQ is eligible, within the EXISTING one recovery budget.
                # Bare INVALID_ARGUMENT/RESOURCE_EXHAUSTED have no safe
                # retry proof. Never treat them as a risk or quota enum.
                attempts = ref.get('rpc_attempts') or [rpc]
                if not isinstance(attempts, list) or len(attempts) > 2:
                    return None
                for attempt in attempts:
                    if not isinstance(attempt, dict):
                        return None
                    if attempt.get('code') == 'CancelledError' and not attempt.get('dispatch_started'):
                        continue  # A drained sibling sent no provider RPC.
                    if (attempt.get('rpc_method') != 'maseQ'
                            or attempt.get('response_complete') is not True
                            or attempt.get('http_status') != 200 or attempt.get('provider_code')):
                        return None
                    if attempt.get('success') is True:
                        if attempt.get('submission_outcome') != 'rpc_accepted':
                            return None
                    elif (attempt.get('success') is not False
                            or attempt.get('rpc_rejection_confirmed') is not True
                            or attempt.get('rpc_public_error_present') is not False
                            or attempt.get('submission_outcome') != 'explicit_provider_rejection'
                            or type(attempt.get('rpc_status_code')) is not int
                            or attempt.get('rpc_status_code') != 13
                            or attempt.get('rpc_status_name') != 'INTERNAL'):
                        return None
                if ref_status == 'failed':
                    if ref.get('parallel_outcome') == 'cancelled' and not rpc.get('dispatch_started'):
                        continue
                    if (ref.get('cause') != 'rpc_internal' or rpc.get('success') is not False
                            or rpc.get('rpc_status_code') != 13):
                        return None
                    failed = True
                continue
            posts = ref.get("http_attempts") or []
            if len(posts) > 2:
                return None
            for post in posts:
                t = post.get("transport") or {}
                status = t.get("http_status_code")
                if (t.get("response_complete") is not True or t.get("submission_outcome") != "http_response"
                        or t.get("failure_phase") in {"response_decode", "image_decode", "local_processing"}):
                    return None
                if status == 500:
                    google = t.get("google_error") or {}
                    if post.get("success") is not False or google.get("code") != 500 or google.get("status") != "INTERNAL":
                        return None
                elif status != 200 or post.get("success") is not True:
                    return None
            if ref_status == "failed":
                if (not posts or ref.get("cause") not in {"upstream_http_500", "upstream_http_500:INTERNAL"}
                        or (posts[-1].get("transport") or {}).get("http_status_code") != 500):
                    return None
                failed = True
        return "reference_upload_internal" if failed else None

    @staticmethod
    def _upload_busy_retry_decision(error, perf_trace, reference_metadata, account_id, consumed=0):
        # Preserve existing callers; numeric deadline recovery has its own log.
        if not str(error or "").startswith("Project-scoped image upload failed via /flow/uploadImage; cause=rpc_high_traffic;"):
            return {"eligible": False, "reason": "not_upload_busy", "max_recoveries": 1,
                    "shared_budget": "upload_internal_recoveries"}
        return GenerationHandler._upload_technical_retry_decision(
            error, perf_trace, reference_metadata, account_id, consumed)

    @staticmethod
    def _upload_technical_retry_decision(error, perf_trace, reference_metadata, account_id, consumed=0):
        """One complete busy/deadline upload recovery; every sibling must be settled or unsent.

        Shares the existing INTERNAL recovery allowance. Never authorizes a
        generation, content-policy, risk-control or uncertain RPC replay.
        """
        decision = {"eligible": False, "reason": "not_upload_technical_failure", "max_recoveries": 1,
                    "shared_budget": "upload_internal_recoveries"}
        message = str(error or "")
        deadline = message.startswith("Project-scoped image upload failed via /flow/uploadImage; cause=rpc_deadline_exceeded;")
        if not deadline and not message.startswith(
                "Project-scoped image upload failed via /flow/uploadImage; cause=rpc_high_traffic;"):
            return decision
        def reject(reason):
            return dict(decision, reason=reason)
        if consumed:
            return reject("upload_technical_recovery_limit")
        image = perf_trace.get("image_generation") or {}
        if (image.get("output_delivered") or image.get("output_validation") or image.get("upsample")
                or (image.get("upstream_trace") or {}).get("generation_attempts")):
            return reject("generation_or_output_observed")
        upload = image.get("reference_upload") or {}
        refs = upload.get("images") or []
        if ((upload.get("admission") or {}).get("status") != "admitted"
                or not reference_metadata or len(refs) != len(reference_metadata)):
            return reject("upload_reference_evidence_missing")
        busy = False
        for index, (ref, expected) in enumerate(zip(refs, reference_metadata), 1):
            if (not isinstance(ref, dict) or not isinstance(expected, dict)
                    or ref.get("index") != index or ref.get("account_id") != account_id
                    or any(expected.get(k) is None or ref.get(k) != expected[k] for k in MATCH_FIELDS)
                    or ref.get("status") not in {"uploaded", "failed", "cancelled"}):
                return reject("original_reference_binding_mismatch")
            attempts = ref.get("rpc_attempts") or [ref.get("rpc_trace")]
            if not isinstance(attempts, list) or not 1 <= len(attempts) <= 2:
                return reject("upload_attempt_evidence_missing")
            terminal = None
            for attempt in attempts:
                if not isinstance(attempt, dict):
                    return reject("upload_attempt_evidence_missing")
                # Exact pre-dispatch cancellation or unavailable-solver result,
                # including an earlier solver fallback. No Google RPC was sent.
                if (attempt.get("dispatch_started") is False and attempt.get("success") is False
                        and attempt.get("recaptcha_ok") is False and attempt.get("phase") == "captcha"
                        and attempt.get("code") in {"CancelledError", "cookie_media_captcha_unavailable"}
                        and not attempt.get("transport") and not attempt.get("http_transport")
                        and not attempt.get("rpc_method") and not attempt.get("rpc_rejection_confirmed")
                        and not attempt.get("provider_code")
                        and attempt.get("submission_outcome") in {None, "not_dispatched"}):
                    terminal = "unsent"
                    continue
                if (attempt.get("rpc_method") != "maseQ" or attempt.get("dispatch_started") is not True
                        or attempt.get("response_complete") is not True or attempt.get("http_status") != 200):
                    return reject("upload_sibling_accepted_or_unknown")
                if (attempt.get("success") is True and attempt.get("submission_outcome") == "rpc_accepted"
                        and not attempt.get("provider_code") and not attempt.get("rpc_rejection_confirmed")):
                    terminal = "uploaded"
                    continue
                # Numeric RPC4 is a complete failed upload response, not a curl
                # timeout or a generation timeout. Unknown sibling outcomes
                # remain blocked by the complete-response checks above.
                if (deadline and attempt.get("success") is False
                        and attempt.get("submission_outcome") == "explicit_provider_rejection"
                        and attempt.get("rpc_rejection_confirmed") is True
                        and attempt.get("rpc_public_error_present") is False
                        and type(attempt.get("rpc_status_code")) is int
                        and attempt.get("rpc_status_code") == 4
                        and attempt.get("rpc_status_name") == "DEADLINE_EXCEEDED"
                        and not attempt.get("provider_code")
                        and attempt.get("error_class") == "rpc_provider_error"):
                    terminal = "busy"
                    busy = True
                    continue
                if (deadline or attempt.get("success") is not False
                        or attempt.get("submission_outcome") != "explicit_provider_rejection"
                        or attempt.get("rpc_rejection_confirmed") is not True
                        or attempt.get("rpc_public_error_present") is not True
                        or type(attempt.get("rpc_status_code")) is not int
                        or attempt.get("rpc_status_code") != 8
                        or attempt.get("rpc_status_name") != "RESOURCE_EXHAUSTED"
                        or attempt.get("provider_code") != "PUBLIC_ERROR_HIGH_TRAFFIC"
                        or attempt.get("error_class") != "PUBLIC_ERROR_HIGH_TRAFFIC"):
                    return reject("upload_non_busy_or_unknown_rejection")
                terminal = "busy"
                busy = True
            if ((ref["status"] == "uploaded" and terminal != "uploaded")
                    or (ref["status"] in {"failed", "cancelled"} and terminal not in {"busy", "unsent"})):
                return reject("upload_terminal_evidence_mismatch")
        if not busy:
            return reject("upload_busy_rejection_missing")
        return dict(decision, eligible=True, reason="reference_upload_deadline" if deadline else "reference_upload_busy",
                    generation_dispatched=False, submission_outcome="explicit_provider_rejection")

    async def _known_success_upload_400_decision(self, error, perf_trace, reference_metadata,
                                                account_id, consumed=0):
        """One original-byte recovery, only before any image submission.

        Read-only successful-upload proof is bounded. Unknown error reasons,
        mixed failures, explicit input/content failures and missing traces fail
        closed. No image, project or old media is copied between accounts.
        """
        decision = {"eligible": False, "reason": "not_proven_upload_400", "max_recoveries": 1}
        if not str(error or "").startswith("Project-scoped image upload failed via /flow/uploadImage; "):
            return decision
        if consumed >= 1:
            return {**decision, "reason": "known_success_400_retry_limit"}
        image = perf_trace.get("image_generation") or {}
        if (image.get("output_delivered") or image.get("output_validation") or image.get("upsample")
                or (image.get("upstream_trace") or {}).get("generation_attempts")):
            return {**decision, "reason": "image_submission_observed"}
        upload = image.get("reference_upload") or {}
        refs = upload.get("images") or []
        if ((upload.get("admission") or {}).get("status") != "admitted"
                or not reference_metadata or len(refs) != len(reference_metadata)):
            return decision
        failed = []
        for index, (ref, expected) in enumerate(zip(refs, reference_metadata), 1):
            if (ref.get("index") != index or ref.get("account_id") != account_id
                    or any(ref.get(k) != expected.get(k) for k in MATCH_FIELDS)):
                return {**decision, "reason": "reference_identity_unproven"}
            rpc = ref.get('rpc_trace')
            if isinstance(rpc, dict):
                # Modern equivalent of the existing generic HTTP400 rule:
                # complete maseQ INVALID_ARGUMENT without a public enum, plus
                # SAME ORIGINAL BYTES success on another account below.
                status = ref.get('status')
                attempts = ref.get('rpc_attempts') or [rpc]
                if (status not in {'uploaded', 'failed', 'cancelled'}
                        or not isinstance(attempts, list) or not 1 <= len(attempts) <= 2):
                    return {**decision, 'reason': 'non_generic_or_unproven_400'}
                for attempt in attempts:
                    if not isinstance(attempt, dict):
                        return {**decision, 'reason': 'non_generic_or_unproven_400'}
                    if (status == 'cancelled' and attempt.get('dispatch_started') is False
                            and attempt.get('code') == 'CancelledError'):
                        continue
                    if (attempt.get('rpc_method') != 'maseQ'
                            or attempt.get('http_status') != 200
                            or attempt.get('response_complete') is not True
                            or attempt.get('provider_code')):
                        return {**decision, 'reason': 'mixed_or_unknown_rpc_upload'}
                    if attempt.get('success') is True:
                        if attempt.get('submission_outcome') != 'rpc_accepted':
                            return {**decision, 'reason': 'mixed_or_unknown_rpc_upload'}
                    elif (attempt.get('success') is not False
                            or attempt.get('rpc_rejection_confirmed') is not True
                            or attempt.get('submission_outcome') != 'explicit_provider_rejection'
                            or attempt.get('rpc_public_error_present') is not False
                            or type(attempt.get('rpc_status_code')) is not int
                            or attempt.get('rpc_status_code') != 3
                            or attempt.get('rpc_status_name') != 'INVALID_ARGUMENT'):
                        return {**decision, 'reason': 'non_generic_or_unproven_400'}
                if status == 'failed':
                    if ref.get('cause') != 'rpc_invalid_argument' or rpc.get('success') is not False:
                        return {**decision, 'reason': 'non_generic_or_unproven_400'}
                    failed.append((index, ref))
                elif status == 'uploaded' and rpc.get('success') is not True:
                    return {**decision, 'reason': 'mixed_or_unknown_rpc_upload'}
                continue
            posts = ref.get("http_attempts") or []
            if len(posts) > 2 or ref.get("status") not in {"uploaded", "cancelled", "failed"}:
                return decision
            for post in posts:
                t = post.get("transport") or {}
                status = t.get("http_status_code")
                if ref.get("status") == "failed":
                    google = t.get("google_error") or {}
                    if (post.get("success") is not False or status != 400
                            or t.get("response_complete") is not True
                            or t.get("submission_outcome") != "http_response"
                            or t.get("provider_400_hints") != ["unspecified"]
                            or t.get("upload_400_reason_policy") != "generic_invalid_argument"
                            or google.get("status") != "INVALID_ARGUMENT"
                            or google.get("message_template") != "generic_invalid_argument"):
                        return {**decision, "reason": "non_generic_or_unproven_400"}
                elif status is not None and (type(status) is not int or status >= 400):
                    return {**decision, "reason": "mixed_upload_failure"}
            if ref.get("status") == "failed":
                if not posts or ref.get("cause") != "upstream_http_400:INVALID_ARGUMENT":
                    return decision
                failed.append((index, ref))
        if not failed:
            return decision
        proofs = []
        for index, ref in failed:
            proof = await find_success(getattr(self.db, "db_path", None), ref, account_id)
            proofs.append({"reference_index": index, **proof})
            if proof.get("found") is not True:
                return {**decision, "reason": proof.get("reason", "missing_success_proof"), "proofs": proofs}
        return {**decision, "eligible": True, "reason": "reference_upload_known_success_400", "proofs": proofs}

    async def _partial_send_alternative(self, model, model_quota_key, account_id, minimum_bytes, selected):
        decision = {"selected": selected, "eligible": False, "skipped_same_exit_retry": False,
                    "configured_percent": 10, "reason": "not_selected"}
        if not selected:
            return decision
        failed = upload_egress.identity(account_id)
        if failed is None:
            return {**decision, "reason": "upload_egress_identity_unavailable"}
        healthy = await upload_egress.healthy_accounts(getattr(self.db, "db_path", None), minimum_bytes)
        excluded = self._reference_upload_exclusions([True]) | self._busy_reference_upload_accounts()
        cooldown = await self.token_manager.get_token_ids_in_model_cooldown(model_quota_key) if model_quota_key else set()
        for candidate in await self.token_manager.get_active_tokens():
            aid = int(candidate.id)
            route = upload_egress.identity(aid)
            if (aid == account_id or aid not in healthy or aid in excluded or aid in cooldown
                    or not route or route["assigned_exit_sha256"] == failed["assigned_exit_sha256"]
                    or not candidate.image_enabled or self.token_manager.needs_at_refresh(candidate)
                    or not supports_model_for_tier(model, normalize_user_paygate_tier(candidate.user_paygate_tier))):
                continue
            ok, _ = await self.load_balancer._check_extension_route(candidate)
            if ok:
                return {**decision, "eligible": True, "skipped_same_exit_retry": True,
                        "reason": "partial_send_distinct_healthy_exit", "alternate_account_id": aid,
                        "alternate_exit_sha256": route["assigned_exit_sha256"]}
        return {**decision, "reason": "no_recent_healthy_distinct_exit"}

    def _upload_transport_exclusions(self):
        pauses = getattr(self, "_upload_transport_pauses", None)
        if pauses is None:
            pauses = self._upload_transport_pauses = {}
        now = time.monotonic()
        for account, until in list(pauses.items()):
            if until <= now:
                del pauses[account]
        return set(pauses)

    def _busy_reference_upload_accounts(self):
        admission = getattr(self, "_reference_upload_admission", None)
        busy = ({account for account, batches in admission._active.items()
                 if isinstance(account, int) and batches >= admission.account_batches}
                if admission is not None else set())
        pipeline = getattr(self, "_cookie_image_pipeline_admission", None)
        if pipeline is not None:
            busy |= {account for account, batches in pipeline._active.items()
                     if isinstance(account, int) and batches >= getattr(pipeline,
                         "_active_limits", {}).get(account, pipeline.account_batches)}
        return busy

    def _upload_exit_backoff(self):
        breaker = getattr(self, "_upload_exit_breaker", None)
        if breaker is None:
            breaker = self._upload_exit_breaker = UploadExitBackoff()
        return breaker

    def _reference_upload_exclusions(self, images):
        if not images:
            return set()
        result = self._upload_transport_exclusions()
        breaker = self._upload_exit_backoff()
        scheduler = breaker.scheduler_active()
        result |= {key[1] for key in scheduler if key[0] == "account"}
        active = breaker.active() | {key[1] for key in scheduler if key[0] == "exit"}
        if active:
            result |= {aid for aid, route in upload_egress.routes().items()
                       if route["assigned_exit_sha256"] in active}
        return result

    @staticmethod
    def _upload_scheduler_timeout(error, upload_trace):
        """Narrow modern upload evidence; this predicate grants NO retry."""
        if (not str(error or "").startswith(
                "Project-scoped image upload failed via /flow/uploadImage; cause=network_timeout;")
                or (upload_trace or {}).get("admission", {}).get("status") != "admitted"):
            return False
        for ref in (upload_trace or {}).get("images") or []:
            rpc = ref.get("rpc_trace") or {}
            transport = rpc.get("transport") or {}
            duration = transport.get("duration_ms")
            if (ref.get("status") == "failed" and ref.get("cause") == "network_timeout"
                    and rpc.get("auth_mode") == "google_cookie_rpc"
                    and rpc.get("rpc_method") == "maseQ" and rpc.get("success") is False
                    and rpc.get("dispatch_started") is True
                    and rpc.get("phase") == "rpc_dispatch"
                    and rpc.get("code") == "rpc_transport_unavailable_curl_28"
                    and rpc.get("submission_outcome") == "unknown"
                    and transport.get("curl_code") == 28
                    and rpc.get("http_status") is None
                    and transport.get("http_status") is None
                    and transport.get("response_complete") is False
                    and type(duration) in (int, float) and math.isfinite(duration) and duration >= 1000):
                return True
        return False

    def _observe_upload_schedule(self, account, digest, started, upload_trace, error=None):
        """Observe a whole settled batch, not individual parallel children."""
        breaker = self._upload_exit_backoff()
        event = None
        if error is not None and self._upload_scheduler_timeout(error, upload_trace):
            event = breaker.observe_timeout(account, digest)
            event["trigger"] = "cookie_upload_timeout_unknown"
        elif error is None:
            refs = (upload_trace or {}).get("images") or []
            if refs and all(ref.get("status") == "uploaded"
                    and (ref.get("rpc_trace") or {}).get("rpc_method") == "maseQ"
                    and (ref.get("rpc_trace") or {}).get("success") is True
                    and (ref.get("rpc_trace") or {}).get("submission_outcome") == "rpc_accepted"
                    and ((ref.get("rpc_trace") or {}).get("transport") or {}).get("response_complete") is True
                    for ref in refs):
                cleared = breaker.observe_success(account, digest, started)
                if cleared:
                    event = {"policy": "upload_timeout_scheduler_v1", "trigger": "complete_upload_success",
                             "cleared_scopes": cleared, "authorizes_replay": False}
        if event is not None:
            event.update(account_id=account, assigned_exit_sha256=digest,
                         registry_identity_available=digest is not None)
            if isinstance(upload_trace, dict):
                upload_trace["scheduler_backoff"] = event
            try:
                print("[UPLOAD_SCHEDULER_BACKOFF] " + json.dumps(event, sort_keys=True), flush=True)
            except Exception:
                pass

    @staticmethod
    def _image_retry_admission_limit(configured, reason, prior_upload_transport=False):
        # Two bounded 120s upload POSTs can finish just after the normal 240s
        # generation retry admission closes. Proven upload transport recovery
        # and its subsequent explicit risk refusal share 360s; disabled0 stays disabled.
        risk = reason in {"PUBLIC_ERROR_UNUSUAL_ACTIVITY", "PUBLIC_ERROR_UNUSUAL_ACTIVITY_TOO_MUCH_TRAFFIC"}
        extended = reason == "reference_upload_transport" or (prior_upload_transport and risk)
        return max(360, configured) if extended and configured > 0 else configured

    async def _select_image_recovery_account(self, *, model, model_config, model_quota_key,
                                             images, attempted_ids, exit_exclusions,
                                             preferred_upload_accounts, failed_upload_exits,
                                             retry_deadline, account_attempt):
        excluded = set(attempted_ids) | exit_exclusions | self._reference_upload_exclusions(images)
        common = dict(for_image_generation=True, model=model, model_quota_key=model_quota_key,
                      reserve=False, enforce_concurrency_filter=False, track_pending=True)
        if model_config.get("upsample") == "UPSAMPLE_IMAGE_RESOLUTION_4K":
            remaining = retry_deadline - time.monotonic()
            admission = account_attempt["pool_admission"] = {
                "policy": "idle_cookie_pool_fair_v2", "scope": "cross_account_recovery",
                "status": "waiting", "max_account_pipelines": 5,
                "dispatch_started": False, "upload_posts": 0,
                "remaining_retry_admission_ms": max(0, int(remaining * 1000)),
            }
            if remaining <= 0:
                admission["status"] = "retry_admission_deadline"
                return None
            # Join the same queue as primary 4K requests. An optional recent-exit
            # preference must not bind a busy jar or bypass an older waiter.
            wait = min(120.0, remaining)
            admission["wait_timeout_seconds"] = wait
            return await self.load_balancer.select_token(
                **common, excluded_token_ids=excluded, idle_cookie_only=True,
                wait_idle_seconds=wait, selection_diagnostic=admission)

        # Preserve the existing 1K/2K recovery selection policy.
        token = None
        if preferred_upload_accounts and failed_upload_exits:
            token = await self.load_balancer.select_token(**common,
                excluded_token_ids=excluded | self._busy_reference_upload_accounts()
                    | (set(range(1, 256)) - preferred_upload_accounts))
            account_attempt["recent_healthy_exit_selected"] = token is not None
        if token is None:
            token = await self.load_balancer.select_token(**common,
                excluded_token_ids=excluded | (self._busy_reference_upload_accounts() if images else set()))
        if token is None and images and self._busy_reference_upload_accounts() - excluded:
            token = await self.load_balancer.select_token(**common, excluded_token_ids=excluded)
            account_attempt["busy_account_fallback"] = token is not None
        return token

    def _pause_upload_transport_account(self, account, account_attempt):
        self._upload_transport_exclusions()
        self._upload_transport_pauses[int(account)] = time.monotonic() + 120
        account_attempt["upload_transport_backoff"] = {"seconds": 120, "scope": "image_scheduler",
                                                       "persistent_account_mutation": False}
        route = upload_egress.identity(account)
        if route:
            account_attempt["upload_exit_backoff"] = self._upload_exit_backoff().failed(route["assigned_exit_sha256"])

    @staticmethod
    def _generation_submission_observed(perf_trace: Dict[str, Any]) -> bool:
        """A successful upstream submission blocks another image creation.

        This covers exceptions between upstream acceptance and populating the
        client-visible result state. Unknown transport outcomes also fail closed.
        """
        image = perf_trace.get("image_generation") or {}
        upstream = image.get("upstream_trace") or {}
        for attempt in upstream.get("generation_attempts") or []:
            if not isinstance(attempt, dict):
                continue
            transports = ([attempt["http_transport"]] if isinstance(attempt.get("http_transport"), dict) else [])
            transports += [call.get("transport") or {} for call in attempt.get("http_attempts") or []
                           if isinstance(call, dict)]
            if any(t.get("submission_outcome") in {"unknown", "http_response_unparsed", "accepted"}
                   for t in transports):
                return True
            if attempt.get("success") is True:
                return True
            if any(call.get("success") is True for call in attempt.get("http_attempts") or []
                   if isinstance(call, dict)):
                return True
            if attempt.get("recaptcha_ok") and attempt.get("success") is False:
                # A timeout/unknown failure after a token-backed submission is
                # not evidence that Google did not create an image.
                if (FlowClient._image_provider_retry_reason(attempt.get("error")) is None
                        and GenerationHandler._cross_account_retry_reason(attempt.get("error")) is None):
                    return True
        return False

    @staticmethod
    def _classify_public_image_error(error: Any) -> Optional[Dict[str, Any]]:
        """Map private/provider failures to a stable, non-secret public contract."""
        policy = image_content_policy.rejection(error)
        if policy:
            return {
                "status_code": 422, "type": "invalid_request_error",
                "code": "content_policy_violation",
                "message": "Image request rejected by the provider content policy.",
                "stage": policy["stage"], "reason": policy["reason"],
            }
        message = str(error or "")
        public_code_match = re.search(r"\bPUBLIC_ERROR_[A-Z0-9_]{2,64}\b", message)
        public_code = public_code_match.group(0) if public_code_match else ""

        aspect_reasons = {
            "original_aspect_matching_reference_required": "matching_reference_required",
            "original_aspect_reference_geometry_unverified": "reference_geometry_unverified",
            "original_aspect_unsupported": "aspect_not_supported_by_route",
            "original_aspect_cookie_rpc_required": "cookie_rpc_required",
        }
        if message in aspect_reasons:
            # A route capability mismatch is not a transient Google failure or
            # a content refusal. 503 preserves existing cross-channel selection;
            # it grants no same-account retries and changes no reference bytes.
            return {
                "status_code": 503, "type": "server_error",
                "code": "flow_reference_aspect_unsupported",
                "message": "This Flow route requires a verified first reference image matching the requested aspect ratio. Use a compatible image route.",
                "stage": "reference_precheck", "reason": aspect_reasons[message],
            }
        if message == "original_aspect_reference_invalid":
            return {
                "status_code": 422, "type": "invalid_request_error",
                "code": "invalid_reference_image",
                "message": "A reference image cannot be decoded or has invalid dimensions.",
                "stage": "reference_precheck", "reason": "reference_invalid",
            }

        if str(error or "").startswith("flow_account_capacity_unavailable:"):
            return {
                "status_code": 503, "type": "server_error",
                "code": "flow_account_capacity_unavailable",
                "message": "All eligible Flow account pipelines are busy. Please retry later.",
                "stage": "account_admission", "reason": "account_pipeline_queue_timeout",
                "retry_after_seconds": 15,
            }
        if str(error or "").startswith("invalid_reference_image:"):
            return {
                "status_code": 422, "type": "invalid_request_error",
                "code": "invalid_reference_image",
                "message": "A reference image cannot be decoded or has invalid dimensions.",
                "stage": "reference_upload",
            }
        if "Project-scoped image upload failed via /flow/uploadImage;" in message:
            cause_match = re.search(r"\bcause=([a-z_0-9]+)", message)
            cause = cause_match.group(1) if cause_match else "unknown"
            if cause == "upload_queue_timeout":
                reason = "upload_queue_timeout"
            elif cause == "rpc_high_traffic":
                reason = "upstream_busy"
            elif cause in {"rpc_internal", "rpc_deadline_exceeded", "rpc_invalid_argument", "rpc_resource_exhausted", "rpc_provider_rejection"}:
                reason = cause
            elif cause == "network_timeout":
                reason = "network_timeout"
            elif cause == "upload_missing_media":
                reason = "missing_media"
            elif cause == "upstream_http_400":
                reason = "upstream_400"
            elif cause in {"transport", "network_error"} or cause.endswith("error"):
                reason = "transport"
            else:
                reason = "unknown"
            return {
                "status_code": 502, "type": "server_error",
                "code": "reference_upload_failed",
                "message": "The reference image could not be uploaded to Flow.",
                "stage": "reference_upload", "reason": reason,
            }
        if is_shared_flash_404(error) or message.startswith("flow_model_temporarily_unavailable:"):
            retry_match = re.search(r"\bretry_after=(\d{1,4})\b", message)
            return {
                "status_code": 503, "type": "server_error",
                "code": "flow_model_temporarily_unavailable",
                "message": "The requested Flow image model is temporarily unavailable.",
                "stage": "generate",
                "retry_after_seconds": int(retry_match.group(1)) if retry_match else None,
            }

        if public_code == "PUBLIC_ERROR_UNSAFE_GENERATION":
            return {
                "status_code": 422,
                "type": "invalid_request_error",
                "code": "content_policy_violation",
                "message": "Image request rejected by the provider content policy.",
            }
        if public_code in {
            "PUBLIC_ERROR_UNUSUAL_ACTIVITY",
            "PUBLIC_ERROR_UNUSUAL_ACTIVITY_TOO_MUCH_TRAFFIC",
        }:
            return {
                "status_code": 503,
                "type": "server_error",
                "code": "google_risk_control_rejected",
                "message": "Google risk control rejected this image attempt. Please try again later.",
            }
        if public_code in {
            "PUBLIC_ERROR_PER_MODEL_DAILY_QUOTA_REACHED",
            "PUBLIC_ERROR_PER_MODEL_DAILY_QUOTA_REACHED_UPGRADEABLE",
        }:
            return {
                "status_code": 503,
                "type": "server_error",
                "code": "flow_account_pool_unavailable",
                "message": "No eligible Flow account is currently available for this model.",
            }
        if (message.strip().lower() in {"failed to obtain recaptcha token", "cookie_media_captcha_unavailable"}
                or re.fullmatch(r"image_upsample_failed:(?:2K|4K):cause=captcha_unavailable", message)):
            return {
                "status_code": 503,
                "type": "server_error",
                "code": "captcha_unavailable",
                "message": "CAPTCHA verification is temporarily unavailable. Please try again later.",
            }
        if message == "image_original_aspect_output_validation_failed":
            return {
                "status_code": 502, "type": "server_error",
                "code": "image_output_validation_failed",
                "message": "The generated image could not be verified for the requested aspect ratio.",
                "stage": "output_validation", "reason": "unverified_output",
            }
        if "image_upsample_failed:" in message:
            return {
                "status_code": 502,
                "type": "server_error",
                "code": "image_upsample_failed",
                "message": "The requested image upsample could not be completed and verified.",
            }
        return None

    def _mark_generation_failed(self, generation_result: Optional[Dict[str, Any]], error_message: str):
        """????????????????????"""
        if isinstance(generation_result, dict):
            generation_result["success"] = False
            generation_result["error_message"] = error_message
            generation_result["error_emitted"] = True

    def _mark_generation_succeeded(self, generation_result: Optional[Dict[str, Any]]):
        """???????"""
        if isinstance(generation_result, dict):
            generation_result["success"] = True
            generation_result["error_message"] = None
            generation_result["error_emitted"] = False

    async def _resolve_video_asset(
        self,
        token,
        operation: Dict[str, Any],
    ) -> Dict[str, Any]:
        """按当前上游逻辑解析视频资产：状态由 media 决定，URL 通过 redirect 二段获取。"""
        metadata = (operation.get("operation") or {}).get("metadata", {}) or {}
        video_info = metadata.get("video", {}) if isinstance(metadata.get("video"), dict) else {}
        media_name = (
            operation.get("mediaName")
            or video_info.get("mediaName")
            or video_info.get("mediaGenerationId")
            or operation.get("name")
            or (operation.get("operation") or {}).get("name")
        )

        video_url = ""
        if media_name and getattr(token, "st", None):
            video_url = await self.flow_client.get_media_url_redirect(
                token.st,
                media_name,
                media_url_type="MEDIA_URL_TYPE_FULL_MEDIA",
            ) or ""

        import re as _re
        uuid_match = _re.search(r"/video/([0-9a-f-]{36})", video_url or "")
        video_media_id = (
            uuid_match.group(1)
            if uuid_match
            else str(media_name or video_info.get("mediaGenerationId") or "")
        )

        return {
            "media_name": media_name,
            "video_url": video_url,
            "video_media_id": video_media_id,
            "aspect_ratio": video_info.get("aspectRatio", "VIDEO_ASPECT_RATIO_LANDSCAPE"),
            "model": video_info.get("model"),
            "duration": video_info.get("duration"),
            "metadata": metadata,
            "video_info": video_info,
        }

    def _normalize_error_message(self, error_message: Any, max_length: int = 1000) -> str:
        """归一化错误文本，避免写入超长内容。"""
        text = str(error_message or "").strip() or "未知错误"
        if len(text) <= max_length:
            return text
        return f"{text[:max_length - 3]}..."

    @staticmethod
    def _validate_upscaled_image(
        encoded_image: str,
        target_resolution: str,
        aspect_ratio: str,
    ) -> Dict[str, Any]:
        """Fully decode an upsample result and require its exact advertised dimensions."""
        expected = UPSAMPLED_IMAGE_DIMENSIONS.get(target_resolution, {}).get(aspect_ratio)
        if expected is None:
            raise RuntimeError("image_upsample_contract_unknown")
        try:
            raw_image = base64.b64decode(encoded_image, validate=True)
            with Image.open(io.BytesIO(raw_image)) as image:
                image.load()
                actual = tuple(image.size)
                image_format = str(image.format or "").upper()
        except (binascii.Error, UnidentifiedImageError, OSError, ValueError) as exc:
            raise RuntimeError("image_upsample_invalid_payload") from exc
        # Exact additional dimensions observed in completed Google SPrCad RPCs.
        # These are full decoded 2K/4K images, not a tolerance window, resizing,
        # content replacement or permission to replay generation/upsample.
        observed_variants = {
            ("UPSAMPLE_IMAGE_RESOLUTION_2K", "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR"): {(1792, 2388), (1728, 2304)},
            ("UPSAMPLE_IMAGE_RESOLUTION_2K", "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE"): {(2388, 1792), (2304, 1728)},
            ("UPSAMPLE_IMAGE_RESOLUTION_4K", "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR"): {(3456, 4608)},
            ("UPSAMPLE_IMAGE_RESOLUTION_4K", "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE"): {(4608, 3456)},
            ("UPSAMPLE_IMAGE_RESOLUTION_2K", "IMAGE_ASPECT_RATIO_LANDSCAPE"): {(2730, 1536), (2688, 1512)},
            ("UPSAMPLE_IMAGE_RESOLUTION_2K", "IMAGE_ASPECT_RATIO_PORTRAIT_FOUR_FIVE"): {(1840, 2304), (1790, 2240)},
            ("UPSAMPLE_IMAGE_RESOLUTION_2K", "IMAGE_ASPECT_RATIO_PORTRAIT_TWO_THREE"): {(1684, 2528)},
        }
        dimension_contract = "canonical" if actual == expected else "observed_google_rpc_20261121"
        if actual != expected and actual not in observed_variants.get((target_resolution, aspect_ratio), set()):
            error = RuntimeError(
                "image_upsample_dimension_mismatch: "
                f"expected={expected[0]}x{expected[1]},actual={actual[0]}x{actual[1]}"
            )
            error.flow2api_output_validation = {
                "failure_kind": "dimension_mismatch", "expected_width": expected[0],
                "expected_height": expected[1], "actual_width": actual[0], "actual_height": actual[1],
                "format": image_format, "bytes": len(raw_image),
                "sha256": hashlib.sha256(raw_image).hexdigest(),
                "target_resolution": target_resolution, "aspect_ratio": aspect_ratio,
            }
            raise error
        if image_format not in {"JPEG", "PNG", "WEBP"}:
            raise RuntimeError(f"image_upsample_unsupported_format:{image_format or 'unknown'}")
        return {
            "width": actual[0],
            "height": actual[1],
            "format": image_format,
            "bytes": len(raw_image),
            "sha256": hashlib.sha256(raw_image).hexdigest(),
            "dimension_contract": dimension_contract,
            "canonical_width": expected[0],
            "canonical_height": expected[1],
        }

    def _resolve_video_model_key_for_tier(self, model_config: Dict[str, Any], user_tier: str) -> tuple[str, Optional[str]]:
        """根据账号层级调整视频模型 key。"""
        model_key = model_config["model_key"]
        allow_tier_upgrade = bool(model_config.get("allow_tier_upgrade", True))

        if user_tier == "PAYGATE_TIER_TWO":
            if allow_tier_upgrade and "ultra" not in model_key:
                upgraded_model_key = _resolve_tier_two_model_key(model_key)
                if upgraded_model_key != model_key:
                    return upgraded_model_key, f"TIER_TWO 账号自动切换到 ultra 模型: {upgraded_model_key}"
            return model_key, None

        if user_tier == "PAYGATE_TIER_ONE" and "ultra" in model_key:
            model_key = model_key.replace("_ultra_fl", "_fl").replace("_ultra", "")
            return model_key, f"TIER_ONE 账号自动切换到标准模型: {model_key}"

        return model_key, None

    async def _fail_video_task(self, operations: Optional[List[Dict[str, Any]]], error_message: str):
        """将视频任务收口到失败态，避免残留 processing。"""
        if not operations:
            return

        operation = operations[0] if operations else {}
        task_id = (operation.get("operation") or {}).get("name")
        if not task_id:
            return

        try:
            await self.db.update_task(
                task_id,
                status="failed",
                error_message=self._normalize_error_message(error_message),
                completed_at=time.time()
            )
        except Exception as exc:
            debug_logger.log_error(f"[VIDEO] 更新任务失败状态失败: {exc}")

    async def check_token_availability(self, is_image: bool, is_video: bool) -> bool:
        """检查Token可用性

        Args:
            is_image: 是否检查图片生成Token
            is_video: 是否检查视频生成Token

        Returns:
            True表示有可用Token, False表示无可用Token
        """
        token_obj = await self.load_balancer.select_token(
            for_image_generation=is_image,
            for_video_generation=is_video
        )
        return token_obj is not None

    async def handle_generation(
        self, model: str, prompt: str, images: Optional[List[bytes]] = None,
        stream: bool = False, base_url_override: Optional[str] = None,
        video_media_id: Optional[str] = None,
    ) -> AsyncGenerator:
        chain = marker = None
        if MODEL_CONFIG.get(model, {}).get("type") == "image":
            chain, marker = await google_failure_evidence.begin(model, prompt, images)
        generator = self._handle_generation_impl(
            model, prompt, images, stream, base_url_override, video_media_id)
        try:
            async for chunk in generator:
                yield chunk
        finally:
            try:
                await generator.aclose()
            finally:
                if chain is not None:
                    await google_failure_evidence.end(chain, marker)

    async def _handle_generation_impl(
        self,
        model: str,
        prompt: str,
        images: Optional[List[bytes]] = None,
        stream: bool = False,
        base_url_override: Optional[str] = None,
        video_media_id: Optional[str] = None,
    ) -> AsyncGenerator:
        """统一生成入口

        Args:
            model: 模型名称
            prompt: 提示词
            images: 图片列表 (bytes格式)
            stream: 是否流式输出
        """
        start_time = time.time()
        retry_started_monotonic = time.monotonic()
        token = None
        generation_type = None
        pending_token_state = {"active": False}
        request_id = f"gen-{int(start_time * 1000)}-{id(asyncio.current_task())}"
        perf_trace: Dict[str, Any] = {
            "request_id": request_id,
            "model": model,
            "status": "processing",
        }
        generation_result = self._create_generation_result()
        recorded_failure_token_ids: set[int] = set()
        response_state = self._create_response_state()
        response_state["base_url"] = (base_url_override or "").strip().rstrip("/") or None
        request_log_state: Dict[str, Any] = {"id": None, "progress": 0}

        # 防止并发链路复用到上一次请求的指纹上下文
        if hasattr(self.flow_client, "clear_request_fingerprint"):
            self.flow_client.clear_request_fingerprint()

        # 1. 验证模型
        if model not in MODEL_CONFIG:
            error_msg = f"不支持的模型: {model}"
            debug_logger.log_error(error_msg)
            record_generation_result("unknown", "invalid", time.time() - start_time)
            yield self._create_error_response(error_msg, status_code=400)
            return

        model_config = MODEL_CONFIG[model]
        generation_type = model_config["type"]
        cross_account_retry_selected = False
        cross_account_retry_percent = 0
        if generation_type == "image":
            (
                cross_account_retry_selected,
                cross_account_retry_percent,
            ) = self._select_cross_account_retry_canary()
            perf_trace["cross_account_retry"] = {
                "selected": cross_account_retry_selected,
                "configured_percent": cross_account_retry_percent,
                "attempted": False,
                "recovered": False,
                "max_cross_account_attempts": self._max_image_account_attempts() - 1,
                "max_account_attempts": self._max_image_account_attempts(),
                "upsample_regeneration_enabled": os.getenv("FLOW2API_UPSAMPLE_CROSS_ACCOUNT_REGEN_ENABLED", "0") == "1",
                "max_upsample_regenerations": 1,
                "account_attempts": [],
                "additional_account_image_traces": [],
                "automatic_rollout": False,
            }
        model_quota_key = model_config.get("model_name") or model
        video_type_for_op = model_config.get("video_type", "")
        request_operation = "extend_video" if video_type_for_op == "extend" else f"generate_{generation_type}"
        prompt_for_log = prompt if len(prompt) <= 2000 else f"{prompt[:2000]}...(truncated)"
        request_payload = {
            "model": model,
            "prompt": prompt_for_log,
            "has_images": images is not None and len(images) > 0,
        }
        reference_metadata = []
        if generation_type == "image" and images:
            try:
                from .reference_compat import prepare_reference
                prepared_images = []
                compatibility = []
                for reference_index, item in enumerate(images, 1):
                    upload_bytes, proof = await asyncio.to_thread(prepare_reference, item)
                    reference_metadata.append(self._reference_image_metadata(upload_bytes))
                    prepared_images.append(upload_bytes)
                    if proof:
                        compatibility.append({"index": reference_index, **proof})
                images = prepared_images
                if compatibility:
                    perf_trace["reference_compatibility"] = {"schema": 1, "images": compatibility}
            except ValueError as reference_error:
                public_error = self._classify_public_image_error(
                    "invalid_reference_image:decode_or_dimensions"
                )
                perf_trace.update({
                    "status": "failed",
                    "public_error_code": public_error["code"],
                    "error": "invalid_reference_image",
                })
                perf_trace["reference_precheck"] = {
                    "success": False, "failed_reference_index": reference_index,
                    "input_image_count": len(images), "validated_count": len(reference_metadata),
                    "failure": getattr(reference_error, "flow2api_reference_precheck", {}),
                    "account_selected": False, "original_retained": False,
                }
                record_generation_result("image", "invalid", time.time() - start_time)
                await self._log_request(
                    None, request_operation, request_payload,
                    {"error": public_error["code"], "performance": perf_trace},
                    public_error["status_code"], time.time() - start_time,
                    status_text="failed", progress=0,
                )
                yield self._create_error_response(
                    public_error["message"],
                    status_code=public_error["status_code"],
                    error_type=public_error["type"],
                    error_code=public_error["code"],
                    stage=public_error["stage"],
                )
                return
            perf_trace["image_generation"] = {
                "input_image_count": len(images),
                "reference_upload": {
                    "images": [
                        {"index": i + 1, **item}
                        for i, item in enumerate(reference_metadata)
                    ],
                    "uploaded_count": 0,
                },
            }
        # This check is account-independent: reject incompatible Original
        # inputs before token selection, account health mutation or CAPTCHA.
        if generation_type == "image" and model_config.get("native_original_aspect"):
            try:
                geometry = await asyncio.to_thread(reference_geometry, images, model_config["aspect_ratio"])
                perf_trace.setdefault("image_generation", {})["original_aspect"] = geometry
            except ValueError as aspect_error:
                public_error = self._classify_public_image_error(aspect_error)
                if not public_error:
                    raise
                perf_trace.update(status="failed", public_error_code=public_error["code"],
                                  error=str(aspect_error), total_ms=int((time.time()-start_time)*1000))
                perf_trace["reference_precheck"] = {
                    "success": False, "account_selected": False,
                    "generation_dispatched": False, "google_calls": 0,
                    "captcha_consumed": False, "reason": public_error["reason"],
                    "requested_aspect": model_config["aspect_ratio"],
                    "input_image_count": len(images or []),
                    "first_reference": reference_metadata[0] if reference_metadata else None,
                }
                record_generation_result("image", "invalid", time.time()-start_time)
                await self._log_request(None, request_operation, request_payload,
                    {"error": public_error["code"], "performance": perf_trace},
                    public_error["status_code"], time.time()-start_time,
                    status_text="failed", progress=0)
                yield self._create_error_response(public_error["message"],
                    status_code=public_error["status_code"], error_type=public_error["type"],
                    error_code=public_error["code"], stage=public_error["stage"],
                    reason=public_error["reason"])
                return
        debug_logger.log_info(f"[GENERATION] 开始生成 - 模型: {model}, 类型: {generation_type}, Prompt: {prompt[:50]}...")

        # 向用户展示开始信息
        if stream:
            yield self._create_stream_chunk(
                f"✨ {'视频' if generation_type == 'video' else '图片'}生成任务已启动\n",
                role="assistant"
            )
            request_log_state["id"] = await self._log_request(
                token_id=None,
                operation=request_operation,
                request_data=request_payload,
                response_data={"status": "processing", "status_text": "started", "progress": 0, "request_id": request_id},
                status_code=102,
                duration=0,
                status_text="started",
                progress=0,
            )

        # 2. 选择Token
        debug_logger.log_info(f"[GENERATION] 正在选择可用Token...")
        token_select_started_at = time.time()

        if generation_type == "image":
            upload_exclusions = self._reference_upload_exclusions(images)
            busy_upload_accounts = self._busy_reference_upload_accounts() if images else set()
            perf_trace["upload_transport_admission"] = {"temporarily_excluded_accounts": sorted(upload_exclusions),
                                                        "busy_upload_accounts": sorted(busy_upload_accounts),
                                                        "backoff_policy": "upload_timeout_scheduler_v1"}
            pool_wait = model_config.get("upsample") == "UPSAMPLE_IMAGE_RESOLUTION_4K"
            selection_args = {}
            if pool_wait:
                admission_trace = perf_trace["token_pool_admission"] = {
                    "policy": "idle_cookie_pool_fair_v2", "status": "waiting",
                    "wait_timeout_seconds": 240, "max_account_pipelines": cookie_capacity.MAX_PIPELINES,
                    "dispatch_started": False, "upload_posts": 0,
                }
                selection_args = {"idle_cookie_only": True, "wait_idle_seconds": 240,
                                  "selection_diagnostic": admission_trace}
            token = await self.load_balancer.select_token(
                for_image_generation=True,
                model=model,
                model_quota_key=model_quota_key,
                reserve=False,
                enforce_concurrency_filter=False,
                track_pending=True,
                excluded_token_ids=upload_exclusions | (set() if pool_wait else busy_upload_accounts),
                **selection_args,
            )
            if not pool_wait and token is None and busy_upload_accounts - upload_exclusions:
                # All qualified accounts may be busy (especially Ultra); retain
                # their bounded queue instead of inventing quota exhaustion.
                token = await self.load_balancer.select_token(
                    for_image_generation=True, model=model, model_quota_key=model_quota_key,
                    reserve=False, enforce_concurrency_filter=False, track_pending=True,
                    excluded_token_ids=upload_exclusions)
                perf_trace["upload_transport_admission"]["busy_account_fallback"] = token is not None
        else:
            token = await self.load_balancer.select_token(
                for_video_generation=True,
                model=model,
                model_quota_key=model_quota_key,
                reserve=False,
                enforce_concurrency_filter=False,
                track_pending=True,
            )
        perf_trace["token_select_ms"] = int((time.time() - token_select_started_at) * 1000)

        if not token:
            error_msg = None
            unavailable_diagnostic = None
            pool_admission = perf_trace.get("token_pool_admission") or {}
            pool_wait_timeout = pool_admission.get("status") == "timeout"
            if pool_wait_timeout:
                # Capacity is established by the bounded admission wait, not by
                # a later independent pool scan (which cannot prove bad auth).
                unavailable_diagnostic = {
                    "reason": "account_capacity_timeout",
                    "snapshot_source": "last_completed_selection_poll",
                    "selection_snapshot_status": pool_admission.get("selection_snapshot_status", "not_observed"),
                    "selection_snapshot_age_ms": pool_admission.get("selection_snapshot_age_ms"),
                    "filter_counts": {key: pool_admission.get(key) for key in (
                        "active_accounts", "eligible_candidates", "eligible_pipeline_capacity", "cookie_not_ready_candidates",
                        "busy_cookie_candidates", "older_waiter_candidates")},
                }
                perf_trace["account_pool"] = unavailable_diagnostic
            if not pool_wait_timeout and self.load_balancer and hasattr(self.load_balancer, "get_unavailable_reason"):
                error_msg = await self.load_balancer.get_unavailable_reason(
                    for_image_generation=(generation_type == "image"),
                    for_video_generation=(generation_type == "video"),
                    model=model,
                    model_quota_key=model_quota_key,
                )
            if not pool_wait_timeout and generation_type == "image" and hasattr(self.load_balancer, "get_unavailable_diagnostic"):
                try:
                    unavailable_diagnostic = await self.load_balancer.get_unavailable_diagnostic(
                        model=model, model_quota_key=model_quota_key,
                    )
                except Exception as diagnostic_error:
                    debug_logger.log_warning(
                        f"[POOL_DIAGNOSTIC] unavailable: {type(diagnostic_error).__name__}"
                    )
                    unavailable_diagnostic = {"reason": "unknown"}
                perf_trace["account_pool"] = unavailable_diagnostic
                perf_trace["public_error_code"] = "flow_account_pool_unavailable"
            pool_error_code = "flow_account_capacity_unavailable" if pool_wait_timeout else "flow_account_pool_unavailable"
            if pool_wait_timeout:
                perf_trace["public_error_code"] = pool_error_code
                error_msg = "flow_account_capacity_unavailable:idle_cookie_pool_queue_timeout"
            if not error_msg:
                error_msg = self._get_no_token_error_message(generation_type)
            perf_trace.update(status="failed", total_ms=int((time.time()-start_time)*1000))
            debug_logger.log_error(f"[GENERATION] {error_msg}")
            record_generation_result(generation_type, "no_token", time.time() - start_time)
            await self._log_request(
                token_id=None,
                operation=request_operation,
                request_data=request_payload,
                response_data={"error": error_msg, "performance": perf_trace},
                status_code=503,
                duration=time.time() - start_time,
                log_id=request_log_state.get("id"),
                status_text="failed",
                progress=request_log_state.get("progress", 0),
            )
            if stream:
                yield self._create_stream_chunk(f"错误: {error_msg}\n")
            if generation_type == "image":
                yield self._create_error_response(
                    "Flow account capacity wait expired." if pool_wait_timeout else "No eligible Flow account is currently available for this model.",
                    status_code=503,
                    error_type="server_error",
                    error_code=pool_error_code,
                    reason="idle_cookie_pool_queue_timeout" if pool_wait_timeout else (unavailable_diagnostic or {}).get("reason"),
                    retry_after_seconds=10 if pool_wait_timeout else (unavailable_diagnostic or {}).get("retry_after_seconds"),
                )
            else:
                yield self._create_error_response(error_msg, status_code=503)
            return

        debug_logger.log_info(f"[GENERATION] 已选择Token: {token.id} ({token.email})")
        pending_token_state["active"] = True
        await self._update_request_log_progress(
            request_log_state,
            token_id=token.id,
            status_text="token_selected",
            progress=8,
            response_extra={"token_email": token.email},
        )

        try:
            if generation_type == "image" and hasattr(self.flow_client, "bind_token_image_egress"):
                fallback_proxy_url = (
                    (getattr(token, "proxy_url", "") or "").strip()
                    or (getattr(token, "captcha_proxy_url", "") or "").strip()
                )
                try:
                    self.flow_client.bind_token_image_egress(
                        token.id,
                        fallback_proxy_url=fallback_proxy_url,
                    )
                finally:
                    if hasattr(self.flow_client, "get_image_captcha_routing"):
                        routing = self.flow_client.get_image_captcha_routing()
                        if isinstance(routing, dict):
                            perf_trace["captcha_routing"] = routing

            # 3. 确保AT有效
            debug_logger.log_info(f"[GENERATION] 检查Token AT有效性...")
            if stream:
                yield self._create_stream_chunk("初始化生成环境...\n")

            await self._update_request_log_progress(
                request_log_state,
                token_id=token.id,
                status_text="token_ready",
                progress=15,
            )
            ensure_at_started_at = time.time()
            token = await self.token_manager.ensure_valid_token(token)
            perf_trace["ensure_at_ms"] = int((time.time() - ensure_at_started_at) * 1000)
            if not token:
                error_msg = "Token AT无效或刷新失败"
                debug_logger.log_error(f"[GENERATION] {error_msg}")
                record_generation_result(generation_type, "failed", time.time() - start_time)
                if stream:
                    yield self._create_stream_chunk(f"错误: {error_msg}\n")
                yield self._create_error_response(error_msg, status_code=503)
                return

            # 4. 确保Project存在
            debug_logger.log_info(f"[GENERATION] 检查/创建Project...")

            if not supports_model_for_tier(model, token.user_paygate_tier):
                required_tier = get_required_paygate_tier_for_model(model)
                error_msg = "当前模型需要 " + get_paygate_tier_label(required_tier) + " 账号: " + model
                debug_logger.log_error(f"[GENERATION] {error_msg}")
                record_generation_result(generation_type, "failed", time.time() - start_time)
                if stream:
                    yield self._create_stream_chunk(f"错误: {error_msg}\n")
                yield self._create_error_response(error_msg, status_code=403)
                return

            ensure_project_started_at = time.time()
            project_id = await self.token_manager.ensure_project_exists(token.id)
            perf_trace["ensure_project_ms"] = int((time.time() - ensure_project_started_at) * 1000)
            debug_logger.log_info(f"[GENERATION] Project ID: {project_id}")
            await self._update_request_log_progress(
                request_log_state,
                token_id=token.id,
                status_text="project_ready",
                progress=22,
                response_extra={"project_id": project_id},
            )
            prefill_action = "IMAGE_GENERATION" if generation_type == "image" else "VIDEO_GENERATION"
            await self.flow_client.prefill_remote_browser_pool(
                project_id=project_id,
                action=prefill_action,
                token_id=token.id,
            )

            # 5. 根据类型处理
            generation_pipeline_started_at = time.time()
            if generation_type == "image":
                debug_logger.log_info(f"[GENERATION] 开始图片生成流程...")
                retry_trace = perf_trace["cross_account_retry"]
                attempted_ids = set()
                failed_upload_exits = set()
                preferred_upload_accounts = set()
                upload_shortcut_selected = secrets.randbelow(100) < 10
                previous_error = None
                recovery_kind = "primary"
                upsample_regenerations = 0
                known_success_400_recoveries = 0
                upload_internal_recoveries = 0
                prior_upload_transport = False
                retry_max_elapsed = CrossAccountRetryBudget._positive_int(
                    os.getenv("FLOW2API_CROSS_ACCOUNT_RETRY_MAX_ELAPSED_SECONDS", "240"), 240)
                while True:
                    previous_token = token
                    admission_limit = self._image_retry_admission_limit(retry_max_elapsed, recovery_kind, prior_upload_transport)
                    attempt_index = len(attempted_ids) + 1
                    account_attempt = {"attempt_index": attempt_index, "account_id": int(token.id),
                                       "kind": recovery_kind, "started": False, "outcome": "preparing",
                                       "retry_admission_max_seconds": admission_limit}
                    reservation_id = billing_binding = upload_context = None
                    exit_exclusions = upload_egress.exclusions(failed_upload_exits) if failed_upload_exits else set()
                    if failed_upload_exits:
                        account_attempt["egress_exclusion"] = {"policy": "assigned_exit_v1",
                            "excluded_account_count": len(exit_exclusions), "failed_exit_count": len(failed_upload_exits)}
                    if previous_error is not None:
                        retry_trace["selection_attempted"] = True
                        selection_started = time.monotonic()
                        retry_token = await self._select_image_recovery_account(
                            model=model, model_config=model_config, model_quota_key=model_quota_key,
                            images=images, attempted_ids=attempted_ids, exit_exclusions=exit_exclusions,
                            preferred_upload_accounts=preferred_upload_accounts, failed_upload_exits=failed_upload_exits,
                            retry_deadline=retry_started_monotonic + admission_limit, account_attempt=account_attempt)
                        if (model_config.get("upsample") == "UPSAMPLE_IMAGE_RESOLUTION_4K"
                                and time.monotonic() >= retry_started_monotonic + admission_limit):
                            if retry_token is not None:
                                await self.load_balancer.release_pending(retry_token.id, for_image_generation=True)
                            retry_trace["retry_skipped"] = "retry_admission_deadline"
                            retry_trace["unstarted_recovery"] = {**account_attempt, "outcome": "retry_admission_deadline"}
                            raise previous_error
                        label = "second" if attempt_index == 2 else "third"
                        account_attempt["selection_ms"] = int((time.monotonic() - selection_started) * 1000)
                        retry_trace[f"{label}_account_available"] = retry_token is not None
                        if retry_token is None:
                            retry_trace["retry_skipped"] = "no_alternate_account"
                            retry_trace["unstarted_recovery"] = {**account_attempt, "outcome": "no_alternate_account"}
                            raise previous_error
                        token = retry_token
                        pending_token_state["active"] = True
                        account_attempt["account_id"] = int(token.id)
                        retry_trace["account_attempts"].append(account_attempt)
                        if int(token.id) in attempted_ids:
                            # The scheduler contract excludes every previous identity.
                            retry_trace["retry_skipped"] = "alternate_account_not_distinct"
                            await self.load_balancer.release_pending(token.id, for_image_generation=True)
                            pending_token_state["active"] = False
                            token = previous_token
                            raise previous_error
                        retry_trace[f"{label}_account_id"] = int(token.id)
                        retry_trace["different_account"] = True
                        fallback_proxy_url = ((getattr(token, "proxy_url", "") or "").strip()
                                              or (getattr(token, "captcha_proxy_url", "") or "").strip())
                        self.flow_client.bind_token_image_egress(token.id, fallback_proxy_url=fallback_proxy_url)
                        route = upload_egress.identity(token.id)
                        if failed_upload_exits and (not route or route["assigned_exit_sha256"] in failed_upload_exits):
                            retry_trace["retry_skipped"] = "alternate_exit_not_distinct"
                            account_attempt["outcome"] = "alternate_exit_not_distinct"
                            await self.load_balancer.release_pending(token.id, for_image_generation=True)
                            pending_token_state["active"] = False
                            token = previous_token
                            raise previous_error
                        routing = self.flow_client.get_image_captcha_routing() if hasattr(self.flow_client, "get_image_captcha_routing") else None
                        if isinstance(routing, dict):
                            retry_trace[f"{label}_account_captcha_routing"] = routing
                        provider_plan = routing.get("provider_plan") if isinstance(routing, dict) else []
                        estimated = CrossAccountRetryBudget.estimate_cost_usd(model_config, provider_plan)
                        decision = await _CROSS_ACCOUNT_RETRY_BUDGET.consume(estimated)
                        budget = {k: v for k, v in decision.items() if k != "reservation_id"}
                        budget.update(max_per_minute=_CROSS_ACCOUNT_RETRY_BUDGET.max_per_minute,
                                      max_per_hour=_CROSS_ACCOUNT_RETRY_BUDGET.max_per_hour,
                                      max_usd_per_hour=_CROSS_ACCOUNT_RETRY_BUDGET.max_usd_per_hour)
                        account_attempt["retry_budget"] = retry_trace["retry_budget"] = budget
                        account_attempt["estimated_extra_captcha_cost_usd"] = round(estimated, 6)
                        if not decision.get("allowed"):
                            retry_trace["retry_skipped"] = str(decision.get("reason") or "retry_budget_rejected")
                            account_attempt["outcome"] = "budget_denied"
                            await self.load_balancer.release_pending(token.id, for_image_generation=True)
                            pending_token_state["active"] = False
                            token = previous_token
                            raise previous_error
                        retry_trace["estimated_extra_captcha_cost_usd"] = round(
                            retry_trace.get("estimated_extra_captcha_cost_usd", 0) + estimated, 6)
                        reservation_id = decision["reservation_id"]
                        billing_binding = bind_reservation(_CROSS_ACCOUNT_RETRY_BUDGET, reservation_id)
                    else:
                        retry_trace["account_attempts"].append(account_attempt)
                    image_error = None
                    pipeline_started = time.monotonic()
                    try:
                        if previous_error is not None:
                            validated = await self.token_manager.ensure_valid_token(token)
                            if validated is None or int(validated.id) != int(token.id):
                                retry_trace["retry_skipped"] = "alternate_token_unavailable"
                                account_attempt["outcome"] = "alternate_token_unavailable"
                                raise previous_error
                            token = validated
                            project_id = await self.token_manager.ensure_project_exists(token.id)
                            await self.flow_client.prefill_remote_browser_pool(
                                project_id=project_id, action="IMAGE_GENERATION", token_id=token.id)
                            delay_ms = 250 + secrets.randbelow(1000)
                            account_attempt["backoff_ms"] = retry_trace["backoff_ms"] = delay_ms
                            if time.monotonic() - retry_started_monotonic + delay_ms / 1000 >= admission_limit:
                                retry_trace["retry_skipped"] = "retry_admission_deadline"
                                raise previous_error
                            await asyncio.sleep(delay_ms / 1000)
                            if time.monotonic() - retry_started_monotonic >= admission_limit:
                                retry_trace["retry_skipped"] = "retry_admission_deadline"
                                raise previous_error
                            # Detach only when the new image pipeline really starts.
                            # First + intervening traces + current trace is the cost schema.
                            historical = json.loads(json.dumps(perf_trace.get("image_generation") or {}))
                            if attempt_index == 2:
                                retry_trace["first_account_image_trace"] = historical
                            else:
                                retry_trace["additional_account_image_traces"].append({
                                    "account_id": int(previous_token.id), "attempt_index": attempt_index - 1,
                                    "image_trace": historical,
                                })
                            perf_trace["image_generation"] = {}
                            generation_result.clear()
                            generation_result.update(self._create_generation_result())
                            saved_base_url = response_state.get("base_url")
                            response_state.clear()
                            response_state.update(self._create_response_state())
                            response_state["base_url"] = saved_base_url
                            if recovery_kind == "upsample_cross_account_regeneration":
                                upsample_regenerations += 1
                                retry_trace["upsample_regenerations"] = upsample_regenerations
                            retry_trace["attempted"] = True
                            retry_trace[f"{label}_account_generation_started"] = True
                            await self._update_request_log_progress(request_log_state, token_id=token.id,
                                status_text="cross_account_retry_token_selected", progress=8)
                        if recovery_kind == "reference_upload_known_success_400":
                            known_success_400_recoveries += 1
                            retry_trace["known_success_400_recoveries"] = known_success_400_recoveries
                        if recovery_kind in {"reference_upload_internal", "reference_upload_busy", "reference_upload_deadline"}:
                            upload_internal_recoveries += 1
                            retry_trace["upload_internal_recoveries"] = upload_internal_recoveries
                        route = upload_egress.identity(token.id)
                        if failed_upload_exits and (not route or route["assigned_exit_sha256"] in failed_upload_exits):
                            retry_trace["retry_skipped"] = "alternate_exit_not_distinct"
                            raise previous_error
                        if route:
                            account_attempt.update(route)
                        account_attempt["upload_egress_policy"] = "assigned_exit_v1"
                        upload_context = upload_egress.bind(token.id,
                            lambda: self._partial_send_alternative(model, model_quota_key, int(token.id),
                                max((len(i)//2 for i in images or []), default=0), upload_shortcut_selected))
                        attempted_ids.add(int(token.id))
                        account_attempt.update(started=True, outcome="processing")
                        retry_trace.update(account_attempt_count=len(attempted_ids),
                                           cross_account_attempt_count=max(0, len(attempted_ids) - 1),
                                           final_account_id=int(token.id))
                        async for chunk in self._handle_image_generation(
                            token, project_id, model_config, prompt, images, stream,
                            perf_trace=perf_trace, generation_result=generation_result,
                            response_state=response_state, request_log_state=request_log_state,
                            pending_token_state=pending_token_state,
                        ):
                            if generation_result.get("success"):
                                perf_trace.setdefault("image_generation", {})["output_delivered"] = True
                            yield chunk
                        account_attempt["outcome"] = "success" if generation_result.get("success") else "failed_without_exception"
                        retry_trace["recovered"] = bool(retry_trace["attempted"] and generation_result.get("success"))
                    except asyncio.CancelledError:
                        account_attempt["outcome"] = "cancelled"
                        raise
                    except Exception as current_error:
                        if not account_attempt["started"]:
                            account_attempt["outcome"] = "setup_failed"
                            await self.load_balancer.release_pending(token.id, for_image_generation=True)
                            pending_token_state["active"] = False
                            token = previous_token
                            raise
                        image_error = current_error
                        account_attempt["outcome"] = "failed"
                    finally:
                        account_attempt["duration_ms"] = int((time.monotonic() - pipeline_started) * 1000)
                        if upload_context is not None:
                            upload_egress.reset(upload_context)
                        if billing_binding is not None:
                            reset_reservation(billing_binding)
                            account_attempt["retry_budget_settlement"] = _CROSS_ACCOUNT_RETRY_BUDGET.settle(reservation_id)
                            self._aggregate_retry_settlement(retry_trace)
                    if image_error is None:
                        break
                    policy = image_content_policy.rejection(image_error)
                    if policy:
                        # Do not run proof searches, browser repair, or alternate-account
                        # selection after an explicit provider content-safety rejection.
                        account_attempt.update(failure_code="content_policy_violation",
                            failure_stage=policy["stage"], retry_decision={
                                "allowed": False, "reason": "content_policy_violation"})
                        retry_trace["retry_skipped"] = "content_policy_violation"
                        perf_trace["content_policy_rejection"] = {
                            **policy, "retryable": False, "terminal": True,
                        }
                        raise image_error
                    reason = self._cross_account_retry_reason(image_error)
                    produced = bool(generation_result.get("success") or response_state.get("url")
                                    or response_state.get("generated_assets") or self._generation_submission_observed(perf_trace))
                    upload_reason = self._upload_transport_retry_reason(image_error, perf_trace)
                    if not upload_reason and not produced:
                        upload_reason = self._upload_internal_retry_reason(
                            image_error, perf_trace, reference_metadata, int(token.id), upload_internal_recoveries)
                    if not upload_reason and not produced:
                        busy_decision = self._upload_technical_retry_decision(
                            image_error, perf_trace, reference_metadata, int(token.id), upload_internal_recoveries)
                        if busy_decision["reason"] != "not_upload_technical_failure":
                            account_attempt["upload_technical_recovery_decision"] = busy_decision
                            if "cause=rpc_high_traffic;" in str(image_error):
                                account_attempt["upload_busy_recovery_decision"] = busy_decision
                        if busy_decision["eligible"]:
                            upload_reason = busy_decision["reason"]
                    if upload_reason and not produced:
                        reason = upload_reason
                        if upload_reason == "reference_upload_transport":
                            self._pause_upload_transport_account(token.id, account_attempt)
                            digest = account_attempt.get("assigned_exit_sha256")
                            if digest:
                                failed_upload_exits.add(digest)
                                preferred_upload_accounts = await upload_egress.healthy_accounts(
                                    getattr(self.db, "db_path", None), max((len(i)//2 for i in images or []), default=0))
                                account_attempt["recent_healthy_exit_candidate_count"] = len(preferred_upload_accounts)
                            else:
                                account_attempt["upload_exit_identity_unavailable"] = True
                        elif upload_reason in {"reference_upload_internal", "reference_upload_busy", "reference_upload_deadline"}:
                            digest = account_attempt.get("assigned_exit_sha256")
                            if digest:
                                failed_upload_exits.add(digest)
                            account_attempt["upload_internal_recovery"] = {"max_recoveries": 1,
                                "complete_response": True, "persistent_account_mutation": False}
                        else:
                            account_attempt["upload_queue_recovery"] = {"blocking_reason": "account_limit",
                                "uploaded_POSTs": 0, "persistent_account_mutation": False}
                    known_400 = None
                    if not upload_reason and not produced:
                        known_400 = await self._known_success_upload_400_decision(
                            image_error, perf_trace, reference_metadata, int(token.id), known_success_400_recoveries)
                        if str(image_error).startswith("Project-scoped image upload failed via /flow/uploadImage; "):
                            account_attempt["known_success_upload_400_decision"] = known_400
                        if known_400["eligible"]:
                            reason = known_400["reason"]
                    upsample_decision = self._upsample_regeneration_decision(
                        image_error, perf_trace, generation_result, response_state, model_config)
                    account_attempt["upsample_regeneration_decision"] = upsample_decision
                    public = self._classify_public_image_error(image_error)
                    account_attempt["failure_code"] = public.get("code") if public else "unknown"
                    account_attempt["failure_stage"] = public.get("stage") if public and public.get("stage") else (
                        "upsample" if str(image_error).startswith("image_upsample_failed:") else "generation")
                    account_attempt["base_image_available"] = bool(response_state.get("generated_assets"))
                    account_attempt["eligible_reason"] = reason
                    retry_trace["eligible_reason"] = reason
                    if attempt_index == 1:
                        retry_trace.update(first_account_id=int(token.id), first_attempt_produced_image=produced,
                                           first_attempt_failed_before_image=not produced)
                    blocked = None
                    if not cross_account_retry_selected:
                        blocked = "not_selected"
                    elif upload_reason in {"reference_upload_transport", "reference_upload_internal", "reference_upload_busy", "reference_upload_deadline"} and not account_attempt.get("assigned_exit_sha256"):
                        blocked = "upload_egress_identity_unavailable"
                    elif len(attempted_ids) >= retry_trace["max_account_attempts"]:
                        blocked = "account_attempt_limit"
                    elif upsample_decision["eligible"]:
                        if not retry_trace["upsample_regeneration_enabled"]:
                            blocked = "upsample_regeneration_disabled"
                        elif upsample_regenerations >= 1:
                            blocked = "upsample_regeneration_limit"
                        else:
                            reason = "upsample_cross_account_regeneration"
                    elif known_400 and known_400["reason"] == "known_success_400_retry_limit":
                        blocked = "known_success_400_retry_limit"
                    elif not reason or produced:
                        blocked = upsample_decision["reason"] if str(image_error).startswith("image_upsample_failed:") else "non_retryable_or_ambiguous_submission"
                    retry_max_elapsed = CrossAccountRetryBudget._positive_int(
                        os.getenv("FLOW2API_CROSS_ACCOUNT_RETRY_MAX_ELAPSED_SECONDS"), 240)
                    retry_elapsed = time.monotonic() - retry_started_monotonic
                    account_attempt["elapsed_before_retry_ms"] = retry_trace["elapsed_before_retry_ms"] = int(retry_elapsed * 1000)
                    admission_limit = self._image_retry_admission_limit(retry_max_elapsed, reason, prior_upload_transport)
                    retry_trace["max_retry_admission_seconds"] = admission_limit
                    if blocked is None and (admission_limit <= 0 or retry_elapsed >= admission_limit):
                        blocked = "retry_admission_deadline"
                    account_attempt["retry_decision"] = {"allowed": blocked is None,
                        "reason": blocked or reason, "prior_submission": "confirmed_upsample_rejected" if upsample_decision["eligible"] else
                        ("accepted_or_unknown" if produced else "no_image_observed")}
                    if blocked:
                        retry_trace["retry_skipped"] = blocked
                        raise image_error
                    retry_trace["eligible_reason"] = reason
                    await self._record_token_failure(token.id, model_quota_key, image_error, perf_trace=perf_trace)
                    recorded_failure_token_ids.add(int(token.id))
                    if pending_token_state.get("active"):
                        await self.load_balancer.release_pending(token.id, for_image_generation=True)
                        pending_token_state["active"] = False
                    if hasattr(self.flow_client, "clear_request_fingerprint"):
                        self.flow_client.clear_request_fingerprint()
                    previous_error, recovery_kind = image_error, reason
                    if reason == "reference_upload_transport":
                        prior_upload_transport = True
                        retry_trace["prior_upload_transport_recovery"] = True
            else:  # video
                debug_logger.log_info(f"[GENERATION] 开始视频生成流程...")
                async for chunk in self._handle_video_generation(
                    token, project_id, model_config, prompt, images, stream,
                    perf_trace=perf_trace,
                    generation_result=generation_result,
                    response_state=response_state,
                    request_log_state=request_log_state,
                    pending_token_state=pending_token_state,
                    video_media_id=video_media_id,
                ):
                    yield chunk
            perf_trace["generation_pipeline_ms"] = int((time.time() - generation_pipeline_started_at) * 1000)

            # 6. 记录使用
            if not generation_result.get("success"):
                error_msg = generation_result.get("error_message") or "生成未成功完成"
                debug_logger.log_warning(f"[GENERATION] 生成未成功，不扣次数: {error_msg}")
                if token:
                    await self._record_token_failure(token.id, model_quota_key, error_msg, perf_trace=perf_trace)
                duration = time.time() - start_time
                record_generation_result(generation_type, "failed", duration)
                perf_trace["status"] = "failed"
                perf_trace["total_ms"] = int(duration * 1000)
                perf_trace["error"] = error_msg
                prompt_for_log = prompt if len(prompt) <= 2000 else f"{prompt[:2000]}...(truncated)"
                await self._log_request(
                    token.id if token else None,
                    request_operation,
                    request_payload,
                    {"error": error_msg, "performance": perf_trace},
                    500,
                    duration,
                    log_id=request_log_state.get("id"),
                    status_text="failed",
                    progress=request_log_state.get("progress", 0),
                )
                if not generation_result.get("error_emitted"):
                    if stream:
                        yield self._create_stream_chunk(f"错误: {error_msg}\n")
                    yield self._create_error_response(error_msg, status_code=500)
                return

            is_video = (generation_type == "video")
            await self.token_manager.record_usage(token.id, is_video=is_video)

            # 重置错误计数 (请求成功时清空连续错误计数)
            await self.token_manager.record_success(token.id)
            await self.token_manager.clear_model_cooldown(token.id, model_quota_key)

            debug_logger.log_info(f"[GENERATION] ✅ 生成成功完成")

            # 7. 记录成功日志
            duration = time.time() - start_time
            record_generation_result(generation_type, "success", duration)
            perf_trace["status"] = "success"
            perf_trace["total_ms"] = int(duration * 1000)
            # 日志中保留更完整的 prompt，避免管理页只看到过短内容
            prompt_for_log = prompt if len(prompt) <= 2000 else f"{prompt[:2000]}...(truncated)"

            # 构建响应数据，包含生成的URL
            response_data = {
                "status": "success",
                "model": model,
                "prompt": prompt_for_log,
                "performance": perf_trace
            }

            # 添加生成的URL（如果有）
            if response_state.get("url"):
                response_data["url"] = response_state["url"]
            if response_state.get("generated_assets"):
                response_data["generated_assets"] = response_state["generated_assets"]
            image_perf = perf_trace.get("image_generation", {}) if isinstance(perf_trace, dict) else {}
            video_perf = perf_trace.get("video_generation", {}) if isinstance(perf_trace, dict) else {}
            debug_logger.log_info(
                f"[PERF] [{request_id}] total={perf_trace.get('total_ms', 0)}ms, "
                f"select={perf_trace.get('token_select_ms', 0)}ms, "
                f"ensure_at={perf_trace.get('ensure_at_ms', 0)}ms, "
                f"project={perf_trace.get('ensure_project_ms', 0)}ms, "
                f"pipeline={perf_trace.get('generation_pipeline_ms', 0)}ms, "
                f"slot_wait={image_perf.get('slot_wait_ms', 0)}ms, "
                f"launch_queue={image_perf.get('launch_queue_wait_ms', 0)}ms, "
                f"launch_stagger={image_perf.get('launch_stagger_wait_ms', 0)}ms, "
                f"video_slot_wait={video_perf.get('slot_wait_ms', 0)}ms"
            )

            await self._log_request(
                token.id,
                request_operation,
                request_payload,
                response_data,
                200,
                duration,
                log_id=request_log_state.get("id"),
                status_text="completed",
                progress=100,
            )

        except asyncio.CancelledError:
            error_msg = "生成已取消: 客户端连接已断开"
            debug_logger.log_warning(f"[GENERATION] ⚠️ {error_msg}")
            duration = time.time() - start_time
            record_generation_result(generation_type or "unknown", "cancelled", duration)
            perf_trace["status"] = "failed"
            perf_trace["total_ms"] = int(duration * 1000)
            perf_trace["error"] = error_msg
            prompt_for_log = prompt if len(prompt) <= 2000 else f"{prompt[:2000]}...(truncated)"
            await self._log_request(
                token.id if token else None,
                request_operation if generation_type else "generate_unknown",
                request_payload if 'request_payload' in locals() else {"model": model},
                {"error": error_msg, "performance": perf_trace},
                499,
                duration,
                log_id=request_log_state.get("id"),
                status_text="failed",
                progress=request_log_state.get("progress", 0),
            )
            raise
        except Exception as e:
            error_msg = f"生成失败: {str(e)}"
            debug_logger.log_error(f"[GENERATION] 生成失败: {error_msg}")
            if token and int(token.id) not in recorded_failure_token_ids:
                await self._record_token_failure(token.id, model_quota_key, e, perf_trace=perf_trace)

            public_error = (
                self._classify_public_image_error(e)
                if generation_type == "image"
                else None
            )
            if public_error:
                perf_trace["public_error_code"] = public_error["code"]

            # 先将最终失败状态落库，再返回错误响应，避免日志停在 102。
            duration = time.time() - start_time
            record_generation_result(generation_type or "unknown", "failed", duration)
            perf_trace["status"] = "failed"
            perf_trace["total_ms"] = int(duration * 1000)
            perf_trace["error"] = error_msg
            prompt_for_log = prompt if len(prompt) <= 2000 else f"{prompt[:2000]}...(truncated)"
            await self._log_request(
                token.id if token else None,
                request_operation if generation_type else "generate_unknown",
                request_payload if 'request_payload' in locals() else {"model": model},
                {"error": public_error["code"] if public_error else error_msg, "performance": perf_trace},
                public_error["status_code"] if public_error else 500,
                duration,
                log_id=request_log_state.get("id"),
                status_text="failed",
                progress=request_log_state.get("progress", 0),
            )
            if stream:
                visible_message = public_error["message"] if public_error else error_msg
                yield self._create_stream_chunk(f"错误: {visible_message}\n")
            if public_error:
                yield self._create_error_response(
                    public_error["message"],
                    status_code=public_error["status_code"],
                    error_type=public_error["type"],
                    error_code=public_error["code"],
                    reason=public_error.get("reason"),
                    stage=public_error.get("stage"),
                    retry_after_seconds=public_error.get("retry_after_seconds"),
                )
            else:
                yield self._create_error_response(error_msg, status_code=500)
        finally:
            if pending_token_state.get("active") and token and self.load_balancer:
                await self.load_balancer.release_pending(
                    token.id,
                    for_image_generation=(generation_type == "image"),
                    for_video_generation=(generation_type == "video"),
                )
                pending_token_state["active"] = False
            if hasattr(self.flow_client, "clear_request_fingerprint"):
                self.flow_client.clear_request_fingerprint()


    def _get_no_token_error_message(self, generation_type: str) -> str:
        """获取无可用Token时的详细错误信息"""
        if generation_type == "image":
            return "没有可用的Token进行图片生成。所有Token都处于禁用、冷却、锁定或已过期状态。"
        else:
            return "没有可用的Token进行视频生成。所有Token都处于禁用、冷却、配额耗尽或已过期状态。"

    @staticmethod
    def _is_captcha_provider_unavailable(error: Any) -> bool:
        # Exact infrastructure codes only. Session/auth/binding failures remain
        # account faults; do not infer attribution from a generic captcha word.
        return str(error or "").strip().lower() in {
            "cookie_media_captcha_unavailable", "captcha_unavailable",
            "captcha_provider_plan_empty",
        }

    def _should_count_token_error(self, error: Exception) -> bool:
        """判断失败是否应计入 token 连续错误。

        reCAPTCHA 获取失败、验证码供应商错误、打码资源不足等问题通常不是账号本身异常；
        若将其纳入连续错误，会在回归测试或代理波动时把 token 自动打成 inactive。
        """
        if image_content_policy.rejection(error) or self._is_captcha_provider_unavailable(error):
            return False
        error_text = str(error or "").strip().lower()
        if not error_text:
            return True

        non_token_fault_markers = (
            "failed to obtain recaptcha token",
            "recaptcha evaluation failed",
            "recaptcha 验证失败",
            "recaptcha 错误",
            "public_error_unusual_activity",
            "too much traffic",
            "error_no_slot_available",
            "打码服务资源不足",
            "打码服务资源阻塞",
            "yescaptcha",
            "capsolver",
            "capmonster",
            "ezcaptcha",
            "image_upsample_",
            "project-scoped image upload failed via /flow/uploadimage",
            "invalid_reference_image:",
            "flow_model_temporarily_unavailable:",
        )
        if any(marker in error_text for marker in non_token_fault_markers):
            return False

        if "没有可用的token进行" in error_text:
            return False

        return True

    @staticmethod
    def _is_model_daily_quota_error(error: Any) -> bool:
        error_text = str(error or "").strip().lower()
        return "public_error_per_model_daily_quota_reached" in error_text

    @staticmethod
    def _is_model_transient_throttle_error(error: Any) -> bool:
        error_text = str(error or "").strip().lower()
        return "public_error_user_requests_throttled" in error_text

    async def _record_token_failure(self, token_id: int, model_quota_key: str, error: Any, perf_trace=None) -> None:
        """Classify a failure before changing account-wide scheduling state."""
        if self._is_captcha_provider_unavailable(error):
            # Supplier funding/capacity failures do not describe this Google
            # identity. Preserve all existing counters, holds and quota rows.
            if isinstance(perf_trace, dict):
                perf_trace.setdefault("token_failure_attribution", []).append({
                    "account_id": token_id, "scope": "captcha_provider",
                    "reason": "captcha_unavailable", "account_error_counted": False,
                })
            debug_logger.log_info(
                f"[TOKEN_FAILURE_ATTRIBUTION] token_id={token_id} "
                "scope=captcha_provider account_error_counted=false"
            )
            return
        if str(error or "").startswith("flow_account_capacity_unavailable:"):
            # Local queue pressure says nothing about login, policy or quota.
            return
        # The shared BELUGA generation endpoint can return HTTP 404 for
        # otherwise healthy accounts. Keep this endpoint failure from
        # disabling every account through the account-wide breaker.
        if model_quota_key == "BELUGA" and is_shared_flash_404(error):
            debug_logger.log_warning(
                f"[MODEL_ENDPOINT] Token {token_id} model={model_quota_key} "
                "shared HTTP 404 skipped by account breaker"
            )
            return

        if self._is_model_daily_quota_error(error):
            cooling_until = await self.token_manager.cool_down_model_daily_quota(
                token_id,
                model_quota_key,
            )
            debug_logger.log_warning(
                f"[MODEL_QUOTA] Token {token_id} model={model_quota_key} "
                f"cooling_until={cooling_until.isoformat()}"
            )
            return

        if self._is_model_transient_throttle_error(error):
            cooling_until = await self.token_manager.cool_down_model_transient_throttle(
                token_id,
                model_quota_key,
            )
            debug_logger.log_warning(
                f"[MODEL_THROTTLE] Token {token_id} model={model_quota_key} "
                f"cooling_until={cooling_until.isoformat()}"
            )
            return

        if explicit_risk(error, perf_trace, token_id):
            # Separate short scheduler pause, never an account disable or daily quota edit.
            try:
                state = await IMAGE_RISK_BACKOFF.failure(
                    getattr(self.token_manager, "db", None), token_id, model_quota_key,
                )
                if state and isinstance(perf_trace, dict):
                    perf_trace.setdefault("risk_backoff", []).append(state)
            except Exception:
                debug_logger.log_warning("[IMAGE_RISK] temporary backoff persistence failed")
            return

        if self._should_count_token_error(error):
            await self.token_manager.record_error(token_id)
            return

        debug_logger.log_info(
            f"[GENERATION] 跳过 token 错误计数: token_id={token_id}, reason={str(error)[:200]}"
        )

    @staticmethod
    def _upload_batch_settle_reason(error, upload_trace):
        """Permit bounded observation, never a provider retry or replay grant."""
        message = str(error or "")
        prefix = "Project-scoped image upload failed via /flow/uploadImage; cause="
        cause = next((c for c in ("rpc_internal", "rpc_deadline_exceeded", "rpc_high_traffic")
                      if message.startswith(prefix + c + ";")), None)
        failed = [r for r in (upload_trace or {}).get("images", []) if r.get("status") == "failed"]
        if not cause or not failed:
            return None
        for ref in failed:
            rpc = ref.get("rpc_trace") or {}
            code = {"rpc_internal": 13, "rpc_deadline_exceeded": 4, "rpc_high_traffic": 8}[cause]
            if (ref.get("cause") != cause or rpc.get("rpc_method") != "maseQ"
                    or rpc.get("dispatch_started") is not True or rpc.get("success") is not False
                    or rpc.get("response_complete") is not True or rpc.get("http_status") != 200
                    or rpc.get("rpc_rejection_confirmed") is not True
                    or rpc.get("submission_outcome") != "explicit_provider_rejection"
                    or type(rpc.get("rpc_status_code")) is not int or rpc["rpc_status_code"] != code):
                return None
            if cause == "rpc_high_traffic":
                if (rpc.get("provider_code") != "PUBLIC_ERROR_HIGH_TRAFFIC"
                        or rpc.get("rpc_public_error_present") is not True):
                    return None
            elif rpc.get("provider_code") or rpc.get("rpc_public_error_present") is not False:
                return None
        return cause

    async def _upload_reference_images(
        self,
        token,
        project_id: str,
        model_config: dict,
        images: List[bytes],
        image_trace: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, str]]:
        """Upload all references concurrently, retaining input order and context.

        Each child inherits the caller's account fingerprint. The existing
        upload_image method alone owns per-image retry/transport policy.
        On failure or cancellation, drain every child before leaving the batch.
        """
        if not images:
            return []
        # Lazy initialization supports isolated handler use without app startup.
        if not hasattr(self, "_reference_upload_admission"):
            self._reference_upload_admission = _ReferenceUploadAdmission()
        admission = self._reference_upload_admission
        queue_started_at = time.monotonic()
        upload_trace = image_trace.get("reference_upload") if image_trace is not None else None
        if upload_trace is not None:
            upload_trace["mode"] = "parallel"
            upload_trace["parallelism"] = len(images)
            upload_trace["peak_active_uploads"] = 0
        account = getattr(token, "id", None)
        if account is None:
            account = token.at
        pressure_at_enqueue = admission.snapshot(account, len(images))
        try:
            lease = await admission.acquire(account, len(images))
        except asyncio.TimeoutError as exc:
            if upload_trace is not None:
                upload_trace["admission"] = {"status": "timeout", "wait_ms": max(
                    0, int((time.monotonic() - queue_started_at) * 1000)),
                    "max_account_batches": admission.account_batches,
                    "reference_capacity": admission.reference_capacity,
                    "wait_timeout_seconds": admission.wait_seconds,
                    "pressure_at_enqueue": pressure_at_enqueue,
                    "pressure_at_timeout": admission.snapshot(account, len(images))}
            raise RuntimeError(
                "Project-scoped image upload failed via /flow/uploadImage; "
                "cause=upload_queue_timeout; attempts=0"
            ) from exc
        if upload_trace is not None:
            upload_trace["admission"] = {"status": "admitted", "wait_ms": max(
                0, int((time.monotonic() - queue_started_at) * 1000)),
                "max_account_batches": admission.account_batches,
                "reference_capacity": admission.reference_capacity,
                "wait_timeout_seconds": admission.wait_seconds,
                "pressure_at_enqueue": pressure_at_enqueue,
                "account_batches_at_start": lease["account_batches"],
                "reserved_references_at_start": lease["reserved_references"]}
        batch_started_at = time.monotonic()
        # Stable pre-upload assignment; a changed route must not inherit an
        # older exit's failure/success. Account fallback works without registry.
        environment = (image_trace or {}).get("environment") or {}
        assigned_exit = environment.get("assigned_exit_sha256")
        if not isinstance(assigned_exit, str) or not re.fullmatch(r"[a-f0-9]{64}", assigned_exit):
            assigned_exit = None
        active_uploads = 0

        async def upload_one(index: int, image_bytes: bytes) -> Dict[str, str]:
            nonlocal active_uploads
            upload_item = upload_trace["images"][index] if upload_trace is not None else None
            active_uploads += 1
            if upload_trace is not None:
                upload_trace["peak_active_uploads"] = max(
                    upload_trace["peak_active_uploads"], active_uploads,
                )
            if upload_item is not None:
                upload_item.update({"request_id": image_trace.get("upload_request_id"),
                                    "flow_log_id": image_trace.get("upload_flow_log_id"),
                                    "account_id": getattr(token, "id", None),
                                    "input_image_count": len(images)})
                upload_item["parallel_started_ms"] = max(
                    0, int((time.monotonic() - batch_started_at) * 1000),
                )
            try:
                media_id = await self.flow_client.upload_image(
                    token.at,
                    image_bytes,
                    model_config["aspect_ratio"],
                    project_id=project_id,
                    diagnostic_trace=upload_item,
                )
                if upload_trace is not None:
                    upload_trace["uploaded_count"] += 1
                if upload_item is not None:
                    upload_item["parallel_outcome"] = "uploaded"
                return {"name": media_id, "imageInputType": "IMAGE_INPUT_TYPE_REFERENCE"}
            except asyncio.CancelledError:
                if upload_item is not None:
                    upload_item["parallel_outcome"] = "cancelled"
                raise
            except Exception:
                if upload_item is not None:
                    upload_item["parallel_outcome"] = "failed"
                raise
            finally:
                admission.reference_finished(lease)
                active_uploads -= 1
                if upload_item is not None:
                    upload_item["parallel_finished_ms"] = max(
                        0, int((time.monotonic() - batch_started_at) * 1000),
                    )

        tasks = []
        try:
            for index, image_bytes in enumerate(images):
                tasks.append(asyncio.create_task(upload_one(index, image_bytes)))
            # gather retains the source order even when HTTPs finish out of order.
            results = await asyncio.gather(*tasks)
            self._observe_upload_schedule(account, assigned_exit, batch_started_at, upload_trace)
            return results
        except BaseException as failure:
            settling = []
            settlement = None
            try:
                reason = self._upload_batch_settle_reason(failure, upload_trace)
                if reason:
                    for task, ref in zip(tasks, upload_trace["images"]):
                        ref["batch_stop_requested"] = True
                        if task.done():
                            continue
                        rpc = ref.get("rpc_trace") or {}
                        if (rpc.get("dispatch_started") is True and rpc.get("rpc_method") == "maseQ"
                                and rpc.get("success") is not False):
                            settling.append(task)
                        else:
                            task.cancel()  # No new solver/POST after the batch failed.
                    settlement = {"policy": "dispatched_siblings_only_v1", "trigger": reason,
                                  "grace_seconds": 10, "dispatched_pending": len(settling)}
                    upload_trace["failure_settlement"] = settlement
                    started = time.monotonic()
                    remaining = set(settling)
                    deadline = started + 10
                    while remaining:
                        done, remaining = await asyncio.wait(remaining,
                            timeout=max(0, deadline - time.monotonic()),
                            return_when=asyncio.FIRST_COMPLETED)
                        if not done:
                            break
                        errors = [t.exception() for t in done if not t.cancelled() and t.exception()]
                        # A refusal/unknown result stops observation promptly;
                        # it never gains recovery from the initial technical error.
                        if errors and any(not self._upload_batch_settle_reason(e, upload_trace) for e in errors):
                            policy_error = next((e for e in errors if image_content_policy.rejection(e)), None)
                            if policy_error is not None:
                                failure = policy_error
                            break
                    settlement.update(wait_ms=round((time.monotonic() - started) * 1000),
                        settled=sum(t.done() for t in settling), pending_at_deadline=len(remaining),
                        deadline_reached=bool(remaining) and time.monotonic() >= deadline)
            finally:
                # Cleanup also runs when the caller cancels during settlement.
                # Unknown/cancelled dispatches remain unknown in the original
                # strict recovery decision; successful siblings are not replayed here.
                for task in tasks:
                    if not task.done():
                        task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
            self._observe_upload_schedule(account, assigned_exit, batch_started_at, upload_trace, failure)
            raise failure
        finally:
            admission.release(lease)


    async def _handle_image_generation(self, token, *args, **kwargs) -> AsyncGenerator:
        """Bound complete pipelines before any upload or CAPTCHA consumption.

        Configured paid tiers admit bounded isolated image pipelines.
        Their RPCs use bounded Cookie readers and lineage-checked delta commits;
        free, unknown or unconfigured tiers retain one pipeline.
        """
        auth = getattr(self.token_manager, "cookie_auth", None)
        is_cookie = getattr(token, "id", None) in getattr(auth, "cache", {})
        lease = None
        gate = None
        trace = None
        scope = None
        pipeline_limit = 1
        if is_cookie:
            gate = getattr(self, "_cookie_image_pipeline_admission", None)
            if gate is None:
                gate = self._cookie_image_pipeline_admission = _ReferenceUploadAdmission(
                    account_batches=cookie_capacity.MAX_PIPELINES, reference_capacity=192, wait_seconds=120)
            model_config = kwargs.get("model_config") or (args[1] if len(args) > 1 else {})
            pipeline_limit = cookie_capacity.account_limit(token.id, tier=getattr(token, "user_paygate_tier", None), four_k=
                model_config.get("upsample") == "UPSAMPLE_IMAGE_RESOLUTION_4K")
            perf = kwargs.get("perf_trace")
            if isinstance(perf, dict):
                trace = perf.setdefault("image_generation", {}).setdefault("account_pipeline_admission", {})
                trace.update(policy="cookie_pipeline_bounded_v2", status="waiting",
                    max_account_pipelines=pipeline_limit, wait_timeout_seconds=gate.wait_seconds,
                    pressure_at_enqueue=gate.snapshot(token.id, 1, account_limit=pipeline_limit))
            started = time.monotonic()
            try:
                lease = await gate.acquire(token.id, 1, account_limit=pipeline_limit)
            except asyncio.TimeoutError as error:
                if trace is not None:
                    trace.update(status="timeout", wait_ms=round((time.monotonic()-started)*1000),
                        dispatch_started=False, upload_posts=0,
                        pressure_at_timeout=gate.snapshot(token.id, 1))
                raise RuntimeError("flow_account_capacity_unavailable:account_pipeline_queue_timeout") from error
            except BaseException:
                if trace is not None:
                    trace.update(status="cancelled", wait_ms=round((time.monotonic()-started)*1000),
                        dispatch_started=False, upload_posts=0)
                raise
            if trace is not None:
                trace.update(status="admitted", wait_ms=round((time.monotonic()-started)*1000),
                    active_account_pipelines_at_start=lease["account_batches"])
            scope = cookie_capacity.enter_pipeline(token.id, pipeline_limit)
        inner = self._handle_image_generation_admitted(token, *args, **kwargs)
        try:
            async for chunk in inner:
                yield chunk
        except Exception:
            if is_cookie and pipeline_limit > 1:
                backoff = cookie_capacity.pause_parallel(token.id)
                if trace is not None:
                    trace["parallel_backoff"] = backoff
            raise
        finally:
            try:
                # Drain/close child upload tasks before returning the lease.
                await inner.aclose()
            finally:
                if lease is not None:
                    gate.release(lease)
                    if trace is not None:
                        trace["released"] = True
                if scope is not None:
                    cookie_capacity.leave_pipeline(scope)

    async def _handle_image_generation_admitted(
        self,
        token,
        project_id: str,
        model_config: dict,
        prompt: str,
        images: Optional[List[bytes]],
        stream: bool,
        perf_trace: Optional[Dict[str, Any]] = None,
        generation_result: Optional[Dict[str, Any]] = None,
        response_state: Optional[Dict[str, Any]] = None,
        request_log_state: Optional[Dict[str, Any]] = None,
        pending_token_state: Optional[Dict[str, bool]] = None
    ) -> AsyncGenerator:
        """处理图片生成 (同步返回)"""

        if response_state is None:
            response_state = self._create_response_state()

        image_trace: Optional[Dict[str, Any]] = None
        if isinstance(perf_trace, dict):
            image_trace = perf_trace.setdefault("image_generation", {})
            image_trace["input_image_count"] = len(images) if images else 0

        # Reject unsupported inputs before Google uploads or CAPTCHA consumption.
        if model_config.get("native_original_aspect"):
            geometry = ((image_trace or {}).get("original_aspect")
                        or reference_geometry(images, model_config["aspect_ratio"]))
            if await self.flow_client._cookie_media_for(token_id=token.id) is None:
                raise ValueError("original_aspect_cookie_rpc_required")
            if image_trace is not None:
                image_trace["original_aspect"] = geometry

        # 不在本地等待图片硬并发槽位；请求一到就直接向上游提交。
        normalized_tier = normalize_user_paygate_tier(token.user_paygate_tier)

        if image_trace is not None:
            image_trace["slot_wait_ms"] = 0
            # Snapshot assigned identity before uploads/solves. No registry I/O
            # is added between synchronous CAPTCHA token return and dispatch.
            try:
                assigned_route = upload_egress.identity(token.id) or {}
            except Exception:
                assigned_route = {}
            image_trace["environment"] = {
                "schema": 1, "diagnostic_build": image_provenance.BUILD,
                "account_id": token.id,
                "image_model_sha256": image_provenance.fingerprint(model_config.get("model_name")),
                "aspect_ratio_sha256": image_provenance.fingerprint(model_config.get("aspect_ratio")),
                "paygate_tier_sha256": image_provenance.fingerprint(normalized_tier),
                "target_resolution": image_provenance.enum_value(model_config.get("upsample"), {
                    "UPSAMPLE_IMAGE_RESOLUTION_2K", "UPSAMPLE_IMAGE_RESOLUTION_4K"}),
                "assigned_exit_sha256": assigned_route.get("assigned_exit_sha256"),
                "route_family": assigned_route.get("route_family", "unknown"),
                "assigned_exit_observation": "pre_upload_registry_snapshot",
            }

        flash_probe = False
        flash_generation_resolved = False
        if model_config.get("model_name") == "BELUGA":
            admitted, flash_probe, retry_after = await FLASH_ENDPOINT_GUARD.admit()
            if not admitted:
                if image_trace is not None:
                    image_trace["model_endpoint"] = {
                        "state": "circuit_open", "retry_after_seconds": retry_after,
                    }
                raise RuntimeError(
                    f"flow_model_temporarily_unavailable:circuit_open:retry_after={retry_after}"
                )
            if image_trace is not None and flash_probe:
                image_trace["model_endpoint"] = {"state": "half_open_probe"}

        if image_trace is not None:
            image_trace["upload_request_id"] = (perf_trace or {}).get("request_id")
            image_trace["upload_flow_log_id"] = (request_log_state or {}).get("id")
        if images and len(images) > 0:
            await self._update_request_log_progress(request_log_state, token_id=token.id, status_text="uploading_images", progress=28)
        else:
            await self._update_request_log_progress(request_log_state, token_id=token.id, status_text="submitting_image", progress=28)

        try:
            # 上传图片 (如果有)
            upload_started_at = time.time()
            image_inputs = []
            if images and len(images) > 0:
                existing = (
                    image_trace.get("reference_upload") if image_trace is not None else None
                )
                metadata_is_valid = (
                    isinstance(existing, dict)
                    and isinstance(existing.get("images"), list)
                    and len(existing["images"]) == len(images)
                )
                if not metadata_is_valid:
                    # Internal calls and a second-account attempt retain this gate.
                    metadata = [self._reference_image_metadata(item) for item in images]
                else:
                    metadata = existing["images"]
                if image_trace is not None and not metadata_is_valid:
                    image_trace["reference_upload"] = {
                        "images": [{"index": i + 1, **item} for i, item in enumerate(metadata)],
                        "uploaded_count": 0,
                    }
                if stream:
                    yield self._create_stream_chunk(f"上传 {len(images)} 张参考图片...\n")

                image_inputs = await self._upload_reference_images(
                    token, project_id, model_config, images, image_trace,
                )
                if model_config.get("native_original_aspect"):
                    image_inputs = original_inputs(image_inputs)
                if stream:
                    yield self._create_stream_chunk(f"已上传全部 {len(images)} 张参考图片\n")
            if image_trace is not None:
                image_trace["upload_images_ms"] = int((time.time() - upload_started_at) * 1000)
                image_trace["provenance"] = {
                    "schema": image_provenance.SCHEMA,
                    "project_sha256": image_provenance.fingerprint(project_id),
                    "prompt_sha256": image_provenance.fingerprint(prompt),
                    "inputs": image_provenance.media_fingerprints(image_inputs),
                }

            # 调用生成API
            if stream:
                if images and len(images) > 0:
                    yield self._create_stream_chunk("参考图片上传完成，正在进行打码验证...\n")
                else:
                    yield self._create_stream_chunk("正在进行打码验证并提交图片生成请求...\n")

            async def _image_progress_callback(status_text: str, progress: int):
                await self._update_request_log_progress(
                    request_log_state,
                    token_id=token.id,
                    status_text=status_text,
                    progress=progress,
                )

            generate_started_at = time.time()
            try:
                result, generation_session_id, upstream_trace = await self.flow_client.generate_image(
                    at=token.at,
                    project_id=project_id,
                    prompt=prompt,
                    model_name=model_config["model_name"],
                    aspect_ratio=model_config["aspect_ratio"],
                    image_inputs=image_inputs,
                    token_id=token.id,
                    token_image_concurrency=token.image_concurrency,
                    progress_callback=_image_progress_callback,
                )
            except Exception as generation_error:
                if model_config.get("model_name") == "BELUGA":
                    if await FLASH_ENDPOINT_GUARD.failure(token.id, generation_error):
                        flash_generation_resolved = True
                        if image_trace is not None:
                            image_trace["model_endpoint"] = {"state": "exact_upstream_404"}
                if image_trace is not None:
                    image_trace["generate_api_ms"] = int((time.time() - generate_started_at) * 1000)
                    terminal_trace = getattr(
                        generation_error,
                        "flow2api_image_generation_trace",
                        None,
                    )
                    if isinstance(terminal_trace, dict):
                        image_trace["upstream_trace"] = terminal_trace
                raise
            if model_config.get("model_name") == "BELUGA":
                await FLASH_ENDPOINT_GUARD.success()
                flash_generation_resolved = True
            if image_trace is not None:
                image_trace["generate_api_ms"] = int((time.time() - generate_started_at) * 1000)
                image_trace["upstream_trace"] = upstream_trace
                attempts = upstream_trace.get("generation_attempts") if isinstance(upstream_trace, dict) else None
                if isinstance(attempts, list) and attempts:
                    first_attempt = attempts[0] if isinstance(attempts[0], dict) else {}
                    image_trace["launch_queue_wait_ms"] = int(first_attempt.get("launch_queue_ms") or 0)
                    image_trace["launch_stagger_wait_ms"] = int(first_attempt.get("launch_stagger_ms") or 0)
            await self._update_request_log_progress(
                request_log_state,
                token_id=token.id,
                status_text="image_generated",
                progress=72,
            )

            # 提取URL和mediaId
            media = result.get("media", [])
            if not media:
                self._mark_generation_failed(generation_result, "\u751f\u6210\u7ed3\u679c\u4e3a\u7a7a")
                yield self._create_error_response("生成结果为空", status_code=502)
                return

            image_url = media[0]["image"]["generatedImage"]["fifeUrl"]
            media_id = media[0].get("name")  # 用于 upsample
            if image_trace is not None:
                image_trace["provenance"].update({
                    "returned_media": image_provenance.generation_response(result),
                    "selected_media_index": 0,
                    "selected_media_sha256": image_provenance.fingerprint(media_id),
                    "session_sha256": image_provenance.fingerprint(generation_session_id),
                    "base_image_url_sha256": image_provenance.fingerprint(image_url),
                })
            response_state["generated_assets"] = {
                "type": "image",
                "origin_image_url": image_url
            }

            # 检查是否需要 upsample
            upsample_resolution = model_config.get("upsample")
            resolution_name = (
                "4K" if upsample_resolution and "4K" in upsample_resolution else "2K"
            )
            if upsample_resolution and media_id:
                upsample_started_at = time.time()
                await self._update_request_log_progress(request_log_state, token_id=token.id, status_text=f"upsampling_{resolution_name.lower()}", progress=82)
                if stream:
                    yield self._create_stream_chunk(f"正在放大图片到 {resolution_name}...\n")

                try:
                    encoded_image, upsample_trace = await self.flow_client.upsample_image(
                        at=token.at,
                        project_id=project_id,
                        media_id=media_id,
                        target_resolution=upsample_resolution,
                        user_paygate_tier=normalized_tier,
                        session_id=generation_session_id,
                        token_id=token.id,
                        recovery_budget=_CROSS_ACCOUNT_RETRY_BUDGET,
                    )
                    if image_trace is not None:
                        image_trace["upsample"] = upsample_trace
                    validation_started = time.monotonic()
                    if image_trace is not None:
                        image_trace["output_validation"] = {"success": False, "stage": "upscaled_image_decode_and_dimensions"}
                    output_info = self._validate_upscaled_image(
                        encoded_image,
                        upsample_resolution,
                        model_config["aspect_ratio"],
                    )
                    if image_trace is not None:
                        image_trace["output_validation"].update(success=True, duration_ms=round((time.monotonic()-validation_started)*1000, 3))
                        image_trace["provenance"]["output"] = dict(output_info)
                        image_trace["output_validation"].update({k: output_info[k] for k in ("width", "height", "dimension_contract", "canonical_width", "canonical_height")})
                except Exception as upsample_error:
                    if image_trace is not None and image_trace.get("output_validation", {}).get("success") is False:
                        image_trace["output_validation"].update(failure_kind="image_decode_or_dimension_error", duration_ms=round((time.monotonic()-validation_started)*1000, 3))
                        diagnostic = getattr(upsample_error, "flow2api_output_validation", None)
                        if isinstance(diagnostic, dict):
                            image_trace["output_validation"].update(diagnostic)
                    terminal_trace = getattr(
                        upsample_error,
                        "flow2api_image_upsample_trace",
                        None,
                    )
                    if image_trace is not None:
                        if isinstance(terminal_trace, dict):
                            image_trace["upsample"] = terminal_trace
                        image_trace["upsample_ms"] = int(
                            (time.time() - upsample_started_at) * 1000
                        )
                    cause = self.flow_client._sanitize_image_upsample_error(upsample_error)
                    raise RuntimeError(
                        f"image_upsample_failed:{resolution_name}:cause={cause}"
                    ) from upsample_error

                debug_logger.log_info(
                    f"[UPSAMPLE] 图片已验证放大到 {resolution_name} "
                    f"({output_info['width']}x{output_info['height']})"
                )
                if stream:
                    yield self._create_stream_chunk(f"✅ 图片已放大到 {resolution_name}\n")

                # Local postprocessing is outside the upsample retry boundary:
                # it must never trigger another generation or solver charge.
                watermark_trace = image_trace.setdefault("watermark", {}) if image_trace is not None else {}
                watermark_trace["request_sha256"] = image_provenance.fingerprint((perf_trace or {}).get("request_id"))
                original_output = dict(output_info)
                original_bytes = base64.b64decode(encoded_image)
                delivered_bytes = await image_watermark.process_image(
                    original_bytes, watermark_trace, (request_log_state or {}).get("id"))
                if delivered_bytes is not original_bytes:
                    encoded_image = base64.b64encode(delivered_bytes).decode("ascii")
                    output_info = {**output_info, "format": "PNG", "bytes": len(delivered_bytes),
                                   "sha256": watermark_trace["delivered_sha"]}
                if image_trace is not None:
                    image_trace["provenance"]["upstream_output"] = original_output
                    image_trace["provenance"]["output"] = dict(output_info)

                response_state["generated_assets"] = {
                    "type": "image",
                    "origin_image_url": image_url,
                    "upscaled_image": {
                        "resolution": resolution_name,
                        "width": output_info["width"],
                        "height": output_info["height"],
                        "format": output_info["format"],
                        "size_bytes": output_info["bytes"],
                    },
                }

                output_cache = image_trace.setdefault("output_cache", {}) if image_trace is not None else {}
                cache_step = "base64_cache"
                try:
                    await self._update_request_log_progress(
                        request_log_state,
                        token_id=token.id,
                        status_text="caching_image",
                        progress=90,
                    )
                    if stream:
                        yield self._create_stream_chunk(f"缓存 {resolution_name} 图片中...\n")
                    cached_filename = await self.file_cache.cache_base64_image(
                        encoded_image,
                        resolution_name,
                    )
                    cache_step = "output_publish"
                    local_url = await self.file_cache.publish_cached_image(
                        cached_filename,
                        self._get_base_url(response_state),
                        diagnostic_trace=output_cache,
                    )
                    if image_trace is not None:
                        # Inline bodies may be large; fingerprint their decoded bytes above.
                        image_trace["provenance"]["published_url_sha256"] = (
                            None if local_url.startswith("data:") else image_provenance.fingerprint(local_url)
                        )
                    inline_delivery = local_url.startswith("data:image/")
                    response_state["url"] = None if inline_delivery else local_url
                    response_state["generated_assets"]["upscaled_image"]["local_url"] = (
                        None if inline_delivery else local_url
                    )
                    response_state["generated_assets"]["upscaled_image"]["url"] = (
                        None if inline_delivery else local_url
                    )
                    if inline_delivery:
                        response_state["generated_assets"]["upscaled_image"]["delivery_mode"] = (
                            "inline_base64_fallback"
                        )
                    self._mark_generation_succeeded(generation_result)
                    if stream:
                        yield self._create_stream_chunk(f"✅ {resolution_name} 图片缓存成功\n")
                        yield self._create_stream_chunk(
                            f"![Generated Image]({local_url})",
                            finish_reason="stop",
                        )
                    else:
                        yield self._create_completion_response(local_url, media_type="image")
                    if image_trace is not None:
                        image_trace["upsample_ms"] = int(
                            (time.time() - upsample_started_at) * 1000
                        )
                    return
                except Exception as cache_error:
                    output_cache["local_failure"] = {"stage": cache_step, "failure_kind": "local_processing_error"}
                    output_cache["delivery_mode"] = "inline_base64_fallback"
                    debug_logger.log_error(
                        f"Failed to cache {resolution_name} image: {type(cache_error).__name__}"
                    )
                    response_state["url"] = None
                    response_state["generated_assets"]["upscaled_image"]["local_url"] = None
                    response_state["generated_assets"]["upscaled_image"]["url"] = None
                    response_state["generated_assets"]["upscaled_image"]["delivery_mode"] = (
                        "inline_base64_fallback"
                    )
                    self._mark_generation_succeeded(generation_result)
                    mime_type = "image/jpeg" if output_info["format"] == "JPEG" else (
                        f"image/{output_info['format'].lower()}"
                    )
                    base64_url = f"data:{mime_type};base64,{encoded_image}"
                    if stream:
                        yield self._create_stream_chunk(
                            "⚠️ 缓存失败，返回已验证的内联高分辨率图片...\n"
                        )
                        yield self._create_stream_chunk(
                            f"![Generated Image]({base64_url})",
                            finish_reason="stop",
                        )
                    else:
                        yield self._create_completion_response(base64_url, media_type="image")
                    if image_trace is not None:
                        image_trace["upsample_ms"] = int(
                            (time.time() - upsample_started_at) * 1000
                        )
                    return

            if upsample_resolution and not media_id:
                raise RuntimeError(f"image_upsample_failed:{resolution_name}:cause=missing_media_id")

            local_url = image_url
            output_cache = image_trace.setdefault("output_cache", {}) if image_trace is not None else {}
            cache_step = "output_download"
            cache_started_at = time.time()
            # All generated images pass local inspection, even if URL caching
            # is disabled. This does not change the persisted cache setting.
            watermark_trace = image_trace.setdefault("watermark", {}) if image_trace is not None else {}
            watermark_trace["request_sha256"] = image_provenance.fingerprint((perf_trace or {}).get("request_id"))
            delivered_bytes = None
            await self._update_request_log_progress(
                request_log_state,
                token_id=token.id,
                status_text="caching_image",
                progress=90,
            )
            if stream:
                yield self._create_stream_chunk("正在缓存 1K 图片文件...\n")
            try:
                cached_filename = await self.file_cache.download_and_cache(image_url, "image", diagnostic_trace=output_cache)
                cache_step = "watermark"
                raw_output = await asyncio.to_thread(self.file_cache.get_cache_path(cached_filename).read_bytes)
                if model_config.get("native_original_aspect"):
                    cache_step = "original_aspect_validation"
                    output_info = await asyncio.to_thread(validate_output, raw_output, model_config["aspect_ratio"])
                    if image_trace is not None:
                        image_trace["output_validation"] = {"success": True, **output_info}
                    cache_step = "watermark"
                delivered_bytes = await image_watermark.process_image(
                    raw_output, watermark_trace, (request_log_state or {}).get("id"))
                if delivered_bytes is not raw_output:
                    # Keep old cached source URLs immutable.
                    cached_filename = await self.file_cache.cache_base64_image(
                        base64.b64encode(delivered_bytes).decode("ascii"), "watermark")
                cache_step = "output_publish"
                local_url = await self.file_cache.publish_cached_image(
                    cached_filename,
                    self._get_base_url(response_state),
                    diagnostic_trace=output_cache,
                )
                if stream:
                    yield self._create_stream_chunk("✅ 1K 图片缓存成功,准备返回缓存地址...\n")
            except Exception as e:
                output_cache["local_failure"] = {"stage": cache_step, "failure_kind": "cache_or_delivery_error"}
                if model_config.get("native_original_aspect") and delivered_bytes is None:
                    # The generated asset stays in response_state; never return
                    # unverified dimensions or regenerate after processing fails.
                    if image_trace is not None:
                        image_trace["output_validation"] = {"success": False, "stage": cache_step,
                            "error_class": type(e).__name__,
                            **getattr(e, "flow2api_output_validation", {})}
                    raise RuntimeError("image_original_aspect_output_validation_failed") from e
                output_cache["delivery_mode"] = "source_url_fallback"
                debug_logger.log_error(f"Failed to cache 1K image: {str(e)}")
                if delivered_bytes is not None:
                    # A publication failure retains the already generated,
                    # processed bytes and never starts new provider work.
                    mime = self.file_cache._validate_image_content(delivered_bytes)
                    local_url = f"data:{mime};base64," + base64.b64encode(delivered_bytes).decode("ascii")
                    output_cache["delivery_mode"] = "inline_base64_fallback"
                else:
                    local_url = image_url
                    await image_watermark.record_skip(watermark_trace, (request_log_state or {}).get("id"))
                if stream:
                    yield self._create_stream_chunk("⚠️ 缓存失败，返回已生成图片...\n")
            if image_trace is not None:
                image_trace["cache_image_ms"] = int((time.time() - cache_started_at) * 1000)
                image_trace["provenance"]["published_url_sha256"] = (
                    None if local_url.startswith("data:") else image_provenance.fingerprint(local_url)
                )
                if isinstance(output_cache.get("content"), dict):
                    image_trace["provenance"]["output"] = dict(output_cache["content"])

            # 返回结果
            # 存储URL用于日志记录
            response_state["url"] = local_url
            response_state["generated_assets"] = {
                "type": "image",
                "origin_image_url": image_url,
                "final_image_url": local_url
            }
            self._mark_generation_succeeded(generation_result)

            if stream:
                yield self._create_stream_chunk(
                    f"![Generated Image]({local_url})",
                    finish_reason="stop"
                )
            else:
                yield self._create_completion_response(
                    local_url,  # 直接传URL,让方法内部格式化
                    media_type="image"
                )

        finally:
            if image_trace is not None and "upload_images_ms" not in image_trace:
                image_trace["upload_images_ms"] = int(
                    (time.time() - upload_started_at) * 1000
                )
            if flash_probe and not flash_generation_resolved:
                await FLASH_ENDPOINT_GUARD.abandon_probe()

    async def _handle_video_generation(
        self,
        token,
        project_id: str,
        model_config: dict,
        prompt: str,
        images: Optional[List[bytes]],
        stream: bool,
        perf_trace: Optional[Dict[str, Any]] = None,
        generation_result: Optional[Dict[str, Any]] = None,
        response_state: Optional[Dict[str, Any]] = None,
        request_log_state: Optional[Dict[str, Any]] = None,
        pending_token_state: Optional[Dict[str, bool]] = None,
        video_media_id: Optional[str] = None,
    ) -> AsyncGenerator:
        """处理视频生成 (异步轮询)"""

        if response_state is None:
            response_state = self._create_response_state()

        video_trace: Optional[Dict[str, Any]] = None
        if isinstance(perf_trace, dict):
            video_trace = perf_trace.setdefault("video_generation", {})
            video_trace["input_image_count"] = len(images) if images else 0

        # 不在本地等待视频硬并发槽位；请求一到就直接向上游提交。
        normalized_tier = normalize_user_paygate_tier(token.user_paygate_tier)

        if video_trace is not None:
            video_trace["slot_wait_ms"] = 0

        await self._update_request_log_progress(request_log_state, token_id=token.id, status_text="preparing_video", progress=24)

        try:
            # 获取模型类型和配置
            video_type = model_config.get("video_type")
            supports_images = model_config.get("supports_images", False)
            min_images = model_config.get("min_images", 0)
            max_images = model_config.get("max_images", 0)
            use_v2_model_config = bool(model_config.get("use_v2_model_config", False))

            # 根据账号tier自动调整模型 key
            user_tier = normalized_tier

            original_model_key = model_config["model_key"]
            model_key, tier_message = self._resolve_video_model_key_for_tier(model_config, user_tier)
            if tier_message:
                if stream:
                    yield self._create_stream_chunk(f"{tier_message}\n")
                debug_logger.log_info(f"[VIDEO] 账号层级模型调整: {original_model_key} -> {model_key}")
            elif user_tier == "PAYGATE_TIER_TWO" and original_model_key == model_key:
                debug_logger.log_info(f"[VIDEO] TIER_TWO 账号，未找到有效 ultra 变体，保持模型: {model_key}")

            # 更新 model_config 中的 model_key
            model_config = dict(model_config)  # 创建副本避免修改原配置
            model_config["model_key"] = model_key

            # 图片数量
            image_count = len(images) if images else 0

            # ========== 验证和处理图片 ==========

            # T2V: 文生视频 - 不支持图片
            if video_type == "t2v":
                if image_count > 0:
                    if stream:
                        yield self._create_stream_chunk("⚠️ 文生视频模型不支持上传图片,将忽略图片仅使用文本提示词生成\n")
                    debug_logger.log_warning(f"[T2V] 模型 {model_config['model_key']} 不支持图片,已忽略 {image_count} 张图片")
                images = None  # 清空图片
                image_count = 0

            # Omni: 无图走 T2V，有图走当前上游 Reference Images 直连链路
            elif video_type == "omni":
                if max_images is not None and image_count > max_images:
                    error_msg = f"Omni 模型最多支持 {max_images} 张参考图，当前提供了 {image_count} 张"
                    if stream:
                        yield self._create_stream_chunk(f"{error_msg}\n")
                    self._mark_generation_failed(generation_result, error_msg)
                    yield self._create_error_response(error_msg, status_code=400)
                    return

            # I2V: 首尾帧模型 - 需要1-2张图片
            elif video_type == "i2v":
                if image_count < min_images or image_count > max_images:
                    error_msg = f"首尾帧模型需要 {min_images}-{max_images} 张图片，当前提供了 {image_count} 张"
                    if stream:
                        yield self._create_stream_chunk(f"{error_msg}\n")
                    self._mark_generation_failed(generation_result, error_msg)
                    yield self._create_error_response(error_msg, status_code=400)
                    return

            # R2V: 多图生成 - 当前上游协议最多 3 张参考图
            elif video_type == "r2v":
                if max_images is not None and image_count > max_images:
                    error_msg = f"多图视频模型最多支持 {max_images} 张参考图，当前提供了 {image_count} 张"
                    if stream:
                        yield self._create_stream_chunk(f"{error_msg}\n")
                    self._mark_generation_failed(generation_result, error_msg)
                    yield self._create_error_response(error_msg, status_code=400)
                    return

            # ========== 上传图片 ==========
            start_media_id = None
            end_media_id = None
            reference_images = []

            # I2V: 首尾帧处理
            if video_type == "i2v" and images:
                if image_count == 1:
                    # 只有1张图: 仅作为首帧
                    if stream:
                        yield self._create_stream_chunk("上传首帧图片...\n")
                    start_media_id = await self.flow_client.upload_image(
                        token.at, images[0], model_config["aspect_ratio"], project_id=project_id
                    )
                    debug_logger.log_info(f"[I2V] 仅上传首帧: {start_media_id}")

                elif image_count == 2:
                    # 2张图: 首帧+尾帧
                    if stream:
                        yield self._create_stream_chunk("上传首帧和尾帧图片...\n")
                    start_media_id = await self.flow_client.upload_image(
                        token.at, images[0], model_config["aspect_ratio"], project_id=project_id
                    )
                    end_media_id = await self.flow_client.upload_image(
                        token.at, images[1], model_config["aspect_ratio"], project_id=project_id
                    )
                    debug_logger.log_info(f"[I2V] 上传首尾帧: {start_media_id}, {end_media_id}")

            # R2V: 多图处理
            elif video_type == "r2v" and images:
                if stream:
                    yield self._create_stream_chunk(f"上传 {image_count} 张参考图片...\n")

                for img in images:
                    media_id = await self.flow_client.upload_image(
                        token.at, img, model_config["aspect_ratio"], project_id=project_id
                    )
                    reference_images.append({
                        "imageUsageType": "IMAGE_USAGE_TYPE_ASSET",
                        "mediaId": media_id
                    })
                debug_logger.log_info(f"[R2V] 上传了 {len(reference_images)} 张参考图片")

            # Omni R2V: 参考图上传到 project，随后直接走 batchAsyncGenerateVideoReferenceImages
            elif video_type == "omni" and images:
                if stream:
                    yield self._create_stream_chunk(f"上传 {image_count} 张 Omni 参考图片...\n")

                for img in images:
                    media_id = await self.flow_client.upload_image(
                        token.at, img, model_config["aspect_ratio"], project_id=project_id
                    )
                    reference_images.append({
                        "imageUsageType": "IMAGE_USAGE_TYPE_ASSET",
                        "mediaId": media_id
                    })
                debug_logger.log_info(f"[VIDEO OMNI-R2V] 上传了 {len(reference_images)} 张参考图片")

            # ========== 调用生成API ==========
            if stream:
                yield self._create_stream_chunk("提交视频生成任务...\n")
            submit_started_at = time.time()

            # I2V: 首尾帧生成
            if video_type == "i2v" and start_media_id:
                if end_media_id:
                    # 有首尾帧
                    result = await self.flow_client.generate_video_start_end(
                        at=token.at,
                        project_id=project_id,
                        prompt=prompt,
                        model_key=model_config["model_key"],
                        aspect_ratio=model_config["aspect_ratio"],
                        start_media_id=start_media_id,
                        end_media_id=end_media_id,
                        use_v2_model_config=use_v2_model_config,
                        user_paygate_tier=normalized_tier,
                        token_id=token.id,
                        token_video_concurrency=token.video_concurrency,
                    )
                else:
                    # 只有首帧 - 需要去掉 model_key 中的 _fl
                    # 情况1: _fl_ 在中间 (如 veo_3_1_i2v_s_fast_fl_ultra_relaxed -> veo_3_1_i2v_s_fast_ultra_relaxed)
                    # 情况2: _fl 在结尾 (如 veo_3_1_i2v_s_fast_ultra_fl -> veo_3_1_i2v_s_fast_ultra)
                    actual_model_key = model_config["model_key"].replace("_fl_", "_")
                    if actual_model_key.endswith("_fl"):
                        actual_model_key = actual_model_key[:-3]
                    debug_logger.log_info(f"[I2V] 单帧模式，model_key: {model_config['model_key']} -> {actual_model_key}")
                    result = await self.flow_client.generate_video_start_image(
                        at=token.at,
                        project_id=project_id,
                        prompt=prompt,
                        model_key=actual_model_key,
                        aspect_ratio=model_config["aspect_ratio"],
                        start_media_id=start_media_id,
                        use_v2_model_config=use_v2_model_config,
                        user_paygate_tier=normalized_tier,
                        token_id=token.id,
                        token_video_concurrency=token.video_concurrency,
                    )

            # R2V: 多图生成
            elif video_type == "r2v" and reference_images:
                result = await self.flow_client.generate_video_reference_images(
                    at=token.at,
                    project_id=project_id,
                    prompt=prompt,
                    model_key=model_config["model_key"],
                    aspect_ratio=model_config["aspect_ratio"],
                    reference_images=reference_images,
                    user_paygate_tier=normalized_tier,
                    token_id=token.id,
                    token_video_concurrency=token.video_concurrency,
                )

            # Omni: 有图走 Reference Images 直连链路，无图走纯文本链路
            elif video_type == "omni" and reference_images:
                if stream:
                    yield self._create_stream_chunk("提交 Omni 参考图视频任务...\n")
                result = await self.flow_client.generate_video_reference_images(
                    at=token.at,
                    project_id=project_id,
                    prompt=prompt,
                    model_key=model_config.get("reference_model_key", "abra_r2v_8s"),
                    aspect_ratio=model_config["aspect_ratio"],
                    reference_images=reference_images,
                    user_paygate_tier=normalized_tier,
                    token_id=token.id,
                    token_video_concurrency=token.video_concurrency,
                )

            # Extend: 视频续写
            elif video_type == "extend":
                if not video_media_id:
                    error_msg = "视频续写需要提供源视频的 mediaGenerationId，请在 image_url 中传入 extend://VIDEO_MEDIA_ID"
                    if stream:
                        yield self._create_stream_chunk(f"{error_msg}\n")
                    self._mark_generation_failed(generation_result, error_msg)
                    yield self._create_error_response(error_msg, status_code=400)
                    return

                debug_logger.log_info(f"[EXTEND] 续写视频: {video_media_id}")
                if stream:
                    yield self._create_stream_chunk(f"视频续写任务提交中，源视频: {video_media_id[:8]}...\n")
                result = await self.flow_client.generate_video_extend(
                    at=token.at,
                    project_id=project_id,
                    prompt=prompt,
                    video_media_id=video_media_id,
                    model_key=model_config["model_key"],
                    aspect_ratio=model_config["aspect_ratio"],
                    user_paygate_tier=normalized_tier,
                    token_id=token.id,
                    token_video_concurrency=token.video_concurrency,
                )

            # T2V 或 R2V无图: 纯文本生成
            else:
                result = await self.flow_client.generate_video_text(
                    at=token.at,
                    project_id=project_id,
                    prompt=prompt,
                    model_key=model_config["model_key"],
                    aspect_ratio=model_config["aspect_ratio"],
                    use_v2_model_config=use_v2_model_config,
                    user_paygate_tier=normalized_tier,
                    token_id=token.id,
                    token_video_concurrency=token.video_concurrency,
                )
            if video_trace is not None:
                video_trace["submit_generation_ms"] = int((time.time() - submit_started_at) * 1000)

            # 获取task_id和operations
            operations = result.get("operations", [])
            if not operations:
                self._mark_generation_failed(generation_result, "\u751f\u6210\u4efb\u52a1\u521b\u5efa\u5931\u8d25")
                yield self._create_error_response("生成任务创建失败", status_code=502)
                return

            operation = operations[0]
            task_id = operation["operation"]["name"]
            scene_id = operation.get("sceneId")

            # 保存Task到数据库
            task = Task(
                task_id=task_id,
                token_id=token.id,
                model=model_config["model_key"],
                prompt=prompt,
                status="processing",
                scene_id=scene_id
            )
            await self.db.create_task(task)
            await self._update_request_log_progress(
                request_log_state,
                token_id=token.id,
                status_text="video_submitted",
                progress=45,
                response_extra={"task_id": task_id, "scene_id": scene_id},
            )

            # 轮询结果
            if stream:
                yield self._create_stream_chunk(f"视频生成中...\n")

            # 检查是否需要放大
            upsample_config = model_config.get("upsample")

            # 如果是 extend，传入源视频 media_id 用于后续拼接
            extend_source_id = video_media_id if video_type == "extend" else None
            async for chunk in self._poll_video_result(
                token,
                project_id,
                operations,
                stream,
                upsample_config,
                generation_result,
                response_state,
                request_log_state,
                extend_source_media_id=extend_source_id,
            ):
                yield chunk

        finally:
            pass

    async def _poll_video_result(
        self,
        token,
        project_id: str,
        operations: List[Dict],
        stream: bool,
        upsample_config: Optional[Dict] = None,
        generation_result: Optional[Dict[str, Any]] = None,
        response_state: Optional[Dict[str, Any]] = None,
        request_log_state: Optional[Dict[str, Any]] = None,
        extend_source_media_id: Optional[str] = None,
    ) -> AsyncGenerator:
        """轮询视频生成结果
        
        Args:
            upsample_config: 放大配置 {"resolution": "VIDEO_RESOLUTION_4K", "model_key": "veo_3_1_upsampler_4k"}
        """

        if response_state is None:
            response_state = self._create_response_state()

        max_attempts = config.max_poll_attempts
        poll_interval = config.poll_interval
        
        # 如果需要放大，轮询次数加倍（放大可能需要 30 分钟）
        if upsample_config:
            max_attempts = max_attempts * 3  # 放大需要更长时间

        consecutive_poll_errors = 0
        last_poll_error: Optional[Exception] = None
        max_consecutive_poll_errors = 3

        for attempt in range(max_attempts):
            await asyncio.sleep(poll_interval)

            try:
                result = await self.flow_client.check_video_status(token.at, operations)
                checked_operations = result.get("operations", [])
                consecutive_poll_errors = 0
                last_poll_error = None

                if not checked_operations:
                    continue

                operation = checked_operations[0]
                status = operation.get("status")

                # 状态更新 - 每20秒报告一次 (poll_interval=3秒, 20秒约7次轮询)
                progress_update_interval = 7  # 每7次轮询 = 21秒
                if stream and attempt % progress_update_interval == 0:  # 每20秒报告一次
                    progress = min(int((attempt / max_attempts) * 100), 95)
                    await self._update_request_log_progress(request_log_state, token_id=token.id, status_text="video_polling", progress=max(45, progress), response_extra={"upstream_status": status})
                    yield self._create_stream_chunk(f"生成进度: {progress}%\n")

                # 检查状态
                if status == "MEDIA_GENERATION_STATUS_SUCCESSFUL":
                    try:
                        resolved_video = await self._resolve_video_asset(token, operation)
                    except Exception as redirect_error:
                        media_name = (
                            operation.get("mediaName")
                            or operation.get("name")
                            or operation["operation"].get("name")
                        )
                        error_msg = f"视频生成成功但获取媒体地址失败: {self._normalize_error_message(redirect_error)}"
                        debug_logger.log_warning(
                            f"[VIDEO POLL] 获取视频URL失败: media={media_name}, error={redirect_error}"
                        )
                        await self._fail_video_task(checked_operations, error_msg)
                        self._mark_generation_failed(generation_result, error_msg)
                        yield self._create_error_response(error_msg, status_code=502)
                        return

                    video_url = resolved_video["video_url"]
                    video_media_id = resolved_video["video_media_id"]
                    aspect_ratio = resolved_video["aspect_ratio"]
                    media_name = resolved_video["media_name"]
                    metadata = resolved_video["metadata"]
                    video_info = resolved_video["video_info"]

                    if not video_url:
                        media_name_for_fetch = (
                            operation.get("mediaName")
                            or operation["operation"].get("name", "")
                        )
                        if media_name_for_fetch:
                            if stream:
                                yield self._create_stream_chunk("视频生成完成，正在下载视频文件...\n")
                            try:
                                media_result = await self.flow_client.get_media(
                                    token.at, media_name_for_fetch
                                )
                                encoded_video = (
                                    media_result.get("video", {}).get("encodedVideo", "")
                                )
                                if encoded_video:
                                    cached_filename = await self.file_cache.cache_base64_video(
                                        encoded_video
                                    )
                                    video_url = f"{self._get_base_url(response_state)}/tmp/{cached_filename}"
                                    video_info["fifeUrl"] = video_url
                                    debug_logger.log_info(
                                        f"[VIDEO] Video fetched via get_media and cached: {cached_filename}"
                                    )
                                else:
                                    debug_logger.log_error(
                                        "[VIDEO] get_media returned empty encodedVideo"
                                    )
                            except Exception as fetch_err:
                                debug_logger.log_error(
                                    f"[VIDEO] Failed to fetch video via get_media: {fetch_err}"
                                )

                    if not video_url:
                        error_msg = "视频生成成功但未获取到媒体地址"
                        await self._fail_video_task(checked_operations, error_msg)
                        self._mark_generation_failed(generation_result, error_msg)
                        yield self._create_error_response(error_msg, status_code=502)
                        return

                    video_info["url"] = video_url
                    video_info["mediaName"] = media_name
                    video_info["mediaGenerationId"] = video_media_id
                    metadata.setdefault("video", video_info)
                    operation["operation"]["metadata"] = metadata

                    # ========== 视频放大处理 ==========
                    if upsample_config and video_media_id:
                        if stream:
                            resolution_name = "4K" if "4K" in upsample_config["resolution"] else "1080P"
                            yield self._create_stream_chunk(f"\n视频生成完成，开始 {resolution_name} 放大处理...（可能需要 30 分钟）\n")
                        
                        try:
                            # 提交放大任务
                            upsample_result = await self.flow_client.upsample_video(
                                at=token.at,
                                project_id=project_id,
                                video_media_id=video_media_id,
                                aspect_ratio=aspect_ratio,
                                resolution=upsample_config["resolution"],
                                model_key=upsample_config["model_key"],
                                user_paygate_tier=normalized_tier,
                                token_id=token.id,
                                token_video_concurrency=token.video_concurrency,
                            )
                            
                            upsample_operations = upsample_result.get("operations", [])
                            if upsample_operations:
                                if stream:
                                    yield self._create_stream_chunk("放大任务已提交，继续轮询...\n")
                                
                                # 递归轮询放大结果（不再放大）
                                async for chunk in self._poll_video_result(
                                    token,
                                    project_id,
                                    upsample_operations,
                                    stream,
                                    None,
                                    generation_result,
                                    response_state,
                                    request_log_state,
                                ):
                                    yield chunk
                                return
                            else:
                                if stream:
                                    yield self._create_stream_chunk("⚠️ 放大任务创建失败，返回原始视频\n")
                        except Exception as e:
                            debug_logger.log_error(f"Video upsample failed: {str(e)}")
                            if stream:
                                yield self._create_stream_chunk(f"⚠️ 放大失败: {str(e)}，返回原始视频\n")

                    # ========== Extend 视频拼接 ==========
                    if extend_source_media_id and video_media_id:
                        try:
                            if stream:
                                yield self._create_stream_chunk("\n视频续写完成，正在拼接完整视频...\n")
                            debug_logger.log_info(f"[CONCAT] 开始拼接: original={extend_source_media_id[:12]}..., extend={video_media_id[:12]}...")
                            
                            # 提交拼接任务
                            concat_result = await self.flow_client.run_concatenation(
                                at=token.at,
                                original_media_id=extend_source_media_id,
                                extend_media_id=video_media_id,
                            )
                            
                            # 获取 operation name
                            concat_op = concat_result.get("operation", {}).get("operation", {}).get("name", "")
                            if concat_op:
                                if stream:
                                    yield self._create_stream_chunk("拼接任务已提交，等待完成...\n")
                                
                                # 轮询拼接状态
                                concat_status = await self.flow_client.poll_concatenation_status(
                                    at=token.at,
                                    operation_name=concat_op,
                                    timeout=300,
                                    poll_interval=3,
                                )
                                
                                concat_url = concat_status.get("outputUri", "")
                                if concat_url:
                                    # 如果是本地路径（/tmp/xxx.mp4），构造完整 URL
                                    if concat_url.startswith("/tmp/"):
                                        server_host = config.server_host or "0.0.0.0"
                                        server_port = config.server_port or 8000
                                        # 对外使用 localhost
                                        host = "localhost" if server_host == "0.0.0.0" else server_host
                                        concat_url = f"http://{host}:{server_port}{concat_url}"
                                    video_url = concat_url  # 替换为拼接后的完整视频 URL
                                    if stream:
                                        yield self._create_stream_chunk("✅ 视频拼接完成！返回 16s 完整视频\n")
                                    debug_logger.log_info(f"[CONCAT] 拼接成功: {concat_url[:80]}...")
                                else:
                                    if stream:
                                        yield self._create_stream_chunk("⚠️ 拼接完成但无 URL，返回续写片段\n")
                            else:
                                debug_logger.log_warning("[CONCAT] 拼接任务创建失败，返回续写片段")
                                if stream:
                                    yield self._create_stream_chunk("⚠️ 拼接任务创建失败，返回续写片段\n")
                        except Exception as e:
                            import traceback
                            debug_logger.log_error(f"[CONCAT] 拼接失败: {str(e)}")
                            debug_logger.log_error(f"[CONCAT] traceback: {traceback.format_exc()}")
                            if stream:
                                yield self._create_stream_chunk(f"⚠️ 拼接失败: {str(e)}，返回续写片段\n")
                            # 拼接失败不影响返回，继续使用 extend 片段的 URL

                    # 缓存视频 (如果启用)
                    local_url = video_url
                    if config.cache_enabled:
                        await self._update_request_log_progress(request_log_state, token_id=token.id, status_text="caching_video", progress=92)
                        try:
                            if stream:
                                yield self._create_stream_chunk("正在缓存视频文件...\n")
                            cached_filename = await self.file_cache.download_and_cache(video_url, "video")
                            local_url = f"{self._get_base_url(response_state)}/tmp/{cached_filename}"
                            if stream:
                                yield self._create_stream_chunk("✅ 视频缓存成功,准备返回缓存地址...\n")
                        except Exception as e:
                            debug_logger.log_error(f"Failed to cache video: {str(e)}")
                            # 缓存失败不影响结果返回,使用原始URL
                            local_url = video_url
                            if stream:
                                cache_error = self._normalize_error_message(e, max_length=120)
                                yield self._create_stream_chunk(f"⚠️ 缓存失败: {cache_error}\n正在返回源链接...\n")
                    else:
                        if stream:
                            yield self._create_stream_chunk("缓存已关闭,正在返回源链接...\n")

                    # 更新数据库
                    task_id = operation["operation"]["name"]
                    await self.db.update_task(
                        task_id,
                        status="completed",
                        progress=100,
                        result_urls=[local_url],
                        completed_at=time.time()
                    )

                    # 存储URL用于日志记录
                    response_state["url"] = local_url
                    response_state["generated_assets"] = {
                        "type": "video",
                        "final_video_url": local_url,
                        "mediaGenerationId": video_media_id,
                        "mediaName": media_name,
                        "aspectRatio": aspect_ratio,
                        "model": resolved_video.get("model"),
                        "duration": resolved_video.get("duration"),
                    }

                    # 返回结果
                    self._mark_generation_succeeded(generation_result)

                    if stream:
                        yield self._create_stream_chunk(
                            f"<video src='{local_url}' data-media-id='{video_media_id}' controls style='max-width:100%'></video>",
                            finish_reason="stop"
                        )

                    else:
                        yield self._create_completion_response(
                            local_url,  # 直接传URL,让方法内部格式化
                            media_type="video"
                        )
                    return

                elif status == "MEDIA_GENERATION_STATUS_FAILED":
                    # 生成失败 - 提取错误信息
                    error_info = operation.get("operation", {}).get("error", {})
                    error_code = error_info.get("code", "unknown")
                    error_message = error_info.get("message", "未知错误")
                    
                    # 更新数据库任务状态
                    await self._fail_video_task(
                        checked_operations,
                        f"{error_message} (code: {error_code})"
                    )
                    
                    # 返回友好的错误消息，提示用户重试
                    friendly_error = f"视频生成失败: {error_message}，请重试"
                    self._mark_generation_failed(generation_result, friendly_error)
                    if stream:
                        yield self._create_stream_chunk(f"错误: {friendly_error}\n")
                    yield self._create_error_response(friendly_error, status_code=502)
                    return

                elif status.startswith("MEDIA_GENERATION_STATUS_ERROR"):
                    # ??????
                    error_msg = f"视频生成失败: {status}"
                    await self._fail_video_task(checked_operations, error_msg)
                    self._mark_generation_failed(generation_result, error_msg)
                    yield self._create_error_response(error_msg, status_code=502)
                    return
                    
                elif status == "MEDIA_GENERATION_STATUS_ACTIVE" and attempt > 80:
                    # 如果持续4分钟（80次 * 3秒 = 240秒）依然是 ACTIVE 状态，则判定为卡死
                    error_msg = "视频生成超时 (上游卡顿超过4分钟，已自动取消)"
                    await self._fail_video_task(checked_operations, error_msg)
                    self._mark_generation_failed(generation_result, error_msg)
                    if stream:
                        yield self._create_stream_chunk(f"错误: {error_msg}\n")
                    yield self._create_error_response(error_msg, status_code=504)
                    return

            except Exception as e:
                last_poll_error = e
                consecutive_poll_errors += 1
                debug_logger.log_error(f"Poll error: {str(e)}")
                if consecutive_poll_errors >= max_consecutive_poll_errors:
                    error_msg = f"视频状态查询失败: {self._normalize_error_message(e)}"
                    await self._fail_video_task(operations, error_msg)
                    self._mark_generation_failed(generation_result, error_msg)
                    if stream:
                        yield self._create_stream_chunk(f"错误: {error_msg}\n")
                    yield self._create_error_response(error_msg, status_code=502)
                    return
                continue

        # 超时
        if last_poll_error is not None:
            error_msg = f"视频状态查询持续失败: {self._normalize_error_message(last_poll_error)}"
        else:
            error_msg = f"视频生成超时 (已轮询 {max_attempts} 次)"
        await self._fail_video_task(operations, error_msg)
        self._mark_generation_failed(generation_result, error_msg)
        yield self._create_error_response(error_msg, status_code=504)

    # ========== 响应格式化 ==========

    def _create_stream_chunk(self, content: str, role: str = None, finish_reason: str = None) -> str:
        """创建流式响应chunk"""
        import json
        import time

        chunk = {
            "id": f"chatcmpl-{int(time.time())}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": "flow2api",
            "choices": [{
                "index": 0,
                "delta": {},
                "finish_reason": finish_reason
            }]
        }

        if role:
            chunk["choices"][0]["delta"]["role"] = role

        if finish_reason:
            chunk["choices"][0]["delta"]["content"] = content
        else:
            chunk["choices"][0]["delta"]["reasoning_content"] = content

        return f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"

    def _create_completion_response(self, content: str, media_type: str = "image", is_availability_check: bool = False) -> str:
        """创建非流式响应

        Args:
            content: 媒体URL或纯文本消息
            media_type: 媒体类型 ("image" 或 "video")
            is_availability_check: 是否为可用性检查响应 (纯文本消息)

        Returns:
            JSON格式的响应
        """
        import json
        import time

        # 可用性检查: 返回纯文本消息
        if is_availability_check:
            formatted_content = content
        else:
            # 媒体生成: 根据媒体类型格式化内容为Markdown
            if media_type == "video":
                formatted_content = f"```html\n<video src='{content}' controls></video>\n```"
            else:  # image
                formatted_content = f"![Generated Image]({content})"

        response = {
            "id": f"chatcmpl-{int(time.time())}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": "flow2api",
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": formatted_content
                },
                "finish_reason": "stop"
            }]
        }

        return json.dumps(response, ensure_ascii=False)

    def _create_error_response(
        self,
        error_message: str,
        status_code: int = 500,
        error_type: Optional[str] = None,
        error_code: str = "generation_failed",
        reason: Optional[str] = None,
        stage: Optional[str] = None,
        retry_after_seconds: Optional[int] = None,
    ) -> str:
        """创建错误响应"""
        import json

        error = {
            "error": {
                "message": error_message,
                "type": error_type or (
                    "server_error" if status_code >= 500 else "invalid_request_error"
                ),
                "code": error_code,
                "status_code": status_code,
            }
        }

        if reason:
            error["error"]["reason"] = reason
        if stage:
            error["error"]["stage"] = stage
        if retry_after_seconds is not None:
            error["error"]["retry_after_seconds"] = int(retry_after_seconds)

        return json.dumps(error, ensure_ascii=False)

    def _get_base_url(self, response_state: Optional[Dict[str, Any]] = None) -> str:
        """获取基础URL用于缓存文件访问"""
        # 已配置缓存访问域名时，始终优先使用它，避免被请求 Host/IP 覆盖。
        if config.cache_base_url:
            return config.cache_base_url.rstrip("/")

        request_base_url = ""
        if isinstance(response_state, dict):
            request_base_url = (response_state.get("base_url") or "").strip().rstrip("/")
        if request_base_url:
            return request_base_url

        # 回退到服务地址，避免把监听地址 0.0.0.0 / :: 直接返回给客户端
        server_host = (config.server_host or "").strip()
        if server_host in {"", "0.0.0.0", "::", "[::]"}:
            server_host = "127.0.0.1"

        return f"http://{server_host}:{config.server_port}"

    async def _update_request_log_progress(
        self,
        request_log_state: Optional[Dict[str, Any]],
        *,
        token_id: Optional[int] = None,
        status_text: str,
        progress: int,
        response_extra: Optional[Dict[str, Any]] = None,
    ):
        """?????????????"""
        if not isinstance(request_log_state, dict):
            return
        log_id = request_log_state.get("id")
        if not log_id:
            return

        safe_progress = max(0, min(100, int(progress)))
        now = time.time()
        last_status_text = str(request_log_state.get("last_status_text") or "").strip()
        last_progress = int(request_log_state.get("last_progress") or 0)
        last_updated_at = float(request_log_state.get("last_progress_update_at") or 0)

        request_log_state["progress"] = safe_progress
        request_log_state["last_status_text"] = status_text
        request_log_state["last_progress"] = safe_progress
        payload = {
            "status": "processing",
            "status_text": status_text,
            "progress": safe_progress,
        }
        if isinstance(response_extra, dict):
            payload.update(response_extra)

        should_write = (
            safe_progress in (0, 100)
            or status_text != last_status_text
            or safe_progress >= last_progress + 5
            or (now - last_updated_at) >= 1.0
        )
        if not should_write:
            return

        request_log_state["last_progress_update_at"] = now

        try:
            await self.db.update_request_log(
                log_id,
                token_id=token_id,
                response_body=json.dumps(payload, ensure_ascii=False),
                status_code=102,
                duration=0,
                status_text=status_text,
                progress=safe_progress,
            )
        except Exception as e:
            debug_logger.log_error(f"Failed to update request log progress: {e}")

    async def _log_request(
        self,
        token_id: Optional[int],
        operation: str,
        request_data: Dict[str, Any],
        response_data: Dict[str, Any],
        status_code: int,
        duration: float,
        log_id: Optional[int] = None,
        status_text: Optional[str] = None,
        progress: Optional[int] = None,
    ):
        """???????????? log_id ????????"""
        try:
            effective_status_text = status_text or (
                "completed" if status_code == 200 else "failed" if status_code >= 400 else "processing"
            )
            effective_progress = progress
            if effective_progress is None:
                effective_progress = 100 if status_code == 200 else 0 if status_code >= 400 else 0
            effective_progress = max(0, min(100, int(effective_progress)))

            google_failure_evidence.terminal(
                operation, effective_status_text, log_id, response_data.get("performance"))
            request_body = json.dumps(request_data, ensure_ascii=False)
            if operation == "generate_image" and effective_status_text in {"completed", "failed"}:
                performance = response_data.get("performance")
                if isinstance(performance, dict):
                    try:
                        image_provenance.annotate_performance(performance)
                    except Exception:
                        performance["image_association_diagnostic"] = {
                            "status": "diagnostic_unavailable",
                            "semantic_quality": "unreviewed",
                        }
            response_body = json.dumps(response_data, ensure_ascii=False)

            if log_id:
                await self.db.update_request_log(
                    log_id,
                    token_id=token_id,
                    operation=operation,
                    request_body=request_body,
                    response_body=response_body,
                    status_code=status_code,
                    duration=duration,
                    status_text=effective_status_text,
                    progress=effective_progress,
                )
                google_failure_evidence.bind_log_id(log_id)
                return log_id

            log = RequestLog(
                token_id=token_id,
                operation=operation,
                request_body=request_body,
                response_body=response_body,
                status_code=status_code,
                duration=duration,
                status_text=effective_status_text,
                progress=effective_progress,
            )
            created_id = await self.db.add_request_log(log)
            google_failure_evidence.bind_log_id(created_id)
            return created_id
        except Exception as e:
            debug_logger.log_error(f"Failed to log request: {e}")
            return None
